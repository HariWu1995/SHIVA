const Ya = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Er = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
Ya.reduce(
  (e, { color: t, primary: n, secondary: i }) => ({
    ...e,
    [t]: {
      primary: Er[t][n],
      secondary: Er[t][i]
    }
  }),
  {}
);
function Za(e) {
  let t, n = e[0], i = 1;
  for (; i < e.length; ) {
    const r = e[i], o = e[i + 1];
    if (i += 2, (r === "optionalAccess" || r === "optionalCall") && n == null)
      return;
    r === "access" || r === "optionalAccess" ? (t = n, n = o(n)) : (r === "call" || r === "optionalCall") && (n = o((...a) => n.call(t, ...a)), t = void 0);
  }
  return n;
}
class Wn extends Error {
  constructor(t) {
    super(t), this.name = "ShareError";
  }
}
async function Ja(e, t) {
  if (window.__gradio_space__ == null)
    throw new Wn("Must be on Spaces to share.");
  let n, i, r;
  if (t === "url") {
    const u = await fetch(e);
    n = await u.blob(), i = u.headers.get("content-type") || "", r = u.headers.get("content-disposition") || "";
  } else
    n = Qa(e), i = e.split(";")[0].split(":")[1], r = "file" + i.split("/")[1];
  const o = new File([n], r, { type: i }), a = await fetch("https://huggingface.co/uploads", {
    method: "POST",
    body: o,
    headers: {
      "Content-Type": o.type,
      "X-Requested-With": "XMLHttpRequest"
    }
  });
  if (!a.ok) {
    if (Za([a, "access", (u) => u.headers, "access", (u) => u.get, "call", (u) => u("content-type"), "optionalAccess", (u) => u.includes, "call", (u) => u("application/json")])) {
      const u = await a.json();
      throw new Wn(`Upload failed: ${u.error}`);
    }
    throw new Wn("Upload failed.");
  }
  return await a.text();
}
function Qa(e) {
  for (var t = e.split(","), n = t[0].match(/:(.*?);/)[1], i = atob(t[1]), r = i.length, o = new Uint8Array(r); r--; )
    o[r] = i.charCodeAt(r);
  return new Blob([o], { type: n });
}
const {
  SvelteComponent: Ka,
  assign: $a,
  create_slot: es,
  detach: ts,
  element: ns,
  get_all_dirty_from_scope: is,
  get_slot_changes: rs,
  get_spread_update: os,
  init: as,
  insert: ss,
  safe_not_equal: ls,
  set_dynamic_element_data: Tr,
  set_style: je,
  toggle_class: wt,
  transition_in: Vo,
  transition_out: Wo,
  update_slot_base: us
} = window.__gradio__svelte__internal;
function cs(e) {
  let t, n, i;
  const r = (
    /*#slots*/
    e[17].default
  ), o = es(
    r,
    e,
    /*$$scope*/
    e[16],
    null
  );
  let a = [
    { "data-testid": (
      /*test_id*/
      e[7]
    ) },
    { id: (
      /*elem_id*/
      e[2]
    ) },
    {
      class: n = "block " + /*elem_classes*/
      e[3].join(" ") + " svelte-1t38q2d"
    }
  ], s = {};
  for (let u = 0; u < a.length; u += 1)
    s = $a(s, a[u]);
  return {
    c() {
      t = ns(
        /*tag*/
        e[14]
      ), o && o.c(), Tr(
        /*tag*/
        e[14]
      )(t, s), wt(
        t,
        "hidden",
        /*visible*/
        e[10] === !1
      ), wt(
        t,
        "padded",
        /*padding*/
        e[6]
      ), wt(
        t,
        "border_focus",
        /*border_mode*/
        e[5] === "focus"
      ), wt(t, "hide-container", !/*explicit_call*/
      e[8] && !/*container*/
      e[9]), je(t, "height", typeof /*height*/
      e[0] == "number" ? (
        /*height*/
        e[0] + "px"
      ) : void 0), je(t, "width", typeof /*width*/
      e[1] == "number" ? `calc(min(${/*width*/
      e[1]}px, 100%))` : void 0), je(
        t,
        "border-style",
        /*variant*/
        e[4]
      ), je(
        t,
        "overflow",
        /*allow_overflow*/
        e[11] ? "visible" : "hidden"
      ), je(
        t,
        "flex-grow",
        /*scale*/
        e[12]
      ), je(t, "min-width", `calc(min(${/*min_width*/
      e[13]}px, 100%))`), je(t, "border-width", "var(--block-border-width)");
    },
    m(u, f) {
      ss(u, t, f), o && o.m(t, null), i = !0;
    },
    p(u, f) {
      o && o.p && (!i || f & /*$$scope*/
      65536) && us(
        o,
        r,
        u,
        /*$$scope*/
        u[16],
        i ? rs(
          r,
          /*$$scope*/
          u[16],
          f,
          null
        ) : is(
          /*$$scope*/
          u[16]
        ),
        null
      ), Tr(
        /*tag*/
        u[14]
      )(t, s = os(a, [
        (!i || f & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          u[7]
        ) },
        (!i || f & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          u[2]
        ) },
        (!i || f & /*elem_classes*/
        8 && n !== (n = "block " + /*elem_classes*/
        u[3].join(" ") + " svelte-1t38q2d")) && { class: n }
      ])), wt(
        t,
        "hidden",
        /*visible*/
        u[10] === !1
      ), wt(
        t,
        "padded",
        /*padding*/
        u[6]
      ), wt(
        t,
        "border_focus",
        /*border_mode*/
        u[5] === "focus"
      ), wt(t, "hide-container", !/*explicit_call*/
      u[8] && !/*container*/
      u[9]), f & /*height*/
      1 && je(t, "height", typeof /*height*/
      u[0] == "number" ? (
        /*height*/
        u[0] + "px"
      ) : void 0), f & /*width*/
      2 && je(t, "width", typeof /*width*/
      u[1] == "number" ? `calc(min(${/*width*/
      u[1]}px, 100%))` : void 0), f & /*variant*/
      16 && je(
        t,
        "border-style",
        /*variant*/
        u[4]
      ), f & /*allow_overflow*/
      2048 && je(
        t,
        "overflow",
        /*allow_overflow*/
        u[11] ? "visible" : "hidden"
      ), f & /*scale*/
      4096 && je(
        t,
        "flex-grow",
        /*scale*/
        u[12]
      ), f & /*min_width*/
      8192 && je(t, "min-width", `calc(min(${/*min_width*/
      u[13]}px, 100%))`);
    },
    i(u) {
      i || (Vo(o, u), i = !0);
    },
    o(u) {
      Wo(o, u), i = !1;
    },
    d(u) {
      u && ts(t), o && o.d(u);
    }
  };
}
function fs(e) {
  let t, n = (
    /*tag*/
    e[14] && cs(e)
  );
  return {
    c() {
      n && n.c();
    },
    m(i, r) {
      n && n.m(i, r), t = !0;
    },
    p(i, [r]) {
      /*tag*/
      i[14] && n.p(i, r);
    },
    i(i) {
      t || (Vo(n, i), t = !0);
    },
    o(i) {
      Wo(n, i), t = !1;
    },
    d(i) {
      n && n.d(i);
    }
  };
}
function hs(e, t, n) {
  let { $$slots: i = {}, $$scope: r } = t, { height: o = void 0 } = t, { width: a = void 0 } = t, { elem_id: s = "" } = t, { elem_classes: u = [] } = t, { variant: f = "solid" } = t, { border_mode: h = "base" } = t, { padding: p = !0 } = t, { type: g = "normal" } = t, { test_id: v = void 0 } = t, { explicit_call: B = !1 } = t, { container: D = !0 } = t, { visible: N = !0 } = t, { allow_overflow: K = !0 } = t, { scale: x = null } = t, { min_width: M = 0 } = t, H = g === "fieldset" ? "fieldset" : "div";
  return e.$$set = (A) => {
    "height" in A && n(0, o = A.height), "width" in A && n(1, a = A.width), "elem_id" in A && n(2, s = A.elem_id), "elem_classes" in A && n(3, u = A.elem_classes), "variant" in A && n(4, f = A.variant), "border_mode" in A && n(5, h = A.border_mode), "padding" in A && n(6, p = A.padding), "type" in A && n(15, g = A.type), "test_id" in A && n(7, v = A.test_id), "explicit_call" in A && n(8, B = A.explicit_call), "container" in A && n(9, D = A.container), "visible" in A && n(10, N = A.visible), "allow_overflow" in A && n(11, K = A.allow_overflow), "scale" in A && n(12, x = A.scale), "min_width" in A && n(13, M = A.min_width), "$$scope" in A && n(16, r = A.$$scope);
  }, [
    o,
    a,
    s,
    u,
    f,
    h,
    p,
    v,
    B,
    D,
    N,
    K,
    x,
    M,
    H,
    g,
    r,
    i
  ];
}
class Yo extends Ka {
  constructor(t) {
    super(), as(this, t, hs, fs, ls, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 15,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: ds,
  append: wi,
  attr: Dn,
  create_component: ms,
  destroy_component: _s,
  detach: ps,
  element: Pr,
  init: gs,
  insert: bs,
  mount_component: vs,
  safe_not_equal: ws,
  set_data: ys,
  space: Es,
  text: Ts,
  toggle_class: yt,
  transition_in: Ps,
  transition_out: Ms
} = window.__gradio__svelte__internal;
function Ss(e) {
  let t, n, i, r, o, a;
  return i = new /*Icon*/
  e[1]({}), {
    c() {
      t = Pr("label"), n = Pr("span"), ms(i.$$.fragment), r = Es(), o = Ts(
        /*label*/
        e[0]
      ), Dn(n, "class", "svelte-9gxdi0"), Dn(t, "for", ""), Dn(t, "data-testid", "block-label"), Dn(t, "class", "svelte-9gxdi0"), yt(t, "hide", !/*show_label*/
      e[2]), yt(t, "sr-only", !/*show_label*/
      e[2]), yt(
        t,
        "float",
        /*float*/
        e[4]
      ), yt(
        t,
        "hide-label",
        /*disable*/
        e[3]
      );
    },
    m(s, u) {
      bs(s, t, u), wi(t, n), vs(i, n, null), wi(t, r), wi(t, o), a = !0;
    },
    p(s, [u]) {
      (!a || u & /*label*/
      1) && ys(
        o,
        /*label*/
        s[0]
      ), (!a || u & /*show_label*/
      4) && yt(t, "hide", !/*show_label*/
      s[2]), (!a || u & /*show_label*/
      4) && yt(t, "sr-only", !/*show_label*/
      s[2]), (!a || u & /*float*/
      16) && yt(
        t,
        "float",
        /*float*/
        s[4]
      ), (!a || u & /*disable*/
      8) && yt(
        t,
        "hide-label",
        /*disable*/
        s[3]
      );
    },
    i(s) {
      a || (Ps(i.$$.fragment, s), a = !0);
    },
    o(s) {
      Ms(i.$$.fragment, s), a = !1;
    },
    d(s) {
      s && ps(t), _s(i);
    }
  };
}
function Cs(e, t, n) {
  let { label: i = null } = t, { Icon: r } = t, { show_label: o = !0 } = t, { disable: a = !1 } = t, { float: s = !0 } = t;
  return e.$$set = (u) => {
    "label" in u && n(0, i = u.label), "Icon" in u && n(1, r = u.Icon), "show_label" in u && n(2, o = u.show_label), "disable" in u && n(3, a = u.disable), "float" in u && n(4, s = u.float);
  }, [i, r, o, a, s];
}
class Zo extends ds {
  constructor(t) {
    super(), gs(this, t, Cs, Ss, ws, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: xs,
  append: ji,
  attr: Lt,
  bubble: Is,
  create_component: As,
  destroy_component: Rs,
  detach: Jo,
  element: Xi,
  init: Ls,
  insert: Qo,
  listen: Bs,
  mount_component: Ns,
  safe_not_equal: Os,
  set_data: Hs,
  space: ks,
  text: Ds,
  toggle_class: Et,
  transition_in: Us,
  transition_out: Fs
} = window.__gradio__svelte__internal;
function Mr(e) {
  let t, n;
  return {
    c() {
      t = Xi("span"), n = Ds(
        /*label*/
        e[1]
      ), Lt(t, "class", "svelte-xtz2g8");
    },
    m(i, r) {
      Qo(i, t, r), ji(t, n);
    },
    p(i, r) {
      r & /*label*/
      2 && Hs(
        n,
        /*label*/
        i[1]
      );
    },
    d(i) {
      i && Jo(t);
    }
  };
}
function Gs(e) {
  let t, n, i, r, o, a, s, u = (
    /*show_label*/
    e[2] && Mr(e)
  );
  return r = new /*Icon*/
  e[0]({}), {
    c() {
      t = Xi("button"), u && u.c(), n = ks(), i = Xi("div"), As(r.$$.fragment), Lt(i, "class", "svelte-xtz2g8"), Et(
        i,
        "small",
        /*size*/
        e[4] === "small"
      ), Et(
        i,
        "large",
        /*size*/
        e[4] === "large"
      ), Lt(
        t,
        "aria-label",
        /*label*/
        e[1]
      ), Lt(
        t,
        "title",
        /*label*/
        e[1]
      ), Lt(t, "class", "svelte-xtz2g8"), Et(
        t,
        "pending",
        /*pending*/
        e[3]
      ), Et(
        t,
        "padded",
        /*padded*/
        e[5]
      );
    },
    m(f, h) {
      Qo(f, t, h), u && u.m(t, null), ji(t, n), ji(t, i), Ns(r, i, null), o = !0, a || (s = Bs(
        t,
        "click",
        /*click_handler*/
        e[6]
      ), a = !0);
    },
    p(f, [h]) {
      /*show_label*/
      f[2] ? u ? u.p(f, h) : (u = Mr(f), u.c(), u.m(t, n)) : u && (u.d(1), u = null), (!o || h & /*size*/
      16) && Et(
        i,
        "small",
        /*size*/
        f[4] === "small"
      ), (!o || h & /*size*/
      16) && Et(
        i,
        "large",
        /*size*/
        f[4] === "large"
      ), (!o || h & /*label*/
      2) && Lt(
        t,
        "aria-label",
        /*label*/
        f[1]
      ), (!o || h & /*label*/
      2) && Lt(
        t,
        "title",
        /*label*/
        f[1]
      ), (!o || h & /*pending*/
      8) && Et(
        t,
        "pending",
        /*pending*/
        f[3]
      ), (!o || h & /*padded*/
      32) && Et(
        t,
        "padded",
        /*padded*/
        f[5]
      );
    },
    i(f) {
      o || (Us(r.$$.fragment, f), o = !0);
    },
    o(f) {
      Fs(r.$$.fragment, f), o = !1;
    },
    d(f) {
      f && Jo(t), u && u.d(), Rs(r), a = !1, s();
    }
  };
}
function zs(e, t, n) {
  let { Icon: i } = t, { label: r = "" } = t, { show_label: o = !1 } = t, { pending: a = !1 } = t, { size: s = "small" } = t, { padded: u = !0 } = t;
  function f(h) {
    Is.call(this, e, h);
  }
  return e.$$set = (h) => {
    "Icon" in h && n(0, i = h.Icon), "label" in h && n(1, r = h.label), "show_label" in h && n(2, o = h.show_label), "pending" in h && n(3, a = h.pending), "size" in h && n(4, s = h.size), "padded" in h && n(5, u = h.padded);
  }, [i, r, o, a, s, u, f];
}
class ai extends xs {
  constructor(t) {
    super(), Ls(this, t, zs, Gs, Os, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5
    });
  }
}
const {
  SvelteComponent: qs,
  append: js,
  attr: yi,
  binding_callbacks: Xs,
  create_slot: Vs,
  detach: Ws,
  element: Sr,
  get_all_dirty_from_scope: Ys,
  get_slot_changes: Zs,
  init: Js,
  insert: Qs,
  safe_not_equal: Ks,
  toggle_class: Tt,
  transition_in: $s,
  transition_out: el,
  update_slot_base: tl
} = window.__gradio__svelte__internal;
function nl(e) {
  let t, n, i;
  const r = (
    /*#slots*/
    e[5].default
  ), o = Vs(
    r,
    e,
    /*$$scope*/
    e[4],
    null
  );
  return {
    c() {
      t = Sr("div"), n = Sr("div"), o && o.c(), yi(n, "class", "icon svelte-3w3rth"), yi(t, "class", "empty svelte-3w3rth"), yi(t, "aria-label", "Empty value"), Tt(
        t,
        "small",
        /*size*/
        e[0] === "small"
      ), Tt(
        t,
        "large",
        /*size*/
        e[0] === "large"
      ), Tt(
        t,
        "unpadded_box",
        /*unpadded_box*/
        e[1]
      ), Tt(
        t,
        "small_parent",
        /*parent_height*/
        e[3]
      );
    },
    m(a, s) {
      Qs(a, t, s), js(t, n), o && o.m(n, null), e[6](t), i = !0;
    },
    p(a, [s]) {
      o && o.p && (!i || s & /*$$scope*/
      16) && tl(
        o,
        r,
        a,
        /*$$scope*/
        a[4],
        i ? Zs(
          r,
          /*$$scope*/
          a[4],
          s,
          null
        ) : Ys(
          /*$$scope*/
          a[4]
        ),
        null
      ), (!i || s & /*size*/
      1) && Tt(
        t,
        "small",
        /*size*/
        a[0] === "small"
      ), (!i || s & /*size*/
      1) && Tt(
        t,
        "large",
        /*size*/
        a[0] === "large"
      ), (!i || s & /*unpadded_box*/
      2) && Tt(
        t,
        "unpadded_box",
        /*unpadded_box*/
        a[1]
      ), (!i || s & /*parent_height*/
      8) && Tt(
        t,
        "small_parent",
        /*parent_height*/
        a[3]
      );
    },
    i(a) {
      i || ($s(o, a), i = !0);
    },
    o(a) {
      el(o, a), i = !1;
    },
    d(a) {
      a && Ws(t), o && o.d(a), e[6](null);
    }
  };
}
function il(e) {
  let t, n = e[0], i = 1;
  for (; i < e.length; ) {
    const r = e[i], o = e[i + 1];
    if (i += 2, (r === "optionalAccess" || r === "optionalCall") && n == null)
      return;
    r === "access" || r === "optionalAccess" ? (t = n, n = o(n)) : (r === "call" || r === "optionalCall") && (n = o((...a) => n.call(t, ...a)), t = void 0);
  }
  return n;
}
function rl(e, t, n) {
  let i, { $$slots: r = {}, $$scope: o } = t, { size: a = "small" } = t, { unpadded_box: s = !1 } = t, u;
  function f(p) {
    if (!p)
      return !1;
    const { height: g } = p.getBoundingClientRect(), { height: v } = il([
      p,
      "access",
      (B) => B.parentElement,
      "optionalAccess",
      (B) => B.getBoundingClientRect,
      "call",
      (B) => B()
    ]) || { height: g };
    return g > v + 2;
  }
  function h(p) {
    Xs[p ? "unshift" : "push"](() => {
      u = p, n(2, u);
    });
  }
  return e.$$set = (p) => {
    "size" in p && n(0, a = p.size), "unpadded_box" in p && n(1, s = p.unpadded_box), "$$scope" in p && n(4, o = p.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty & /*el*/
    4 && n(3, i = f(u));
  }, [a, s, u, i, o, r, h];
}
class Ko extends qs {
  constructor(t) {
    super(), Js(this, t, rl, nl, Ks, { size: 0, unpadded_box: 1 });
  }
}
const {
  SvelteComponent: ol,
  append: Ei,
  attr: nt,
  detach: al,
  init: sl,
  insert: ll,
  noop: Ti,
  safe_not_equal: ul,
  set_style: lt,
  svg_element: Un
} = window.__gradio__svelte__internal;
function cl(e) {
  let t, n, i, r;
  return {
    c() {
      t = Un("svg"), n = Un("g"), i = Un("path"), r = Un("path"), nt(i, "d", "M18,6L6.087,17.913"), lt(i, "fill", "none"), lt(i, "fill-rule", "nonzero"), lt(i, "stroke-width", "2px"), nt(n, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), nt(r, "d", "M4.364,4.364L19.636,19.636"), lt(r, "fill", "none"), lt(r, "fill-rule", "nonzero"), lt(r, "stroke-width", "2px"), nt(t, "width", "100%"), nt(t, "height", "100%"), nt(t, "viewBox", "0 0 24 24"), nt(t, "version", "1.1"), nt(t, "xmlns", "http://www.w3.org/2000/svg"), nt(t, "xmlns:xlink", "http://www.w3.org/1999/xlink"), nt(t, "xml:space", "preserve"), nt(t, "stroke", "currentColor"), lt(t, "fill-rule", "evenodd"), lt(t, "clip-rule", "evenodd"), lt(t, "stroke-linecap", "round"), lt(t, "stroke-linejoin", "round");
    },
    m(o, a) {
      ll(o, t, a), Ei(t, n), Ei(n, i), Ei(t, r);
    },
    p: Ti,
    i: Ti,
    o: Ti,
    d(o) {
      o && al(t);
    }
  };
}
class fl extends ol {
  constructor(t) {
    super(), sl(this, t, null, cl, ul, {});
  }
}
const {
  SvelteComponent: hl,
  append: dl,
  attr: bn,
  detach: ml,
  init: _l,
  insert: pl,
  noop: Pi,
  safe_not_equal: gl,
  svg_element: Cr
} = window.__gradio__svelte__internal;
function bl(e) {
  let t, n;
  return {
    c() {
      t = Cr("svg"), n = Cr("path"), bn(n, "d", "M23,20a5,5,0,0,0-3.89,1.89L11.8,17.32a4.46,4.46,0,0,0,0-2.64l7.31-4.57A5,5,0,1,0,18,7a4.79,4.79,0,0,0,.2,1.32l-7.31,4.57a5,5,0,1,0,0,6.22l7.31,4.57A4.79,4.79,0,0,0,18,25a5,5,0,1,0,5-5ZM23,4a3,3,0,1,1-3,3A3,3,0,0,1,23,4ZM7,19a3,3,0,1,1,3-3A3,3,0,0,1,7,19Zm16,9a3,3,0,1,1,3-3A3,3,0,0,1,23,28Z"), bn(n, "fill", "currentColor"), bn(t, "id", "icon"), bn(t, "xmlns", "http://www.w3.org/2000/svg"), bn(t, "viewBox", "0 0 32 32");
    },
    m(i, r) {
      pl(i, t, r), dl(t, n);
    },
    p: Pi,
    i: Pi,
    o: Pi,
    d(i) {
      i && ml(t);
    }
  };
}
class vl extends hl {
  constructor(t) {
    super(), _l(this, t, null, bl, gl, {});
  }
}
const {
  SvelteComponent: wl,
  append: yl,
  attr: zt,
  detach: El,
  init: Tl,
  insert: Pl,
  noop: Mi,
  safe_not_equal: Ml,
  svg_element: xr
} = window.__gradio__svelte__internal;
function Sl(e) {
  let t, n;
  return {
    c() {
      t = xr("svg"), n = xr("path"), zt(n, "fill", "currentColor"), zt(n, "d", "M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"), zt(t, "xmlns", "http://www.w3.org/2000/svg"), zt(t, "width", "100%"), zt(t, "height", "100%"), zt(t, "viewBox", "0 0 32 32");
    },
    m(i, r) {
      Pl(i, t, r), yl(t, n);
    },
    p: Mi,
    i: Mi,
    o: Mi,
    d(i) {
      i && El(t);
    }
  };
}
class Cl extends wl {
  constructor(t) {
    super(), Tl(this, t, null, Sl, Ml, {});
  }
}
const {
  SvelteComponent: xl,
  append: Si,
  attr: xe,
  detach: Il,
  init: Al,
  insert: Rl,
  noop: Ci,
  safe_not_equal: Ll,
  svg_element: Fn
} = window.__gradio__svelte__internal;
function Bl(e) {
  let t, n, i, r;
  return {
    c() {
      t = Fn("svg"), n = Fn("rect"), i = Fn("circle"), r = Fn("polyline"), xe(n, "x", "3"), xe(n, "y", "3"), xe(n, "width", "18"), xe(n, "height", "18"), xe(n, "rx", "2"), xe(n, "ry", "2"), xe(i, "cx", "8.5"), xe(i, "cy", "8.5"), xe(i, "r", "1.5"), xe(r, "points", "21 15 16 10 5 21"), xe(t, "xmlns", "http://www.w3.org/2000/svg"), xe(t, "width", "100%"), xe(t, "height", "100%"), xe(t, "viewBox", "0 0 24 24"), xe(t, "fill", "none"), xe(t, "stroke", "currentColor"), xe(t, "stroke-width", "1.5"), xe(t, "stroke-linecap", "round"), xe(t, "stroke-linejoin", "round"), xe(t, "class", "feather feather-image");
    },
    m(o, a) {
      Rl(o, t, a), Si(t, n), Si(t, i), Si(t, r);
    },
    p: Ci,
    i: Ci,
    o: Ci,
    d(o) {
      o && Il(t);
    }
  };
}
let si = class extends xl {
  constructor(t) {
    super(), Al(this, t, null, Bl, Ll, {});
  }
};
const {
  SvelteComponent: Nl,
  append: Ol,
  attr: qt,
  detach: Hl,
  init: kl,
  insert: Dl,
  noop: xi,
  safe_not_equal: Ul,
  svg_element: Ir
} = window.__gradio__svelte__internal;
function Fl(e) {
  let t, n;
  return {
    c() {
      t = Ir("svg"), n = Ir("path"), qt(n, "fill", "currentColor"), qt(n, "d", "M13.75 2a2.25 2.25 0 0 1 2.236 2.002V4h1.764A2.25 2.25 0 0 1 20 6.25V11h-1.5V6.25a.75.75 0 0 0-.75-.75h-2.129c-.404.603-1.091 1-1.871 1h-3.5c-.78 0-1.467-.397-1.871-1H6.25a.75.75 0 0 0-.75.75v13.5c0 .414.336.75.75.75h4.78a3.99 3.99 0 0 0 .505 1.5H6.25A2.25 2.25 0 0 1 4 19.75V6.25A2.25 2.25 0 0 1 6.25 4h1.764a2.25 2.25 0 0 1 2.236-2h3.5Zm2.245 2.096L16 4.25c0-.052-.002-.103-.005-.154ZM13.75 3.5h-3.5a.75.75 0 0 0 0 1.5h3.5a.75.75 0 0 0 0-1.5ZM15 12a3 3 0 0 0-3 3v5c0 .556.151 1.077.415 1.524l3.494-3.494a2.25 2.25 0 0 1 3.182 0l3.494 3.494c.264-.447.415-.968.415-1.524v-5a3 3 0 0 0-3-3h-5Zm0 11a2.985 2.985 0 0 1-1.524-.415l3.494-3.494a.75.75 0 0 1 1.06 0l3.494 3.494A2.985 2.985 0 0 1 20 23h-5Zm5-7a1 1 0 1 1 0-2a1 1 0 0 1 0 2Z"), qt(t, "xmlns", "http://www.w3.org/2000/svg"), qt(t, "width", "100%"), qt(t, "height", "100%"), qt(t, "viewBox", "0 0 24 24");
    },
    m(i, r) {
      Dl(i, t, r), Ol(t, n);
    },
    p: xi,
    i: xi,
    o: xi,
    d(i) {
      i && Hl(t);
    }
  };
}
class Gl extends Nl {
  constructor(t) {
    super(), kl(this, t, null, Fl, Ul, {});
  }
}
const {
  SvelteComponent: zl,
  append: Ii,
  attr: ke,
  detach: ql,
  init: jl,
  insert: Xl,
  noop: Ai,
  safe_not_equal: Vl,
  svg_element: Gn
} = window.__gradio__svelte__internal;
function Wl(e) {
  let t, n, i, r;
  return {
    c() {
      t = Gn("svg"), n = Gn("path"), i = Gn("polyline"), r = Gn("line"), ke(n, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), ke(i, "points", "17 8 12 3 7 8"), ke(r, "x1", "12"), ke(r, "y1", "3"), ke(r, "x2", "12"), ke(r, "y2", "15"), ke(t, "xmlns", "http://www.w3.org/2000/svg"), ke(t, "width", "90%"), ke(t, "height", "90%"), ke(t, "viewBox", "0 0 24 24"), ke(t, "fill", "none"), ke(t, "stroke", "currentColor"), ke(t, "stroke-width", "2"), ke(t, "stroke-linecap", "round"), ke(t, "stroke-linejoin", "round"), ke(t, "class", "feather feather-upload");
    },
    m(o, a) {
      Xl(o, t, a), Ii(t, n), Ii(t, i), Ii(t, r);
    },
    p: Ai,
    i: Ai,
    o: Ai,
    d(o) {
      o && ql(t);
    }
  };
}
let $o = class extends zl {
  constructor(t) {
    super(), jl(this, t, null, Wl, Vl, {});
  }
};
const {
  SvelteComponent: Yl,
  create_component: Zl,
  destroy_component: Jl,
  init: Ql,
  mount_component: Kl,
  safe_not_equal: $l,
  transition_in: eu,
  transition_out: tu
} = window.__gradio__svelte__internal, { createEventDispatcher: nu } = window.__gradio__svelte__internal;
function iu(e) {
  let t, n;
  return t = new ai({
    props: {
      Icon: vl,
      label: (
        /*i18n*/
        e[2]("common.share")
      ),
      pending: (
        /*pending*/
        e[3]
      )
    }
  }), t.$on(
    "click",
    /*click_handler*/
    e[5]
  ), {
    c() {
      Zl(t.$$.fragment);
    },
    m(i, r) {
      Kl(t, i, r), n = !0;
    },
    p(i, [r]) {
      const o = {};
      r & /*i18n*/
      4 && (o.label = /*i18n*/
      i[2]("common.share")), r & /*pending*/
      8 && (o.pending = /*pending*/
      i[3]), t.$set(o);
    },
    i(i) {
      n || (eu(t.$$.fragment, i), n = !0);
    },
    o(i) {
      tu(t.$$.fragment, i), n = !1;
    },
    d(i) {
      Jl(t, i);
    }
  };
}
function ru(e, t, n) {
  const i = nu();
  let { formatter: r } = t, { value: o } = t, { i18n: a } = t, s = !1;
  const u = async () => {
    try {
      n(3, s = !0);
      const f = await r(o);
      i("share", { description: f });
    } catch (f) {
      console.error(f);
      let h = f instanceof Wn ? f.message : "Share failed.";
      i("error", h);
    } finally {
      n(3, s = !1);
    }
  };
  return e.$$set = (f) => {
    "formatter" in f && n(0, r = f.formatter), "value" in f && n(1, o = f.value), "i18n" in f && n(2, a = f.i18n);
  }, [r, o, a, s, i, u];
}
class ou extends Yl {
  constructor(t) {
    super(), Ql(this, t, ru, iu, $l, { formatter: 0, value: 1, i18n: 2 });
  }
}
const {
  SvelteComponent: au,
  append: Ot,
  attr: Vi,
  create_component: su,
  destroy_component: lu,
  detach: Yn,
  element: Wi,
  init: uu,
  insert: Zn,
  mount_component: cu,
  safe_not_equal: fu,
  set_data: Yi,
  space: Zi,
  text: yn,
  toggle_class: Ar,
  transition_in: hu,
  transition_out: du
} = window.__gradio__svelte__internal;
function Rr(e) {
  let t, n, i = (
    /*i18n*/
    e[1]("common.or") + ""
  ), r, o, a, s = (
    /*message*/
    (e[2] || /*i18n*/
    e[1]("upload_text.click_to_upload")) + ""
  ), u;
  return {
    c() {
      t = Wi("span"), n = yn("- "), r = yn(i), o = yn(" -"), a = Zi(), u = yn(s), Vi(t, "class", "or svelte-kzcjhc");
    },
    m(f, h) {
      Zn(f, t, h), Ot(t, n), Ot(t, r), Ot(t, o), Zn(f, a, h), Zn(f, u, h);
    },
    p(f, h) {
      h & /*i18n*/
      2 && i !== (i = /*i18n*/
      f[1]("common.or") + "") && Yi(r, i), h & /*message, i18n*/
      6 && s !== (s = /*message*/
      (f[2] || /*i18n*/
      f[1]("upload_text.click_to_upload")) + "") && Yi(u, s);
    },
    d(f) {
      f && (Yn(t), Yn(a), Yn(u));
    }
  };
}
function mu(e) {
  let t, n, i, r, o = (
    /*i18n*/
    e[1](
      /*defs*/
      e[5][
        /*type*/
        e[0]
      ] || /*defs*/
      e[5].file
    ) + ""
  ), a, s, u;
  i = new $o({});
  let f = (
    /*mode*/
    e[3] !== "short" && Rr(e)
  );
  return {
    c() {
      t = Wi("div"), n = Wi("span"), su(i.$$.fragment), r = Zi(), a = yn(o), s = Zi(), f && f.c(), Vi(n, "class", "icon-wrap svelte-kzcjhc"), Ar(
        n,
        "hovered",
        /*hovered*/
        e[4]
      ), Vi(t, "class", "wrap svelte-kzcjhc");
    },
    m(h, p) {
      Zn(h, t, p), Ot(t, n), cu(i, n, null), Ot(t, r), Ot(t, a), Ot(t, s), f && f.m(t, null), u = !0;
    },
    p(h, [p]) {
      (!u || p & /*hovered*/
      16) && Ar(
        n,
        "hovered",
        /*hovered*/
        h[4]
      ), (!u || p & /*i18n, type*/
      3) && o !== (o = /*i18n*/
      h[1](
        /*defs*/
        h[5][
          /*type*/
          h[0]
        ] || /*defs*/
        h[5].file
      ) + "") && Yi(a, o), /*mode*/
      h[3] !== "short" ? f ? f.p(h, p) : (f = Rr(h), f.c(), f.m(t, null)) : f && (f.d(1), f = null);
    },
    i(h) {
      u || (hu(i.$$.fragment, h), u = !0);
    },
    o(h) {
      du(i.$$.fragment, h), u = !1;
    },
    d(h) {
      h && Yn(t), lu(i), f && f.d();
    }
  };
}
function _u(e, t, n) {
  let { type: i = "file" } = t, { i18n: r } = t, { message: o = void 0 } = t, { mode: a = "full" } = t, { hovered: s = !1 } = t;
  const u = {
    image: "upload_text.drop_image",
    video: "upload_text.drop_video",
    audio: "upload_text.drop_audio",
    file: "upload_text.drop_file",
    csv: "upload_text.drop_csv"
  };
  return e.$$set = (f) => {
    "type" in f && n(0, i = f.type), "i18n" in f && n(1, r = f.i18n), "message" in f && n(2, o = f.message), "mode" in f && n(3, a = f.mode), "hovered" in f && n(4, s = f.hovered);
  }, [i, r, o, a, s, u];
}
class pu extends au {
  constructor(t) {
    super(), uu(this, t, _u, mu, fu, {
      type: 0,
      i18n: 1,
      message: 2,
      mode: 3,
      hovered: 4
    });
  }
}
const {
  SvelteComponent: gu,
  attr: bu,
  create_slot: vu,
  detach: wu,
  element: yu,
  get_all_dirty_from_scope: Eu,
  get_slot_changes: Tu,
  init: Pu,
  insert: Mu,
  safe_not_equal: Su,
  toggle_class: Lr,
  transition_in: Cu,
  transition_out: xu,
  update_slot_base: Iu
} = window.__gradio__svelte__internal;
function Au(e) {
  let t, n;
  const i = (
    /*#slots*/
    e[2].default
  ), r = vu(
    i,
    e,
    /*$$scope*/
    e[1],
    null
  );
  return {
    c() {
      t = yu("div"), r && r.c(), bu(t, "class", "svelte-1nba87b"), Lr(
        t,
        "show_border",
        /*show_border*/
        e[0]
      );
    },
    m(o, a) {
      Mu(o, t, a), r && r.m(t, null), n = !0;
    },
    p(o, [a]) {
      r && r.p && (!n || a & /*$$scope*/
      2) && Iu(
        r,
        i,
        o,
        /*$$scope*/
        o[1],
        n ? Tu(
          i,
          /*$$scope*/
          o[1],
          a,
          null
        ) : Eu(
          /*$$scope*/
          o[1]
        ),
        null
      ), (!n || a & /*show_border*/
      1) && Lr(
        t,
        "show_border",
        /*show_border*/
        o[0]
      );
    },
    i(o) {
      n || (Cu(r, o), n = !0);
    },
    o(o) {
      xu(r, o), n = !1;
    },
    d(o) {
      o && wu(t), r && r.d(o);
    }
  };
}
function Ru(e, t, n) {
  let { $$slots: i = {}, $$scope: r } = t, { show_border: o = !1 } = t;
  return e.$$set = (a) => {
    "show_border" in a && n(0, o = a.show_border), "$$scope" in a && n(1, r = a.$$scope);
  }, [o, r, i];
}
class Lu extends gu {
  constructor(t) {
    super(), Pu(this, t, Ru, Au, Su, { show_border: 0 });
  }
}
var Ri = new Intl.Collator(0, { numeric: 1 }).compare;
function Br(e, t, n) {
  return e = e.split("."), t = t.split("."), Ri(e[0], t[0]) || Ri(e[1], t[1]) || (t[2] = t.slice(2).join("."), n = /[.-]/.test(e[2] = e.slice(2).join(".")), n == /[.-]/.test(t[2]) ? Ri(e[2], t[2]) : n ? -1 : 1);
}
function Mt(e, t, n) {
  return t.startsWith("http://") || t.startsWith("https://") ? n ? e : t : e + t;
}
function Li(e) {
  if (e.startsWith("http")) {
    const { protocol: t, host: n } = new URL(e);
    return n.endsWith("hf.space") ? {
      ws_protocol: "wss",
      host: n,
      http_protocol: t
    } : {
      ws_protocol: t === "https:" ? "wss" : "ws",
      http_protocol: t,
      host: n
    };
  } else if (e.startsWith("file:"))
    return {
      ws_protocol: "ws",
      http_protocol: "http:",
      host: "lite.local"
      // Special fake hostname only used for this case. This matches the hostname allowed in `is_self_host()` in `js/wasm/network/host.ts`.
    };
  return {
    ws_protocol: "wss",
    http_protocol: "https:",
    host: e
  };
}
const ea = /^[^\/]*\/[^\/]*$/, Bu = /.*hf\.space\/{0,1}$/;
async function Nu(e, t) {
  const n = {};
  t && (n.Authorization = `Bearer ${t}`);
  const i = e.trim();
  if (ea.test(i))
    try {
      const r = await fetch(
        `https://huggingface.co/api/spaces/${i}/host`,
        { headers: n }
      );
      if (r.status !== 200)
        throw new Error("Space metadata could not be loaded.");
      const o = (await r.json()).host;
      return {
        space_id: e,
        ...Li(o)
      };
    } catch (r) {
      throw new Error("Space metadata could not be loaded." + r.message);
    }
  if (Bu.test(i)) {
    const { ws_protocol: r, http_protocol: o, host: a } = Li(i);
    return {
      space_id: a.replace(".hf.space", ""),
      ws_protocol: r,
      http_protocol: o,
      host: a
    };
  }
  return {
    space_id: !1,
    ...Li(i)
  };
}
function Ou(e) {
  let t = {};
  return e.forEach(({ api_name: n }, i) => {
    n && (t[n] = i);
  }), t;
}
const Hu = /^(?=[^]*\b[dD]iscussions{0,1}\b)(?=[^]*\b[dD]isabled\b)[^]*$/;
async function Nr(e) {
  try {
    const n = (await fetch(
      `https://huggingface.co/api/spaces/${e}/discussions`,
      {
        method: "HEAD"
      }
    )).headers.get("x-error-message");
    return !(n && Hu.test(n));
  } catch {
    return !1;
  }
}
function dt(e, t, n) {
  if (e == null)
    return null;
  if (Array.isArray(e)) {
    const i = [];
    for (const r of e)
      r == null ? i.push(null) : i.push(dt(r, t, n));
    return i;
  }
  return e.is_stream ? n == null ? new Zt({
    ...e,
    url: t + "/stream/" + e.path
  }) : new Zt({
    ...e,
    url: "/proxy=" + n + "stream/" + e.path
  }) : new Zt({
    ...e,
    url: Du(e.path, t, n)
  });
}
function ku(e) {
  try {
    const t = new URL(e);
    return t.protocol === "http:" || t.protocol === "https:";
  } catch {
    return !1;
  }
}
function Du(e, t, n) {
  return e == null ? n ? `/proxy=${n}file=` : `${t}/file=` : ku(e) ? e : n ? `/proxy=${n}file=${e}` : `${t}/file=${e}`;
}
async function Uu(e, t, n, i = qu) {
  let r = (Array.isArray(e) ? e : [e]).map(
    (o) => o.blob
  );
  return await Promise.all(
    await i(t, r, void 0, n).then(
      async (o) => {
        if (o.error)
          throw new Error(o.error);
        return o.files ? o.files.map((a, s) => {
          const u = new Zt({ ...e[s], path: a });
          return dt(u, t, null);
        }) : [];
      }
    )
  );
}
async function Fu(e, t) {
  return e.map(
    (n, i) => new Zt({
      path: n.name,
      orig_name: n.name,
      blob: n,
      size: n.size,
      mime_type: n.type,
      is_stream: t
    })
  );
}
class Zt {
  constructor({
    path: t,
    url: n,
    orig_name: i,
    size: r,
    blob: o,
    is_stream: a,
    mime_type: s,
    alt_text: u
  }) {
    this.path = t, this.url = n, this.orig_name = i, this.size = r, this.blob = n ? void 0 : o, this.is_stream = a, this.mime_type = s, this.alt_text = u;
  }
}
const Gu = "This application is too busy. Keep trying!", vn = "Connection errored out.";
let ta;
function zu(e, t) {
  return { post_data: n, upload_files: i, client: r, handle_blob: o };
  async function n(a, s, u) {
    const f = { "Content-Type": "application/json" };
    u && (f.Authorization = `Bearer ${u}`);
    try {
      var h = await e(a, {
        method: "POST",
        body: JSON.stringify(s),
        headers: f
      });
    } catch {
      return [{ error: vn }, 500];
    }
    return [await h.json(), h.status];
  }
  async function i(a, s, u, f) {
    const h = {};
    u && (h.Authorization = `Bearer ${u}`);
    const p = 1e3, g = [];
    for (let B = 0; B < s.length; B += p) {
      const D = s.slice(B, B + p), N = new FormData();
      D.forEach((x) => {
        N.append("files", x);
      });
      try {
        const x = f ? `${a}/upload?upload_id=${f}` : `${a}/upload`;
        var v = await e(x, {
          method: "POST",
          body: N,
          headers: h
        });
      } catch {
        return { error: vn };
      }
      const K = await v.json();
      g.push(...K);
    }
    return { files: g };
  }
  async function r(a, s = { normalise_files: !0 }) {
    return new Promise(async (u) => {
      const { status_callback: f, hf_token: h, normalise_files: p } = s, g = {
        predict: ve,
        submit: we,
        view_api: Ee,
        component_server: Re
      }, v = p ?? !0;
      if ((typeof window > "u" || !("WebSocket" in window)) && !global.Websocket) {
        const P = await import("./wrapper-98f94c21-f7f71f53.js");
        ta = (await import("./__vite-browser-external-2447137e.js")).Blob, global.WebSocket = P.WebSocket;
      }
      const { ws_protocol: B, http_protocol: D, host: N, space_id: K } = await Nu(a, h), x = Math.random().toString(36).substring(2), M = {};
      let H, A = {}, E = !1;
      h && K && (E = await Xu(K, h));
      async function m(P) {
        if (H = P, A = Ou((P == null ? void 0 : P.dependencies) || []), H.auth_required)
          return {
            config: H,
            ...g
          };
        try {
          fe = await Ee(H);
        } catch (Y) {
          console.error(`Could not get api details: ${Y.message}`);
        }
        return {
          config: H,
          ...g
        };
      }
      let fe;
      async function be(P) {
        if (f && f(P), P.status === "running")
          try {
            H = await Dr(
              e,
              `${D}//${N}`,
              h
            );
            const Y = await m(H);
            u(Y);
          } catch (Y) {
            console.error(Y), f && f({
              status: "error",
              message: "Could not load this space.",
              load_status: "error",
              detail: "NOT_FOUND"
            });
          }
      }
      try {
        H = await Dr(
          e,
          `${D}//${N}`,
          h
        );
        const P = await m(H);
        u(P);
      } catch (P) {
        console.error(P), K ? Qi(
          K,
          ea.test(K) ? "space_name" : "subdomain",
          be
        ) : f && f({
          status: "error",
          message: "Could not load this space.",
          load_status: "error",
          detail: "NOT_FOUND"
        });
      }
      function ve(P, Y, le) {
        let pe = !1, Q = !1, k;
        if (typeof P == "number")
          k = H.dependencies[P];
        else {
          const ie = P.replace(/^\//, "");
          k = H.dependencies[A[ie]];
        }
        if (k.types.continuous)
          throw new Error(
            "Cannot call predict on this function as it may run forever. Use submit instead"
          );
        return new Promise((ie, R) => {
          const ye = we(P, Y, le);
          let O;
          ye.on("data", (b) => {
            Q && (ye.destroy(), ie(b)), pe = !0, O = b;
          }).on("status", (b) => {
            b.stage === "error" && R(b), b.stage === "complete" && (Q = !0, pe && (ye.destroy(), ie(O)));
          });
        });
      }
      function we(P, Y, le, pe = null) {
        let Q, k;
        if (typeof P == "number")
          Q = P, k = fe.unnamed_endpoints[Q];
        else {
          const ee = P.replace(/^\//, "");
          Q = A[ee], k = fe.named_endpoints[P.trim()];
        }
        if (typeof Q != "number")
          throw new Error(
            "There is no endpoint matching that name of fn_index matching that number."
          );
        let ie, R, ye = H.protocol ?? "sse";
        const O = typeof P == "number" ? "/predict" : P;
        let b, y = null, Z = !1;
        const U = {};
        let C = "";
        typeof window < "u" && (C = new URLSearchParams(window.location.search).toString()), o(
          `${D}//${Mt(N, H.path, !0)}`,
          Y,
          k,
          h
        ).then((ee) => {
          if (b = { data: ee || [], event_data: le, fn_index: Q, trigger_id: pe }, Vu(Q, H))
            w({
              type: "status",
              endpoint: O,
              stage: "pending",
              queue: !1,
              fn_index: Q,
              time: /* @__PURE__ */ new Date()
            }), n(
              `${D}//${Mt(N, H.path, !0)}/run${O.startsWith("/") ? O : `/${O}`}${C ? "?" + C : ""}`,
              {
                ...b,
                session_hash: x
              },
              h
            ).then(([oe, he]) => {
              const ce = v ? Bi(
                oe.data,
                k,
                H.root,
                H.root_url
              ) : oe.data;
              he == 200 ? (w({
                type: "data",
                endpoint: O,
                fn_index: Q,
                data: ce,
                time: /* @__PURE__ */ new Date()
              }), w({
                type: "status",
                endpoint: O,
                fn_index: Q,
                stage: "complete",
                eta: oe.average_duration,
                queue: !1,
                time: /* @__PURE__ */ new Date()
              })) : w({
                type: "status",
                stage: "error",
                endpoint: O,
                fn_index: Q,
                message: oe.error,
                queue: !1,
                time: /* @__PURE__ */ new Date()
              });
            }).catch((oe) => {
              w({
                type: "status",
                stage: "error",
                message: oe.message,
                endpoint: O,
                fn_index: Q,
                queue: !1,
                time: /* @__PURE__ */ new Date()
              });
            });
          else if (ye == "ws") {
            w({
              type: "status",
              stage: "pending",
              queue: !0,
              endpoint: O,
              fn_index: Q,
              time: /* @__PURE__ */ new Date()
            });
            let oe = new URL(`${B}://${Mt(
              N,
              H.path,
              !0
            )}
							/queue/join${C ? "?" + C : ""}`);
            E && oe.searchParams.set("__sign", E), ie = t(oe), ie.onclose = (he) => {
              he.wasClean || w({
                type: "status",
                stage: "error",
                broken: !0,
                message: vn,
                queue: !0,
                endpoint: O,
                fn_index: Q,
                time: /* @__PURE__ */ new Date()
              });
            }, ie.onmessage = function(he) {
              const ce = JSON.parse(he.data), { type: ue, status: L, data: $ } = Ur(
                ce,
                M[Q]
              );
              if (ue === "update" && L && !Z)
                w({
                  type: "status",
                  endpoint: O,
                  fn_index: Q,
                  time: /* @__PURE__ */ new Date(),
                  ...L
                }), L.stage === "error" && ie.close();
              else if (ue === "hash") {
                ie.send(JSON.stringify({ fn_index: Q, session_hash: x }));
                return;
              } else
                ue === "data" ? ie.send(JSON.stringify({ ...b, session_hash: x })) : ue === "complete" ? Z = L : ue === "log" ? w({
                  type: "log",
                  log: $.log,
                  level: $.level,
                  endpoint: O,
                  fn_index: Q
                }) : ue === "generating" && w({
                  type: "status",
                  time: /* @__PURE__ */ new Date(),
                  ...L,
                  stage: L == null ? void 0 : L.stage,
                  queue: !0,
                  endpoint: O,
                  fn_index: Q
                });
              $ && (w({
                type: "data",
                time: /* @__PURE__ */ new Date(),
                data: v ? Bi(
                  $.data,
                  k,
                  H.root,
                  H.root_url
                ) : $.data,
                endpoint: O,
                fn_index: Q
              }), Z && (w({
                type: "status",
                time: /* @__PURE__ */ new Date(),
                ...Z,
                stage: L == null ? void 0 : L.stage,
                queue: !0,
                endpoint: O,
                fn_index: Q
              }), ie.close()));
            }, Br(H.version || "2.0.0", "3.6") < 0 && addEventListener(
              "open",
              () => ie.send(JSON.stringify({ hash: x }))
            );
          } else {
            w({
              type: "status",
              stage: "pending",
              queue: !0,
              endpoint: O,
              fn_index: Q,
              time: /* @__PURE__ */ new Date()
            });
            var J = new URLSearchParams({
              fn_index: Q.toString(),
              session_hash: x
            }).toString();
            let oe = new URL(
              `${D}//${Mt(
                N,
                H.path,
                !0
              )}/queue/join?${C ? C + "&" : ""}${J}`
            );
            R = new EventSource(oe), R.onmessage = async function(he) {
              const ce = JSON.parse(he.data), { type: ue, status: L, data: $ } = Ur(
                ce,
                M[Q]
              );
              if (ue === "update" && L && !Z)
                w({
                  type: "status",
                  endpoint: O,
                  fn_index: Q,
                  time: /* @__PURE__ */ new Date(),
                  ...L
                }), L.stage === "error" && R.close();
              else if (ue === "data") {
                y = ce.event_id;
                let [Ce, l] = await n(
                  `${D}//${Mt(
                    N,
                    H.path,
                    !0
                  )}/queue/data`,
                  {
                    ...b,
                    session_hash: x,
                    event_id: y
                  },
                  h
                );
                l !== 200 && (w({
                  type: "status",
                  stage: "error",
                  message: vn,
                  queue: !0,
                  endpoint: O,
                  fn_index: Q,
                  time: /* @__PURE__ */ new Date()
                }), R.close());
              } else
                ue === "complete" ? Z = L : ue === "log" ? w({
                  type: "log",
                  log: $.log,
                  level: $.level,
                  endpoint: O,
                  fn_index: Q
                }) : ue === "generating" && w({
                  type: "status",
                  time: /* @__PURE__ */ new Date(),
                  ...L,
                  stage: L == null ? void 0 : L.stage,
                  queue: !0,
                  endpoint: O,
                  fn_index: Q
                });
              $ && (w({
                type: "data",
                time: /* @__PURE__ */ new Date(),
                data: v ? Bi(
                  $.data,
                  k,
                  H.root,
                  H.root_url
                ) : $.data,
                endpoint: O,
                fn_index: Q
              }), Z && (w({
                type: "status",
                time: /* @__PURE__ */ new Date(),
                ...Z,
                stage: L == null ? void 0 : L.stage,
                queue: !0,
                endpoint: O,
                fn_index: Q
              }), R.close()));
            };
          }
        });
        function w(ee) {
          const oe = U[ee.type] || [];
          oe == null || oe.forEach((he) => he(ee));
        }
        function T(ee, J) {
          const oe = U, he = oe[ee] || [];
          return oe[ee] = he, he == null || he.push(J), { on: T, off: X, cancel: G, destroy: z };
        }
        function X(ee, J) {
          const oe = U;
          let he = oe[ee] || [];
          return he = he == null ? void 0 : he.filter((ce) => ce !== J), oe[ee] = he, { on: T, off: X, cancel: G, destroy: z };
        }
        async function G() {
          const ee = {
            stage: "complete",
            queue: !1,
            time: /* @__PURE__ */ new Date()
          };
          Z = ee, w({
            ...ee,
            type: "status",
            endpoint: O,
            fn_index: Q
          });
          let J = {};
          ye === "ws" ? (ie && ie.readyState === 0 ? ie.addEventListener("open", () => {
            ie.close();
          }) : ie.close(), J = { fn_index: Q, session_hash: x }) : (R.close(), J = { event_id: y });
          try {
            await e(
              `${D}//${Mt(
                N,
                H.path,
                !0
              )}/reset`,
              {
                headers: { "Content-Type": "application/json" },
                method: "POST",
                body: JSON.stringify(J)
              }
            );
          } catch {
            console.warn(
              "The `/reset` endpoint could not be called. Subsequent endpoint results may be unreliable."
            );
          }
        }
        function z() {
          for (const ee in U)
            U[ee].forEach((J) => {
              X(ee, J);
            });
        }
        return {
          on: T,
          off: X,
          cancel: G,
          destroy: z
        };
      }
      async function Re(P, Y, le) {
        var pe;
        const Q = { "Content-Type": "application/json" };
        h && (Q.Authorization = `Bearer ${h}`);
        let k, ie = H.components.find(
          (O) => O.id === P
        );
        (pe = ie == null ? void 0 : ie.props) != null && pe.root_url ? k = ie.props.root_url : k = `${D}//${Mt(
          N,
          H.path,
          !0
        )}/`;
        const R = await e(
          `${k}component_server/`,
          {
            method: "POST",
            body: JSON.stringify({
              data: le,
              component_id: P,
              fn_name: Y,
              session_hash: x
            }),
            headers: Q
          }
        );
        if (!R.ok)
          throw new Error(
            "Could not connect to component server: " + R.statusText
          );
        return await R.json();
      }
      async function Ee(P) {
        if (fe)
          return fe;
        const Y = { "Content-Type": "application/json" };
        h && (Y.Authorization = `Bearer ${h}`);
        let le;
        if (Br(P.version || "2.0.0", "3.30") < 0 ? le = await e(
          "https://gradio-space-api-fetcher-v2.hf.space/api",
          {
            method: "POST",
            body: JSON.stringify({
              serialize: !1,
              config: JSON.stringify(P)
            }),
            headers: Y
          }
        ) : le = await e(`${P.root}/info`, {
          headers: Y
        }), !le.ok)
          throw new Error(vn);
        let pe = await le.json();
        return "api" in pe && (pe = pe.api), pe.named_endpoints["/predict"] && !pe.unnamed_endpoints[0] && (pe.unnamed_endpoints[0] = pe.named_endpoints["/predict"]), ju(pe, P, A);
      }
    });
  }
  async function o(a, s, u, f) {
    const h = await Ji(
      s,
      void 0,
      [],
      !0,
      u
    );
    return Promise.all(
      h.map(async ({ path: p, blob: g, type: v }) => {
        if (g) {
          const B = (await i(a, [g], f)).files[0];
          return { path: p, file_url: B, type: v, name: g == null ? void 0 : g.name };
        }
        return { path: p, type: v };
      })
    ).then((p) => (p.forEach(({ path: g, file_url: v, type: B, name: D }) => {
      if (B === "Gallery")
        kr(s, v, g);
      else if (v) {
        const N = new Zt({ path: v, orig_name: D });
        kr(s, N, g);
      }
    }), s));
  }
}
const { post_data: om, upload_files: qu, client: am, handle_blob: sm } = zu(
  fetch,
  (...e) => new WebSocket(...e)
);
function Bi(e, t, n, i) {
  return e.map((r, o) => {
    var a, s, u, f;
    return ((s = (a = t == null ? void 0 : t.returns) == null ? void 0 : a[o]) == null ? void 0 : s.component) === "File" ? dt(r, n, i) : ((f = (u = t == null ? void 0 : t.returns) == null ? void 0 : u[o]) == null ? void 0 : f.component) === "Gallery" ? r.map((h) => Array.isArray(h) ? [dt(h[0], n, i), h[1]] : [dt(h, n, i), null]) : typeof r == "object" && r.path ? dt(r, n, i) : r;
  });
}
function Or(e, t, n, i) {
  switch (e.type) {
    case "string":
      return "string";
    case "boolean":
      return "boolean";
    case "number":
      return "number";
  }
  if (n === "JSONSerializable" || n === "StringSerializable")
    return "any";
  if (n === "ListStringSerializable")
    return "string[]";
  if (t === "Image")
    return i === "parameter" ? "Blob | File | Buffer" : "string";
  if (n === "FileSerializable")
    return (e == null ? void 0 : e.type) === "array" ? i === "parameter" ? "(Blob | File | Buffer)[]" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}[]" : i === "parameter" ? "Blob | File | Buffer" : "{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}";
  if (n === "GallerySerializable")
    return i === "parameter" ? "[(Blob | File | Buffer), (string | null)][]" : "[{ name: string; data: string; size?: number; is_file?: boolean; orig_name?: string}, (string | null))][]";
}
function Hr(e, t) {
  return t === "GallerySerializable" ? "array of [file, label] tuples" : t === "ListStringSerializable" ? "array of strings" : t === "FileSerializable" ? "array of files or single file" : e.description;
}
function ju(e, t, n) {
  const i = {
    named_endpoints: {},
    unnamed_endpoints: {}
  };
  for (const r in e) {
    const o = e[r];
    for (const a in o) {
      const s = t.dependencies[a] ? a : n[a.replace("/", "")], u = o[a];
      i[r][a] = {}, i[r][a].parameters = {}, i[r][a].returns = {}, i[r][a].type = t.dependencies[s].types, i[r][a].parameters = u.parameters.map(
        ({ label: f, component: h, type: p, serializer: g }) => ({
          label: f,
          component: h,
          type: Or(p, h, g, "parameter"),
          description: Hr(p, g)
        })
      ), i[r][a].returns = u.returns.map(
        ({ label: f, component: h, type: p, serializer: g }) => ({
          label: f,
          component: h,
          type: Or(p, h, g, "return"),
          description: Hr(p, g)
        })
      );
    }
  }
  return i;
}
async function Xu(e, t) {
  try {
    return (await (await fetch(`https://huggingface.co/api/spaces/${e}/jwt`, {
      headers: {
        Authorization: `Bearer ${t}`
      }
    })).json()).token || !1;
  } catch (n) {
    return console.error(n), !1;
  }
}
function kr(e, t, n) {
  for (; n.length > 1; )
    e = e[n.shift()];
  e[n.shift()] = t;
}
async function Ji(e, t = void 0, n = [], i = !1, r = void 0) {
  if (Array.isArray(e)) {
    let o = [];
    return await Promise.all(
      e.map(async (a, s) => {
        var u;
        let f = n.slice();
        f.push(s);
        const h = await Ji(
          e[s],
          i ? ((u = r == null ? void 0 : r.parameters[s]) == null ? void 0 : u.component) || void 0 : t,
          f,
          !1,
          r
        );
        o = o.concat(h);
      })
    ), o;
  } else {
    if (globalThis.Buffer && e instanceof globalThis.Buffer)
      return [
        {
          path: n,
          blob: t === "Image" ? !1 : new ta([e]),
          type: t
        }
      ];
    if (typeof e == "object") {
      let o = [];
      for (let a in e)
        if (e.hasOwnProperty(a)) {
          let s = n.slice();
          s.push(a), o = o.concat(
            await Ji(
              e[a],
              void 0,
              s,
              !1,
              r
            )
          );
        }
      return o;
    }
  }
  return [];
}
function Vu(e, t) {
  var n, i, r, o;
  return !(((i = (n = t == null ? void 0 : t.dependencies) == null ? void 0 : n[e]) == null ? void 0 : i.queue) === null ? t.enable_queue : (o = (r = t == null ? void 0 : t.dependencies) == null ? void 0 : r[e]) != null && o.queue) || !1;
}
async function Dr(e, t, n) {
  const i = {};
  if (n && (i.Authorization = `Bearer ${n}`), typeof window < "u" && window.gradio_config && location.origin !== "http://localhost:9876" && !window.gradio_config.dev_mode) {
    const r = window.gradio_config.root, o = window.gradio_config;
    return o.root = Mt(t, o.root, !1), { ...o, path: r };
  } else if (t) {
    let r = await e(`${t}/config`, {
      headers: i
    });
    if (r.status === 200) {
      const o = await r.json();
      return o.path = o.path ?? "", o.root = t, o;
    }
    throw new Error("Could not get config.");
  }
  throw new Error("No config or app endpoint found");
}
async function Qi(e, t, n) {
  let i = t === "subdomain" ? `https://huggingface.co/api/spaces/by-subdomain/${e}` : `https://huggingface.co/api/spaces/${e}`, r, o;
  try {
    if (r = await fetch(i), o = r.status, o !== 200)
      throw new Error();
    r = await r.json();
  } catch {
    n({
      status: "error",
      load_status: "error",
      message: "Could not get space status",
      detail: "NOT_FOUND"
    });
    return;
  }
  if (!r || o !== 200)
    return;
  const {
    runtime: { stage: a },
    id: s
  } = r;
  switch (a) {
    case "STOPPED":
    case "SLEEPING":
      n({
        status: "sleeping",
        load_status: "pending",
        message: "Space is asleep. Waking it up...",
        detail: a
      }), setTimeout(() => {
        Qi(e, t, n);
      }, 1e3);
      break;
    case "PAUSED":
      n({
        status: "paused",
        load_status: "error",
        message: "This space has been paused by the author. If you would like to try this demo, consider duplicating the space.",
        detail: a,
        discussions_enabled: await Nr(s)
      });
      break;
    case "RUNNING":
    case "RUNNING_BUILDING":
      n({
        status: "running",
        load_status: "complete",
        message: "",
        detail: a
      });
      break;
    case "BUILDING":
      n({
        status: "building",
        load_status: "pending",
        message: "Space is building...",
        detail: a
      }), setTimeout(() => {
        Qi(e, t, n);
      }, 1e3);
      break;
    default:
      n({
        status: "space_error",
        load_status: "error",
        message: "This space is experiencing an issue.",
        detail: a,
        discussions_enabled: await Nr(s)
      });
      break;
  }
}
function Ur(e, t) {
  switch (e.msg) {
    case "send_data":
      return { type: "data" };
    case "send_hash":
      return { type: "hash" };
    case "queue_full":
      return {
        type: "update",
        status: {
          queue: !0,
          message: Gu,
          stage: "error",
          code: e.code,
          success: e.success
        }
      };
    case "estimation":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: t || "pending",
          code: e.code,
          size: e.queue_size,
          position: e.rank,
          eta: e.rank_eta,
          success: e.success
        }
      };
    case "progress":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: e.code,
          progress_data: e.progress_data,
          success: e.success
        }
      };
    case "log":
      return { type: "log", data: e };
    case "process_generating":
      return {
        type: "generating",
        status: {
          queue: !0,
          message: e.success ? null : e.output.error,
          stage: e.success ? "generating" : "error",
          code: e.code,
          progress_data: e.progress_data,
          eta: e.average_duration
        },
        data: e.success ? e.output : null
      };
    case "process_completed":
      return "error" in e.output ? {
        type: "update",
        status: {
          queue: !0,
          message: e.output.error,
          stage: "error",
          code: e.code,
          success: e.success
        }
      } : {
        type: "complete",
        status: {
          queue: !0,
          message: e.success ? void 0 : e.output.error,
          stage: e.success ? "complete" : "error",
          code: e.code,
          progress_data: e.progress_data,
          eta: e.output.average_duration
        },
        data: e.success ? e.output : null
      };
    case "process_starts":
      return {
        type: "update",
        status: {
          queue: !0,
          stage: "pending",
          code: e.code,
          size: e.rank,
          position: 0,
          success: e.success
        }
      };
  }
  return { type: "none", status: { stage: "error", queue: !0 } };
}
window.libpannellum = function(e, t, n) {
  function i(h) {
    function p(b, y) {
      return b.level == 1 && y.level != 1 ? -1 : y.level == 1 && b.level != 1 ? 1 : y.timestamp - b.timestamp;
    }
    function g(b, y) {
      return b.level != y.level ? b.level - y.level : b.diff - y.diff;
    }
    function v(b, y, Z, U, C, w) {
      this.vertices = b, this.side = y, this.level = Z, this.x = U, this.y = C, this.path = w.replace("%s", y).replace("%l", Z).replace("%x", U).replace("%y", C);
    }
    function B(b, y, Z, U, C) {
      var w, G = y.vertices;
      w = M(b, G.slice(0, 3));
      var T = M(b, G.slice(3, 6)), X = M(b, G.slice(6, 9)), G = M(b, G.slice(
        9,
        12
      )), z = w[0] + T[0] + X[0] + G[0];
      if (z == -4 || z == 4 ? w = !1 : (z = w[1] + T[1] + X[1] + G[1], w = z == -4 || z == 4 ? !1 : w[2] + T[2] + X[2] + G[2] != 4), w) {
        for (w = y.vertices, T = w[0] + w[3] + w[6] + w[9], X = w[1] + w[4] + w[7] + w[10], G = w[2] + w[5] + w[8] + w[11], z = Math.sqrt(T * T + X * X + G * G), G = Math.asin(G / z), T = Math.atan2(X, T) - U, T += T > Math.PI ? -2 * Math.PI : T < -Math.PI ? 2 * Math.PI : 0, T = Math.abs(T), y.diff = Math.acos(Math.sin(Z) * Math.sin(G) + Math.cos(Z) * Math.cos(G) * Math.cos(T)), T = !1, X = 0; X < E.nodeCache.length; X++)
          if (E.nodeCache[X].path == y.path) {
            T = !0, E.nodeCache[X].timestamp = E.nodeCacheTimestamp++, E.nodeCache[X].diff = y.diff, E.currentNodes.push(E.nodeCache[X]);
            break;
          }
        if (T || (y.timestamp = E.nodeCacheTimestamp++, E.currentNodes.push(y), E.nodeCache.push(y)), y.level < E.level) {
          var G = P.cubeResolution * Math.pow(2, y.level - P.maxLevel), T = Math.ceil(G * P.invTileResolution) - 1, X = G % P.tileResolution * 2, ee = 2 * G % P.tileResolution;
          ee === 0 && (ee = P.tileResolution), X === 0 && (X = 2 * P.tileResolution), z = 0.5, (y.x == T || y.y == T) && (z = 1 - P.tileResolution / (P.tileResolution + ee));
          var J = 1 - z, G = [], oe = z, he = z, ce = z, ue = J, L = J, $ = J;
          for (ee < P.tileResolution && (y.x == T && y.y != T ? (L = he = 0.5, (y.side == "d" || y.side == "u") && ($ = ce = 0.5)) : y.x != T && y.y == T && (ue = oe = 0.5, y.side == "l" || y.side == "r") && ($ = ce = 0.5)), X <= P.tileResolution && (y.x == T && (oe = 0, ue = 1, y.side == "l" || y.side == "r") && (ce = 0, $ = 1), y.y == T && (he = 0, L = 1, y.side == "d" || y.side == "u") && (ce = 0, $ = 1)), ee = [w[0], w[1], w[2], w[0] * oe + w[3] * ue, w[1] * z + w[4] * J, w[2] * ce + w[5] * $, w[0] * oe + w[6] * ue, w[1] * he + w[7] * L, w[2] * ce + w[8] * $, w[0] * z + w[9] * J, w[1] * he + w[10] * L, w[2] * ce + w[11] * $], ee = new v(ee, y.side, y.level + 1, 2 * y.x, 2 * y.y, P.fullpath), G.push(ee), y.x == T && X <= P.tileResolution || (ee = [w[0] * oe + w[3] * ue, w[1] * z + w[4] * J, w[2] * ce + w[5] * $, w[3], w[4], w[5], w[3] * z + w[6] * J, w[4] * he + w[7] * L, w[5] * ce + w[8] * $, w[0] * oe + w[6] * ue, w[1] * he + w[7] * L, w[2] * ce + w[8] * $], ee = new v(ee, y.side, y.level + 1, 2 * y.x + 1, 2 * y.y, P.fullpath), G.push(ee)), y.x == T && X <= P.tileResolution || y.y == T && X <= P.tileResolution || (ee = [w[0] * oe + w[6] * ue, w[1] * he + w[7] * L, w[2] * ce + w[8] * $, w[3] * z + w[6] * J, w[4] * he + w[7] * L, w[5] * ce + w[8] * $, w[6], w[7], w[8], w[9] * oe + w[6] * ue, w[10] * z + w[7] * J, w[11] * ce + w[8] * $], ee = new v(ee, y.side, y.level + 1, 2 * y.x + 1, 2 * y.y + 1, P.fullpath), G.push(ee)), y.y == T && X <= P.tileResolution || (ee = [w[0] * z + w[9] * J, w[1] * he + w[10] * L, w[2] * ce + w[11] * $, w[0] * oe + w[6] * ue, w[1] * he + w[7] * L, w[2] * ce + w[8] * $, w[9] * oe + w[6] * ue, w[10] * z + w[7] * J, w[11] * ce + w[8] * $, w[9], w[10], w[11]], ee = new v(ee, y.side, y.level + 1, 2 * y.x, 2 * y.y + 1, P.fullpath), G.push(ee)), y = 0; y < G.length; y++)
            B(b, G[y], Z, U);
        }
      }
    }
    function D() {
      return [-1, 1, -1, 1, 1, -1, 1, -1, -1, -1, -1, -1, 1, 1, 1, -1, 1, 1, -1, -1, 1, 1, -1, 1, -1, 1, 1, 1, 1, 1, 1, 1, -1, -1, 1, -1, -1, -1, -1, 1, -1, -1, 1, -1, 1, -1, -1, 1, -1, 1, 1, -1, 1, -1, -1, -1, -1, -1, -1, 1, 1, 1, -1, 1, 1, 1, 1, -1, 1, 1, -1, -1];
    }
    function N(b, y, Z) {
      var U = Math.sin(y);
      if (y = Math.cos(y), Z == "x")
        return [b[0], y * b[1] + U * b[2], y * b[2] - U * b[1], b[3], y * b[4] + U * b[5], y * b[5] - U * b[4], b[6], y * b[7] + U * b[8], y * b[8] - U * b[7]];
      if (Z == "y")
        return [y * b[0] - U * b[2], b[1], y * b[2] + U * b[0], y * b[3] - U * b[5], b[4], y * b[5] + U * b[3], y * b[6] - U * b[8], b[7], y * b[8] + U * b[6]];
      if (Z == "z")
        return [y * b[0] + U * b[1], y * b[1] - U * b[0], b[2], y * b[3] + U * b[4], y * b[4] - U * b[3], b[5], y * b[6] + U * b[7], y * b[7] - U * b[6], b[8]];
    }
    function K(b) {
      return [b[0], b[4], b[8], b[12], b[1], b[5], b[9], b[13], b[2], b[6], b[10], b[14], b[3], b[7], b[11], b[15]];
    }
    function x(b) {
      O(
        b,
        b.path + "." + P.extension,
        function(y, Z) {
          b.texture = y, b.textureLoaded = Z ? 2 : 1;
        },
        R.crossOrigin
      );
    }
    function M(b, y) {
      var C = [b[0] * y[0] + b[1] * y[1] + b[2] * y[2], b[4] * y[0] + b[5] * y[1] + b[6] * y[2], b[11] + b[8] * y[0] + b[9] * y[1] + b[10] * y[2], 1 / (b[12] * y[0] + b[13] * y[1] + b[14] * y[2])], Z = C[0] * C[3], U = C[1] * C[3], C = C[2] * C[3], w = [0, 0, 0];
      return -1 > Z && (w[0] = -1), 1 < Z && (w[0] = 1), -1 > U && (w[1] = -1), 1 < U && (w[1] = 1), (-1 > C || 1 < C) && (w[2] = 1), w;
    }
    function H() {
      console.log("Reducing canvas size due to error 1286!"), A.width = Math.round(A.width / 2), A.height = Math.round(A.height / 2);
    }
    var A = t.createElement("canvas");
    A.style.width = A.style.height = "100%", h.appendChild(A);
    var E, m, fe, be, ve, we, Re, Ee, P, Y, le, pe, Q, k, ie, R;
    this.init = function(b, y, Z, U, C, w, T, X) {
      function G(ue) {
        if (ee) {
          var L = ue * ue * 4, $ = new Uint8ClampedArray(L), Ce = X.backgroundColor ? X.backgroundColor : [0, 0, 0];
          Ce[0] *= 255, Ce[1] *= 255, Ce[2] *= 255;
          for (var l = 0; l < L; l++)
            $[l++] = Ce[0], $[l++] = Ce[1], $[l++] = Ce[2];
          for (ue = new ImageData($, ue, ue), z = 0; 6 > z; z++)
            P[z].width == 0 && (P[z] = ue);
        }
      }
      if (y === n && (y = "equirectangular"), y != "equirectangular" && y != "cubemap" && y != "multires")
        throw console.log("Error: invalid image type specified!"), { type: "config error" };
      if (Y = y, P = b, le = Z, R = X || {}, E) {
        if (fe && (m.detachShader(E, fe), m.deleteShader(fe)), be && (m.detachShader(E, be), m.deleteShader(be)), m.bindBuffer(m.ARRAY_BUFFER, null), m.bindBuffer(m.ELEMENT_ARRAY_BUFFER, null), E.texture && m.deleteTexture(E.texture), E.nodeCache)
          for (b = 0; b < E.nodeCache.length; b++)
            m.deleteTexture(E.nodeCache[b].texture);
        m.deleteProgram(E), E = n;
      }
      Ee = n;
      var z, ee = !1, J;
      if (Y == "cubemap")
        for (z = 0; 6 > z; z++)
          0 < P[z].width ? (J === n && (J = P[z].width), J != P[z].width && console.log("Cube faces have inconsistent widths: " + J + " vs. " + P[z].width)) : ee = !0;
      if (Y == "cubemap" && J & J - 1 && (navigator.userAgent.toLowerCase().match(/(iphone|ipod|ipad).* os 8_/) || navigator.userAgent.toLowerCase().match(/(iphone|ipod|ipad).* os 9_/) || navigator.userAgent.toLowerCase().match(/(iphone|ipod|ipad).* os 10_/) || navigator.userAgent.match(/Trident.*rv[ :]*11\./)) || (m || (m = A.getContext("experimental-webgl", { alpha: !1, depth: !1 })), m && m.getError() == 1286 && H()), !m && (Y == "multires" && P.hasOwnProperty("fallbackPath") || Y == "cubemap") && ("WebkitAppearance" in t.documentElement.style || navigator.userAgent.match(/Trident.*rv[ :]*11\./) || navigator.appVersion.indexOf("MSIE 10") !== -1)) {
        we && h.removeChild(we), we = t.createElement("div"), we.className = "pnlm-world", U = P.basePath ? P.basePath + P.fallbackPath : P.fallbackPath;
        var oe = "frblud".split(""), he = 0;
        C = function() {
          var L = t.createElement("canvas");
          L.className = "pnlm-face pnlm-" + oe[this.side] + "face", we.appendChild(L);
          var $ = L.getContext("2d");
          L.style.width = this.width + 4 + "px", L.style.height = this.height + 4 + "px", L.width = this.width + 4, L.height = this.height + 4, $.drawImage(this, 2, 2);
          var Ce = $.getImageData(0, 0, L.width, L.height), l = Ce.data, V, W;
          for (V = 2; V < L.width - 2; V++)
            for (W = 0; 4 > W; W++)
              l[4 * (V + L.width) + W] = l[4 * (V + 2 * L.width) + W], l[4 * (V + L.width * (L.height - 2)) + W] = l[4 * (V + L.width * (L.height - 3)) + W];
          for (V = 2; V < L.height - 2; V++)
            for (W = 0; 4 > W; W++)
              l[4 * (V * L.width + 1) + W] = l[4 * (V * L.width + 2) + W], l[4 * ((V + 1) * L.width - 2) + W] = l[4 * ((V + 1) * L.width - 3) + W];
          for (W = 0; 4 > W; W++)
            l[4 * (L.width + 1) + W] = l[4 * (2 * L.width + 2) + W], l[4 * (2 * L.width - 2) + W] = l[4 * (3 * L.width - 3) + W], l[4 * (L.width * (L.height - 2) + 1) + W] = l[4 * (L.width * (L.height - 3) + 2) + W], l[4 * (L.width * (L.height - 1) - 2) + W] = l[4 * (L.width * (L.height - 2) - 3) + W];
          for (V = 1; V < L.width - 1; V++)
            for (W = 0; 4 > W; W++)
              l[4 * V + W] = l[4 * (V + L.width) + W], l[4 * (V + L.width * (L.height - 1)) + W] = l[4 * (V + L.width * (L.height - 2)) + W];
          for (V = 1; V < L.height - 1; V++)
            for (W = 0; 4 > W; W++)
              l[V * L.width * 4 + W] = l[4 * (V * L.width + 1) + W], l[4 * ((V + 1) * L.width - 1) + W] = l[4 * ((V + 1) * L.width - 2) + W];
          for (W = 0; 4 > W; W++)
            l[W] = l[4 * (L.width + 1) + W], l[4 * (L.width - 1) + W] = l[4 * (2 * L.width - 2) + W], l[L.width * (L.height - 1) * 4 + W] = l[4 * (L.width * (L.height - 2) + 1) + W], l[4 * (L.width * L.height - 1) + W] = l[4 * (L.width * (L.height - 1) - 2) + W];
          $.putImageData(Ce, 0, 0), ce.call(this);
        };
        var ce = function() {
          0 < this.width ? (ve === n && (ve = this.width), ve != this.width && console.log("Fallback faces have inconsistent widths: " + ve + " vs. " + this.width)) : ee = !0, he++, he == 6 && (ve = this.width, h.appendChild(we), T());
        }, ee = !1;
        for (z = 0; 6 > z; z++)
          w = new Image(), w.crossOrigin = R.crossOrigin ? R.crossOrigin : "anonymous", w.side = z, w.onload = C, w.onerror = ce, w.src = Y == "multires" ? U.replace("%s", oe[z]) + "." + P.extension : P[z].src;
        G(ve);
      } else {
        if (!m)
          throw console.log("Error: no WebGL support detected!"), { type: "no webgl" };
        for (Y == "cubemap" && G(J), P.fullpath = P.basePath ? P.basePath + P.path : P.path, P.invTileResolution = 1 / P.tileResolution, b = D(), Re = [], z = 0; 6 > z; z++)
          Re[z] = b.slice(12 * z, 12 * z + 12), b = D();
        if (b = 0, Y == "equirectangular") {
          if (b = m.getParameter(m.MAX_TEXTURE_SIZE), Math.max(P.width / 2, P.height) > b)
            throw console.log("Error: The image is too big; it's " + P.width + "px wide, but this device's maximum supported size is " + 2 * b + "px."), { type: "webgl size error", width: P.width, maxWidth: 2 * b };
        } else if (Y == "cubemap" && J > m.getParameter(m.MAX_CUBE_MAP_TEXTURE_SIZE))
          throw console.log("Error: The image is too big; it's " + J + "px wide, but this device's maximum supported size is " + b + "px."), { type: "webgl size error", width: J, maxWidth: b };
        if (X === n || X.horizonPitch === n && X.horizonRoll === n || (Ee = [X.horizonPitch == n ? 0 : X.horizonPitch, X.horizonRoll == n ? 0 : X.horizonRoll]), J = m.TEXTURE_2D, m.viewport(0, 0, m.drawingBufferWidth, m.drawingBufferHeight), m.getShaderPrecisionFormat && (y = m.getShaderPrecisionFormat(m.FRAGMENT_SHADER, m.HIGH_FLOAT)) && 1 > y.precision && (a = a.replace("highp", "mediump")), fe = m.createShader(m.VERTEX_SHADER), y = r, Y == "multires" && (y = o), m.shaderSource(fe, y), m.compileShader(fe), be = m.createShader(m.FRAGMENT_SHADER), y = u, Y == "cubemap" ? (J = m.TEXTURE_CUBE_MAP, y = s) : Y == "multires" && (y = f), m.shaderSource(be, y), m.compileShader(be), E = m.createProgram(), m.attachShader(E, fe), m.attachShader(E, be), m.linkProgram(E), m.getShaderParameter(fe, m.COMPILE_STATUS) || console.log(m.getShaderInfoLog(fe)), m.getShaderParameter(be, m.COMPILE_STATUS) || console.log(m.getShaderInfoLog(be)), m.getProgramParameter(E, m.LINK_STATUS) || console.log(m.getProgramInfoLog(E)), m.useProgram(E), E.drawInProgress = !1, y = X.backgroundColor ? X.backgroundColor : [0, 0, 0], m.clearColor(y[0], y[1], y[2], 1), m.clear(m.COLOR_BUFFER_BIT), E.texCoordLocation = m.getAttribLocation(E, "a_texCoord"), m.enableVertexAttribArray(E.texCoordLocation), Y != "multires" ? (pe || (pe = m.createBuffer()), m.bindBuffer(m.ARRAY_BUFFER, pe), m.bufferData(m.ARRAY_BUFFER, new Float32Array([-1, 1, 1, 1, 1, -1, -1, 1, 1, -1, -1, -1]), m.STATIC_DRAW), m.vertexAttribPointer(E.texCoordLocation, 2, m.FLOAT, !1, 0, 0), E.aspectRatio = m.getUniformLocation(E, "u_aspectRatio"), m.uniform1f(E.aspectRatio, m.drawingBufferWidth / m.drawingBufferHeight), E.psi = m.getUniformLocation(E, "u_psi"), E.theta = m.getUniformLocation(E, "u_theta"), E.f = m.getUniformLocation(E, "u_f"), E.h = m.getUniformLocation(E, "u_h"), E.v = m.getUniformLocation(E, "u_v"), E.vo = m.getUniformLocation(E, "u_vo"), E.rot = m.getUniformLocation(E, "u_rot"), m.uniform1f(E.h, U / (2 * Math.PI)), m.uniform1f(E.v, C / Math.PI), m.uniform1f(E.vo, w / Math.PI * 2), Y == "equirectangular" && (E.backgroundColor = m.getUniformLocation(E, "u_backgroundColor"), m.uniform4fv(
          E.backgroundColor,
          y.concat([1])
        )), E.texture = m.createTexture(), m.bindTexture(J, E.texture), Y == "cubemap" ? (m.texImage2D(m.TEXTURE_CUBE_MAP_POSITIVE_X, 0, m.RGB, m.RGB, m.UNSIGNED_BYTE, P[1]), m.texImage2D(m.TEXTURE_CUBE_MAP_NEGATIVE_X, 0, m.RGB, m.RGB, m.UNSIGNED_BYTE, P[3]), m.texImage2D(m.TEXTURE_CUBE_MAP_POSITIVE_Y, 0, m.RGB, m.RGB, m.UNSIGNED_BYTE, P[4]), m.texImage2D(m.TEXTURE_CUBE_MAP_NEGATIVE_Y, 0, m.RGB, m.RGB, m.UNSIGNED_BYTE, P[5]), m.texImage2D(m.TEXTURE_CUBE_MAP_POSITIVE_Z, 0, m.RGB, m.RGB, m.UNSIGNED_BYTE, P[0]), m.texImage2D(
          m.TEXTURE_CUBE_MAP_NEGATIVE_Z,
          0,
          m.RGB,
          m.RGB,
          m.UNSIGNED_BYTE,
          P[2]
        )) : P.width <= b ? (m.uniform1i(m.getUniformLocation(E, "u_splitImage"), 0), m.texImage2D(J, 0, m.RGB, m.RGB, m.UNSIGNED_BYTE, P)) : (m.uniform1i(m.getUniformLocation(E, "u_splitImage"), 1), U = t.createElement("canvas"), U.width = P.width / 2, U.height = P.height, U = U.getContext("2d"), U.drawImage(P, 0, 0), C = U.getImageData(0, 0, P.width / 2, P.height), m.texImage2D(J, 0, m.RGB, m.RGB, m.UNSIGNED_BYTE, C), E.texture2 = m.createTexture(), m.activeTexture(m.TEXTURE1), m.bindTexture(J, E.texture2), m.uniform1i(m.getUniformLocation(
          E,
          "u_image1"
        ), 1), U.drawImage(P, -P.width / 2, 0), C = U.getImageData(0, 0, P.width / 2, P.height), m.texImage2D(J, 0, m.RGB, m.RGB, m.UNSIGNED_BYTE, C), m.texParameteri(J, m.TEXTURE_WRAP_S, m.CLAMP_TO_EDGE), m.texParameteri(J, m.TEXTURE_WRAP_T, m.CLAMP_TO_EDGE), m.texParameteri(J, m.TEXTURE_MIN_FILTER, m.LINEAR), m.texParameteri(J, m.TEXTURE_MAG_FILTER, m.LINEAR), m.activeTexture(m.TEXTURE0)), m.texParameteri(J, m.TEXTURE_WRAP_S, m.CLAMP_TO_EDGE), m.texParameteri(J, m.TEXTURE_WRAP_T, m.CLAMP_TO_EDGE), m.texParameteri(
          J,
          m.TEXTURE_MIN_FILTER,
          m.LINEAR
        ), m.texParameteri(J, m.TEXTURE_MAG_FILTER, m.LINEAR)) : (E.vertPosLocation = m.getAttribLocation(E, "a_vertCoord"), m.enableVertexAttribArray(E.vertPosLocation), Q || (Q = m.createBuffer()), k || (k = m.createBuffer()), ie || (ie = m.createBuffer()), m.bindBuffer(m.ARRAY_BUFFER, k), m.bufferData(m.ARRAY_BUFFER, new Float32Array([0, 0, 1, 0, 1, 1, 0, 1]), m.STATIC_DRAW), m.bindBuffer(m.ELEMENT_ARRAY_BUFFER, ie), m.bufferData(m.ELEMENT_ARRAY_BUFFER, new Uint16Array([0, 1, 2, 0, 2, 3]), m.STATIC_DRAW), E.perspUniform = m.getUniformLocation(
          E,
          "u_perspMatrix"
        ), E.cubeUniform = m.getUniformLocation(E, "u_cubeMatrix"), E.level = -1, E.currentNodes = [], E.nodeCache = [], E.nodeCacheTimestamp = 0), U = m.getError(), U !== 0)
          throw console.log("Error: Something went wrong with WebGL!", U), { type: "webgl error" };
        T();
      }
    }, this.destroy = function() {
      if (h !== n && (A !== n && h.contains(A) && h.removeChild(A), we !== n && h.contains(we) && h.removeChild(we)), m) {
        var b = m.getExtension("WEBGL_lose_context");
        b && b.loseContext();
      }
    }, this.resize = function() {
      var b = e.devicePixelRatio || 1;
      A.width = A.clientWidth * b, A.height = A.clientHeight * b, m && (m.getError() == 1286 && H(), m.viewport(0, 0, m.drawingBufferWidth, m.drawingBufferHeight), Y != "multires" && m.uniform1f(E.aspectRatio, A.clientWidth / A.clientHeight));
    }, this.resize(), this.setPose = function(b, y) {
      Ee = [b, y];
    }, this.render = function(b, y, Z, U) {
      var C, w = 0;
      if (U === n && (U = {}), U.roll && (w = U.roll), Ee !== n) {
        C = Ee[0];
        var T = Ee[1], X = b, G = y, z = Math.cos(T) * Math.sin(b) * Math.sin(C) + Math.cos(b) * (Math.cos(C) * Math.cos(y) + Math.sin(T) * Math.sin(C) * Math.sin(y)), ee = -Math.sin(b) * Math.sin(T) + Math.cos(b) * Math.cos(T) * Math.sin(y);
        b = Math.cos(T) * Math.cos(C) * Math.sin(b) + Math.cos(b) * (-Math.cos(y) * Math.sin(C) + Math.cos(C) * Math.sin(T) * Math.sin(y)), b = Math.asin(Math.max(Math.min(b, 1), -1)), y = Math.atan2(ee, z), C = [Math.cos(X) * (Math.sin(T) * Math.sin(C) * Math.cos(G) - Math.cos(C) * Math.sin(G)), Math.cos(X) * Math.cos(T) * Math.cos(G), Math.cos(X) * (Math.cos(C) * Math.sin(T) * Math.cos(G) + Math.sin(G) * Math.sin(C))], T = [-Math.cos(b) * Math.sin(y), Math.cos(b) * Math.cos(y)], T = Math.acos(Math.max(Math.min((C[0] * T[0] + C[1] * T[1]) / (Math.sqrt(C[0] * C[0] + C[1] * C[1] + C[2] * C[2]) * Math.sqrt(T[0] * T[0] + T[1] * T[1])), 1), -1)), 0 > C[2] && (T = 2 * Math.PI - T), w += T;
      }
      if (m || Y != "multires" && Y != "cubemap") {
        if (Y != "multires")
          Z = 2 * Math.atan(Math.tan(0.5 * Z) / (m.drawingBufferWidth / m.drawingBufferHeight)), Z = 1 / Math.tan(0.5 * Z), m.uniform1f(E.psi, y), m.uniform1f(E.theta, b), m.uniform1f(E.rot, w), m.uniform1f(E.f, Z), le === !0 && Y == "equirectangular" && (m.bindTexture(m.TEXTURE_2D, E.texture), m.texImage2D(m.TEXTURE_2D, 0, m.RGB, m.RGB, m.UNSIGNED_BYTE, P)), m.drawArrays(m.TRIANGLES, 0, 6);
        else {
          for (C = m.drawingBufferWidth / m.drawingBufferHeight, T = 2 * Math.atan(Math.tan(Z / 2) * m.drawingBufferHeight / m.drawingBufferWidth), T = 1 / Math.tan(T / 2), C = [T / C, 0, 0, 0, 0, T, 0, 0, 0, 0, 100.1 / -99.9, 20 / -99.9, 0, 0, -1, 0], T = 1; T < P.maxLevel && m.drawingBufferWidth > P.tileResolution * Math.pow(2, T - 1) * Math.tan(Z / 2) * 0.707; )
            T++;
          if (E.level = T, T = [1, 0, 0, 0, 1, 0, 0, 0, 1], T = N(T, -w, "z"), T = N(T, -b, "x"), T = N(T, y, "y"), T = [T[0], T[1], T[2], 0, T[3], T[4], T[5], 0, T[6], T[7], T[8], 0, 0, 0, 0, 1], m.uniformMatrix4fv(E.perspUniform, !1, new Float32Array(K(C))), m.uniformMatrix4fv(
            E.cubeUniform,
            !1,
            new Float32Array(K(T))
          ), w = [C[0] * T[0], C[0] * T[1], C[0] * T[2], 0, C[5] * T[4], C[5] * T[5], C[5] * T[6], 0, C[10] * T[8], C[10] * T[9], C[10] * T[10], C[11], -T[8], -T[9], -T[10], 0], E.nodeCache.sort(p), 200 < E.nodeCache.length && E.nodeCache.length > E.currentNodes.length + 50)
            for (C = E.nodeCache.splice(200, E.nodeCache.length - 200), T = 0; T < C.length; T++)
              m.deleteTexture(C[T].texture);
          for (E.currentNodes = [], T = "fbudlr".split(""), C = 0; 6 > C; C++)
            X = new v(Re[C], T[C], 1, 0, 0, P.fullpath), B(w, X, b, y);
          for (E.currentNodes.sort(g), b = ye.length - 1; 0 <= b; b--)
            E.currentNodes.indexOf(ye[b].node) === -1 && (ye[b].node.textureLoad = !1, ye.splice(b, 1));
          if (ye.length === 0) {
            for (b = 0; b < E.currentNodes.length; b++)
              if (y = E.currentNodes[b], !y.texture && !y.textureLoad) {
                y.textureLoad = !0, setTimeout(x, 0, y);
                break;
              }
          }
          if (!E.drawInProgress) {
            for (E.drawInProgress = !0, m.clear(m.COLOR_BUFFER_BIT), b = 0; b < E.currentNodes.length; b++)
              1 < E.currentNodes[b].textureLoaded && (m.bindBuffer(m.ARRAY_BUFFER, Q), m.bufferData(m.ARRAY_BUFFER, new Float32Array(E.currentNodes[b].vertices), m.STATIC_DRAW), m.vertexAttribPointer(
                E.vertPosLocation,
                3,
                m.FLOAT,
                !1,
                0,
                0
              ), m.bindBuffer(m.ARRAY_BUFFER, k), m.vertexAttribPointer(E.texCoordLocation, 2, m.FLOAT, !1, 0, 0), m.bindTexture(m.TEXTURE_2D, E.currentNodes[b].texture), m.drawElements(m.TRIANGLES, 6, m.UNSIGNED_SHORT, 0));
            E.drawInProgress = !1;
          }
        }
        if (U.returnImage !== n)
          return A.toDataURL("image/png");
      } else
        for (C = ve / 2, U = {
          f: "translate3d(-" + (C + 2) + "px, -" + (C + 2) + "px, -" + C + "px)",
          b: "translate3d(" + (C + 2) + "px, -" + (C + 2) + "px, " + C + "px) rotateX(180deg) rotateZ(180deg)",
          u: "translate3d(-" + (C + 2) + "px, -" + C + "px, " + (C + 2) + "px) rotateX(270deg)",
          d: "translate3d(-" + (C + 2) + "px, " + C + "px, -" + (C + 2) + "px) rotateX(90deg)",
          l: "translate3d(-" + C + "px, -" + (C + 2) + "px, " + (C + 2) + "px) rotateX(180deg) rotateY(90deg) rotateZ(180deg)",
          r: "translate3d(" + C + "px, -" + (C + 2) + "px, -" + (C + 2) + "px) rotateY(270deg)"
        }, Z = 1 / Math.tan(Z / 2), Z = Z * A.clientWidth / 2 + "px", y = "perspective(" + Z + ") translateZ(" + Z + ") rotateX(" + b + "rad) rotateY(" + y + "rad) ", Z = Object.keys(U), b = 0; 6 > b; b++)
          (w = we.querySelector(".pnlm-" + Z[b] + "face")) && (w.style.webkitTransform = y + U[Z[b]], w.style.transform = y + U[Z[b]]);
    }, this.isLoading = function() {
      if (m && Y == "multires") {
        for (var b = 0; b < E.currentNodes.length; b++)
          if (!E.currentNodes[b].textureLoaded)
            return !0;
      }
      return !1;
    }, this.getCanvas = function() {
      return A;
    };
    var ye = [], O = function() {
      function b() {
        var T = this;
        this.texture = this.callback = null, this.image = new Image(), this.image.crossOrigin = C || "anonymous";
        var X = function() {
          if (0 < T.image.width && 0 < T.image.height) {
            var G = T.image;
            m.bindTexture(m.TEXTURE_2D, T.texture), m.texImage2D(m.TEXTURE_2D, 0, m.RGB, m.RGB, m.UNSIGNED_BYTE, G), m.texParameteri(
              m.TEXTURE_2D,
              m.TEXTURE_MAG_FILTER,
              m.LINEAR
            ), m.texParameteri(m.TEXTURE_2D, m.TEXTURE_MIN_FILTER, m.LINEAR), m.texParameteri(m.TEXTURE_2D, m.TEXTURE_WRAP_S, m.CLAMP_TO_EDGE), m.texParameteri(m.TEXTURE_2D, m.TEXTURE_WRAP_T, m.CLAMP_TO_EDGE), m.bindTexture(m.TEXTURE_2D, null), T.callback(T.texture, !0);
          } else
            T.callback(T.texture, !1);
          ye.length ? (G = ye.shift(), T.loadTexture(G.src, G.texture, G.callback)) : U[Z++] = T;
        };
        this.image.addEventListener("load", X), this.image.addEventListener("error", X);
      }
      function y(T, X, G, z) {
        this.node = T, this.src = X, this.texture = G, this.callback = z;
      }
      var Z = 4, U = {}, C;
      b.prototype.loadTexture = function(T, X, G) {
        this.texture = X, this.callback = G, this.image.src = T;
      };
      for (var w = 0; w < Z; w++)
        U[w] = new b();
      return function(T, X, G, z) {
        return C = z, z = m.createTexture(), Z ? U[--Z].loadTexture(X, z, G) : ye.push(new y(T, X, z, G)), z;
      };
    }();
  }
  var r = "attribute vec2 a_texCoord;varying vec2 v_texCoord;void main() {gl_Position = vec4(a_texCoord, 0.0, 1.0);v_texCoord = a_texCoord;}", o = "attribute vec3 a_vertCoord;attribute vec2 a_texCoord;uniform mat4 u_cubeMatrix;uniform mat4 u_perspMatrix;varying mediump vec2 v_texCoord;void main(void) {gl_Position = u_perspMatrix * u_cubeMatrix * vec4(a_vertCoord, 1.0);v_texCoord = a_texCoord;}", a = `precision highp float;
uniform float u_aspectRatio;
uniform float u_psi;
uniform float u_theta;
uniform float u_f;
uniform float u_h;
uniform float u_v;
uniform float u_vo;
uniform float u_rot;
const float PI = 3.14159265358979323846264;
uniform sampler2D u_image0;
uniform sampler2D u_image1;
uniform bool u_splitImage;
uniform samplerCube u_imageCube;
varying vec2 v_texCoord;
uniform vec4 u_backgroundColor;
void main() {
float x = v_texCoord.x * u_aspectRatio;
float y = v_texCoord.y;
float sinrot = sin(u_rot);
float cosrot = cos(u_rot);
float rot_x = x * cosrot - y * sinrot;
float rot_y = x * sinrot + y * cosrot;
float sintheta = sin(u_theta);
float costheta = cos(u_theta);
float a = u_f * costheta - rot_y * sintheta;
float root = sqrt(rot_x * rot_x + a * a);
float lambda = atan(rot_x / root, a / root) + u_psi;
float phi = atan((rot_y * costheta + u_f * sintheta) / root);`, s = a + `float cosphi = cos(phi);
gl_FragColor = textureCube(u_imageCube, vec3(cosphi*sin(lambda), sin(phi), cosphi*cos(lambda)));
}`, u = a + `lambda = mod(lambda + PI, PI * 2.0) - PI;
vec2 coord = vec2(lambda / PI, phi / (PI / 2.0));
if(coord.x < -u_h || coord.x > u_h || coord.y < -u_v + u_vo || coord.y > u_v + u_vo)
gl_FragColor = u_backgroundColor;
else {
if(u_splitImage) {
if(coord.x < 0.0)
gl_FragColor = texture2D(u_image0, vec2((coord.x + u_h) / u_h, (-coord.y + u_v + u_vo) / (u_v * 2.0)));
else
gl_FragColor = texture2D(u_image1, vec2((coord.x + u_h) / u_h - 1.0, (-coord.y + u_v + u_vo) / (u_v * 2.0)));
} else {
gl_FragColor = texture2D(u_image0, vec2((coord.x + u_h) / (u_h * 2.0), (-coord.y + u_v + u_vo) / (u_v * 2.0)));
}
}
}`, f = "varying mediump vec2 v_texCoord;uniform sampler2D u_sampler;void main(void) {gl_FragColor = texture2D(u_sampler, v_texCoord);}";
  return { renderer: function(h, p, g, v) {
    return new i(h);
  } };
}(window, document);
window.pannellum = function(e, t, n) {
  function i(r, o) {
    function a() {
      var c = t.createElement("div");
      if (c.innerHTML = "<!--[if lte IE 9]><i></i><![endif]-->", c.getElementsByTagName("i").length == 1)
        h();
      else {
        xt = l.hfov, pn = l.pitch;
        var d;
        if (l.type == "cubemap") {
          for (De = [], c = 0; 6 > c; c++)
            De.push(new Image()), De[c].crossOrigin = l.crossOrigin;
          q.load.lbox.style.display = "block", q.load.lbar.style.display = "none";
        } else if (l.type == "multires")
          c = JSON.parse(JSON.stringify(l.multiRes)), l.basePath && l.multiRes.basePath && !/^(?:[a-z]+:)?\/\//i.test(l.multiRes.basePath) ? c.basePath = l.basePath + l.multiRes.basePath : l.multiRes.basePath ? c.basePath = l.multiRes.basePath : l.basePath && (c.basePath = l.basePath), De = c;
        else if (l.dynamic === !0)
          De = l.panorama;
        else {
          if (l.panorama === n) {
            h(l.strings.noPanoramaError);
            return;
          }
          De = new Image();
        }
        if (l.type == "cubemap")
          for (var _ = 6, S = function() {
            _--, _ === 0 && u();
          }, I = function(et) {
            var Ue = t.createElement("a");
            Ue.href = et.target.src, Ue.textContent = Ue.href, h(l.strings.fileAccessError.replace("%s", Ue.outerHTML));
          }, c = 0; c < De.length; c++)
            d = l.cubeMap[c], d == "null" ? (console.log("Will use background instead of missing cubemap face " + c), S()) : (l.basePath && !s(d) && (d = l.basePath + d), De[c].onload = S, De[c].onerror = I, De[c].src = ue(d));
        else if (l.type == "multires")
          u();
        else if (d = "", l.basePath && (d = l.basePath), l.dynamic !== !0) {
          d = s(l.panorama) ? l.panorama : d + l.panorama, De.onload = function() {
            e.URL.revokeObjectURL(this.src), u();
          };
          var F = new XMLHttpRequest();
          F.onloadend = function() {
            if (F.status != 200) {
              var te = t.createElement("a");
              te.href = d, te.textContent = te.href, h(l.strings.fileAccessError.replace("%s", te.outerHTML));
            }
            f(this.response), q.load.msg.innerHTML = "";
          }, F.onprogress = function(te) {
            if (te.lengthComputable) {
              q.load.lbarFill.style.width = te.loaded / te.total * 100 + "%";
              var et, Ue;
              1e6 < te.total ? (et = "MB", Ue = (te.loaded / 1e6).toFixed(2), te = (te.total / 1e6).toFixed(2)) : 1e3 < te.total ? (et = "kB", Ue = (te.loaded / 1e3).toFixed(1), te = (te.total / 1e3).toFixed(1)) : (et = "B", Ue = te.loaded, te = te.total), q.load.msg.innerHTML = Ue + " / " + te + " " + et;
            } else
              q.load.lbox.style.display = "block", q.load.lbar.style.display = "none";
          };
          try {
            F.open("GET", d, !0);
          } catch {
            h(l.strings.malformedURLError);
          }
          F.responseType = "blob", F.setRequestHeader(
            "Accept",
            "image/*,*/*;q=0.9"
          ), F.withCredentials = l.crossOrigin === "use-credentials", F.send();
        }
        l.draggable && Ie.classList.add("pnlm-grab"), Ie.classList.remove("pnlm-grabbing"), kn = l.dynamicUpdate === !0, l.dynamic && kn && (De = l.panorama, u());
      }
    }
    function s(c) {
      return /^(?:[a-z]+:)?\/\//i.test(c) || c[0] == "/" || c.slice(0, 5) == "blob:";
    }
    function u() {
      V || (V = new libpannellum.renderer(Le)), mi || (mi = !0, We.addEventListener("mousedown", v, !1), t.addEventListener("mousemove", N, !1), t.addEventListener("mouseup", K, !1), l.mouseZoom && (Ie.addEventListener(
        "mousewheel",
        fe,
        !1
      ), Ie.addEventListener("DOMMouseScroll", fe, !1)), l.doubleClickZoom && We.addEventListener("dblclick", B, !1), r.addEventListener("mozfullscreenchange", T, !1), r.addEventListener("webkitfullscreenchange", T, !1), r.addEventListener("msfullscreenchange", T, !1), r.addEventListener("fullscreenchange", T, !1), e.addEventListener("resize", Y, !1), e.addEventListener("orientationchange", Y, !1), l.disableKeyboardCtrl || (r.addEventListener("keydown", be, !1), r.addEventListener("keyup", we, !1), r.addEventListener("blur", ve, !1)), t.addEventListener(
        "mouseleave",
        K,
        !1
      ), t.documentElement.style.pointerAction === "" && t.documentElement.style.touchAction === "" ? (We.addEventListener("pointerdown", A, !1), We.addEventListener("pointermove", E, !1), We.addEventListener("pointerup", m, !1), We.addEventListener("pointerleave", m, !1)) : (We.addEventListener("touchstart", x, !1), We.addEventListener("touchmove", M, !1), We.addEventListener("touchend", H, !1)), e.navigator.pointerEnabled && (r.style.touchAction = "none")), R(), G(l.hfov), setTimeout(function() {
      }, 500);
    }
    function f(c) {
      var d = new FileReader();
      d.addEventListener("loadend", function() {
        var _ = d.result;
        if (navigator.userAgent.toLowerCase().match(/(iphone|ipod|ipad).* os 8_/)) {
          var S = _.indexOf("ÿÂ");
          (0 > S || 65536 < S) && h(l.strings.iOS8WebGLError);
        }
        if (S = _.indexOf("<x:xmpmeta"), -1 < S && l.ignoreGPanoXMP !== !0) {
          var I = _.substring(S, _.indexOf("</x:xmpmeta>") + 12), He = function(Gt) {
            var st;
            return 0 <= I.indexOf(Gt + '="') ? (st = I.substring(I.indexOf(Gt + '="') + Gt.length + 2), st = st.substring(0, st.indexOf('"'))) : 0 <= I.indexOf(Gt + ">") && (st = I.substring(I.indexOf(Gt + ">") + Gt.length + 1), st = st.substring(
              0,
              st.indexOf("<")
            )), st !== n ? Number(st) : null;
          }, _ = He("GPano:FullPanoWidthPixels"), S = He("GPano:CroppedAreaImageWidthPixels"), F = He("GPano:FullPanoHeightPixels"), te = He("GPano:CroppedAreaImageHeightPixels"), et = He("GPano:CroppedAreaTopPixels"), Ue = He("GPano:PoseHeadingDegrees"), tt = He("GPano:PosePitchDegrees"), He = He("GPano:PoseRollDegrees");
          _ !== null && S !== null && F !== null && te !== null && et !== null && (0 > at.indexOf("haov") && (l.haov = S / _ * 360), 0 > at.indexOf("vaov") && (l.vaov = te / F * 180), 0 > at.indexOf("vOffset") && (l.vOffset = -180 * ((et + te / 2) / F - 0.5)), Ue !== null && 0 > at.indexOf("northOffset") && (l.northOffset = Ue, l.compass !== !1 && (l.compass = !0)), tt !== null && He !== null && (0 > at.indexOf("horizonPitch") && (l.horizonPitch = tt), 0 > at.indexOf("horizonRoll") && (l.horizonRoll = He)));
        }
        De.src = e.URL.createObjectURL(c);
      }), d.readAsBinaryString !== n ? d.readAsBinaryString(c) : d.readAsText(c);
    }
    function h(c) {
      c === n && (c = l.strings.genericWebGLError), q.errorMsg.innerHTML = "<p>" + c + "</p>", ne.load.style.display = "none", q.load.box.style.display = "none", q.errorMsg.style.display = "table", On = !0, Se = n, Le.style.display = "none", $("error", c);
    }
    function p(c) {
      var d = g(c);
      ft.style.left = d.x + "px", ft.style.top = d.y + "px", clearTimeout(p.t1), clearTimeout(p.t2), ft.style.display = "block", ft.style.opacity = 1, p.t1 = setTimeout(function() {
        ft.style.opacity = 0;
      }, 2e3), p.t2 = setTimeout(function() {
        ft.style.display = "none";
      }, 2500), c.preventDefault();
    }
    function g(c) {
      var d = r.getBoundingClientRect(), _ = {};
      return _.x = (c.clientX || c.pageX) - d.left, _.y = (c.clientY || c.pageY) - d.top, _;
    }
    function v(c) {
      if (c.preventDefault(), r.focus(), Se && l.draggable) {
        var d = g(c);
        if (l.hotSpotDebug) {
          var _ = D(c);
          console.log("Pitch: " + _[0] + ", Yaw: " + _[1] + ", Center Pitch: " + l.pitch + ", Center Yaw: " + l.yaw + ", HFOV: " + l.hfov);
        }
        z(), oe(), l.roll = 0, re.hfov = 0, bt = !0, Ne = Date.now(), dn = d.x, mn = d.y, Bn = l.yaw, Nn = l.pitch, Ie.classList.add("pnlm-grabbing"), Ie.classList.remove("pnlm-grab"), $("mousedown", c), le();
      }
    }
    function B(c) {
      l.minHfov === l.hfov ? Ce.setHfov(xt, 1e3) : (c = D(c), Ce.lookAt(c[0], c[1], l.minHfov, 1e3));
    }
    function D(c) {
      var I = g(c);
      c = V.getCanvas();
      var F = c.clientWidth, te = c.clientHeight;
      c = I.x / F * 2 - 1;
      var te = (1 - I.y / te * 2) * te / F, d = 1 / Math.tan(l.hfov * Math.PI / 360), _ = Math.sin(l.pitch * Math.PI / 180), S = Math.cos(l.pitch * Math.PI / 180), I = d * S - te * _, F = Math.sqrt(c * c + I * I), te = 180 * Math.atan((te * S + d * _) / F) / Math.PI;
      return c = 180 * Math.atan2(c / F, I / F) / Math.PI + l.yaw, -180 > c && (c += 360), 180 < c && (c -= 360), [te, c];
    }
    function N(c) {
      if (bt && Se) {
        Ne = Date.now();
        var _ = V.getCanvas(), d = _.clientWidth, _ = _.clientHeight;
        c = g(c);
        var S = 180 * (Math.atan(dn / d * 2 - 1) - Math.atan(c.x / d * 2 - 1)) / Math.PI * l.hfov / 90 + Bn;
        re.yaw = (S - l.yaw) % 360 * 0.2, l.yaw = S, d = 360 * Math.atan(Math.tan(l.hfov / 360 * Math.PI) * _ / d) / Math.PI, d = 180 * (Math.atan(c.y / _ * 2 - 1) - Math.atan(mn / _ * 2 - 1)) / Math.PI * d / 90 + Nn, re.pitch = 0.2 * (d - l.pitch), l.pitch = d;
      }
    }
    function K(c) {
      bt && (bt = !1, 15 < Date.now() - Ne && (re.pitch = re.yaw = 0), Ie.classList.add("pnlm-grab"), Ie.classList.remove("pnlm-grabbing"), Ne = Date.now(), $("mouseup", c));
    }
    function x(c) {
      if (Se && l.draggable) {
        z(), oe(), l.roll = 0, re.hfov = 0;
        var d = g(c.targetTouches[0]);
        if (dn = d.x, mn = d.y, c.targetTouches.length == 2) {
          var _ = g(c.targetTouches[1]);
          dn += 0.5 * (_.x - d.x), mn += 0.5 * (_.y - d.y), _n = Math.sqrt((d.x - _.x) * (d.x - _.x) + (d.y - _.y) * (d.y - _.y));
        }
        bt = !0, Ne = Date.now(), Bn = l.yaw, Nn = l.pitch, $("touchstart", c), le();
      }
    }
    function M(c) {
      if (l.draggable && (c.preventDefault(), Se && (Ne = Date.now()), bt && Se)) {
        var d = g(c.targetTouches[0]), _ = d.x, S = d.y;
        c.targetTouches.length == 2 && _n != -1 && (c = g(c.targetTouches[1]), _ += 0.5 * (c.x - d.x), S += 0.5 * (c.y - d.y), d = Math.sqrt((d.x - c.x) * (d.x - c.x) + (d.y - c.y) * (d.y - c.y)), G(l.hfov + 0.1 * (_n - d)), _n = d), d = l.hfov / 360 * l.touchPanSpeedCoeffFactor, _ = (dn - _) * d + Bn, re.yaw = (_ - l.yaw) % 360 * 0.2, l.yaw = _, S = (S - mn) * d + Nn, re.pitch = 0.2 * (S - l.pitch), l.pitch = S;
      }
    }
    function H() {
      bt = !1, 150 < Date.now() - Ne && (re.pitch = re.yaw = 0), _n = -1, Ne = Date.now(), $("touchend", event);
    }
    function A(c) {
      c.pointerType == "touch" && Se && l.draggable && (vt.push(c.pointerId), Ft.push({ clientX: c.clientX, clientY: c.clientY }), c.targetTouches = Ft, x(c), c.preventDefault());
    }
    function E(c) {
      if (c.pointerType == "touch" && l.draggable) {
        for (var d = 0; d < vt.length; d++)
          if (c.pointerId == vt[d]) {
            Ft[d].clientX = c.clientX, Ft[d].clientY = c.clientY, c.targetTouches = Ft, M(c), c.preventDefault();
            break;
          }
      }
    }
    function m(c) {
      if (c.pointerType == "touch") {
        for (var d = !1, _ = 0; _ < vt.length; _++)
          c.pointerId == vt[_] && (vt[_] = n), vt[_] && (d = !0);
        d || (vt = [], Ft = [], H()), c.preventDefault();
      }
    }
    function fe(c) {
      Se && (l.mouseZoom != "fullscreenonly" || Ut) && (c.preventDefault(), z(), Ne = Date.now(), c.wheelDeltaY ? (G(l.hfov - 0.05 * c.wheelDeltaY), re.hfov = 0 > c.wheelDelta ? 1 : -1) : c.wheelDelta ? (G(l.hfov - 0.05 * c.wheelDelta), re.hfov = 0 > c.wheelDelta ? 1 : -1) : c.detail && (G(l.hfov + 1.5 * c.detail), re.hfov = 0 < c.detail ? 1 : -1), le());
    }
    function be(c) {
      z(), Ne = Date.now(), oe(), l.roll = 0;
      var d = c.which || c.keycode;
      0 > l.capturedKeyNumbers.indexOf(d) || (c.preventDefault(), d == 27 ? Ut && w() : Re(d, !0));
    }
    function ve() {
      for (var c = 0; 10 > c; c++)
        j[c] = !1;
    }
    function we(c) {
      var d = c.which || c.keycode;
      0 > l.capturedKeyNumbers.indexOf(d) || (c.preventDefault(), Re(d, !1));
    }
    function Re(c, d) {
      var _ = !1;
      switch (c) {
        case 109:
        case 189:
        case 17:
        case 173:
          j[0] != d && (_ = !0), j[0] = d;
          break;
        case 107:
        case 187:
        case 16:
        case 61:
          j[1] != d && (_ = !0), j[1] = d;
          break;
        case 38:
          j[2] != d && (_ = !0), j[2] = d;
          break;
        case 87:
          j[6] != d && (_ = !0), j[6] = d;
          break;
        case 40:
          j[3] != d && (_ = !0), j[3] = d;
          break;
        case 83:
          j[7] != d && (_ = !0), j[7] = d;
          break;
        case 37:
          j[4] != d && (_ = !0), j[4] = d;
          break;
        case 65:
          j[8] != d && (_ = !0), j[8] = d;
          break;
        case 39:
          j[5] != d && (_ = !0), j[5] = d;
          break;
        case 68:
          j[9] != d && (_ = !0), j[9] = d;
      }
      _ && d && (ot = typeof performance < "u" && performance.now() ? performance.now() : Date.now(), le());
    }
    function Ee() {
      if (Se) {
        var c = !1, d = l.pitch, _ = l.yaw, S = l.hfov, I;
        I = typeof performance < "u" && performance.now() ? performance.now() : Date.now(), ot === n && (ot = I);
        var F = (I - ot) * l.hfov / 1700, F = Math.min(F, 1);
        if (j[0] && l.keyboardZoom === !0 && (G(l.hfov + (0.8 * re.hfov + 0.5) * F), c = !0), j[1] && l.keyboardZoom === !0 && (G(l.hfov + (0.8 * re.hfov - 0.2) * F), c = !0), (j[2] || j[6]) && (l.pitch += (0.8 * re.pitch + 0.2) * F, c = !0), (j[3] || j[7]) && (l.pitch += (0.8 * re.pitch - 0.2) * F, c = !0), (j[4] || j[8]) && (l.yaw += (0.8 * re.yaw - 0.2) * F, c = !0), (j[5] || j[9]) && (l.yaw += (0.8 * re.yaw + 0.2) * F, c = !0), c && (Ne = Date.now()), l.autoRotate) {
          if (1e-3 < I - ot) {
            var c = (I - ot) / 1e3, te = (re.yaw / c * F - 0.2 * l.autoRotate) * c, te = (0 < -l.autoRotate ? 1 : -1) * Math.min(Math.abs(l.autoRotate * c), Math.abs(te));
            l.yaw += te;
          }
          l.autoRotateStopDelay && (l.autoRotateStopDelay -= I - ot, 0 >= l.autoRotateStopDelay && (l.autoRotateStopDelay = !1, $e = l.autoRotate, l.autoRotate = 0));
        }
        Oe.pitch && (P("pitch"), d = l.pitch), Oe.yaw && (P("yaw"), _ = l.yaw), Oe.hfov && (P("hfov"), S = l.hfov), 0 < F && !l.autoRotate && (c = 1 - l.friction, j[4] || j[5] || j[8] || j[9] || Oe.yaw || (l.yaw += re.yaw * F * c), j[2] || j[3] || j[6] || j[7] || Oe.pitch || (l.pitch += re.pitch * F * c), j[0] || j[1] || Oe.hfov || G(l.hfov + re.hfov * F * c)), ot = I, 0 < F && (re.yaw = 0.8 * re.yaw + (l.yaw - _) / F * 0.2, re.pitch = 0.8 * re.pitch + (l.pitch - d) / F * 0.2, re.hfov = 0.8 * re.hfov + (l.hfov - S) / F * 0.2, d = l.autoRotate ? Math.abs(l.autoRotate) : 5, re.yaw = Math.min(
          d,
          Math.max(re.yaw, -d)
        ), re.pitch = Math.min(d, Math.max(re.pitch, -d)), re.hfov = Math.min(d, Math.max(re.hfov, -d))), j[0] && j[1] && (re.hfov = 0), (j[2] || j[6]) && (j[3] || j[7]) && (re.pitch = 0), (j[4] || j[8]) && (j[5] || j[9]) && (re.yaw = 0);
      }
    }
    function P(c) {
      var d = Oe[c], _ = Math.min(1, Math.max((Date.now() - d.startTime) / 1e3 / (d.duration / 1e3), 0)), _ = d.startPosition + l.animationTimingFunction(_) * (d.endPosition - d.startPosition);
      (d.endPosition > d.startPosition && _ >= d.endPosition || d.endPosition < d.startPosition && _ <= d.endPosition || d.endPosition === d.startPosition) && (_ = d.endPosition, re[c] = 0, delete Oe[c]), l[c] = _;
    }
    function Y() {
      T("resize");
    }
    function le() {
      _i || (_i = !0, pe());
    }
    function pe() {
      if (!yr)
        if (Q(), Hn && clearTimeout(Hn), bt || Ke === !0)
          requestAnimationFrame(pe);
        else if (j[0] || j[1] || j[2] || j[3] || j[4] || j[5] || j[6] || j[7] || j[8] || j[9] || l.autoRotate || Oe.pitch || Oe.yaw || Oe.hfov || 0.01 < Math.abs(re.yaw) || 0.01 < Math.abs(re.pitch) || 0.01 < Math.abs(re.hfov))
          Ee(), 0 <= l.autoRotateInactivityDelay && $e && Date.now() - Ne > l.autoRotateInactivityDelay && !l.autoRotate && (l.autoRotate = $e, Ce.lookAt(pn, n, xt, 3e3)), requestAnimationFrame(pe);
        else if (V && (V.isLoading() || l.dynamic === !0 && kn))
          requestAnimationFrame(pe);
        else {
          $("animatefinished", { pitch: Ce.getPitch(), yaw: Ce.getYaw(), hfov: Ce.getHfov() }), _i = !1, ot = n;
          var c = l.autoRotateInactivityDelay - (Date.now() - Ne);
          0 < c ? Hn = setTimeout(function() {
            l.autoRotate = $e, Ce.lookAt(pn, n, xt, 3e3), le();
          }, c) : 0 <= l.autoRotateInactivityDelay && $e && (l.autoRotate = $e, Ce.lookAt(pn, n, xt, 3e3), le());
        }
    }
    function Q() {
      var c;
      if (Se) {
        var d = V.getCanvas();
        l.autoRotate !== !1 && (360 < l.yaw ? l.yaw -= 360 : -360 > l.yaw && (l.yaw += 360)), c = l.yaw;
        var _ = 0;
        if (l.avoidShowingBackground) {
          var S = l.hfov / 2, I = 180 * Math.atan2(Math.tan(S / 180 * Math.PI), d.width / d.height) / Math.PI;
          l.vaov > l.haov ? Math.min(Math.cos((l.pitch - S) / 180 * Math.PI), Math.cos((l.pitch + S) / 180 * Math.PI)) : _ = S * (1 - Math.min(Math.cos((l.pitch - I) / 180 * Math.PI), Math.cos((l.pitch + I) / 180 * Math.PI)));
        }
        var S = l.maxYaw - l.minYaw, I = -180, F = 180;
        360 > S && (I = l.minYaw + l.hfov / 2 + _, F = l.maxYaw - l.hfov / 2 - _, S < l.hfov && (I = F = (I + F) / 2), l.yaw = Math.max(I, Math.min(F, l.yaw))), l.autoRotate === !1 && (360 < l.yaw ? l.yaw -= 360 : -360 > l.yaw && (l.yaw += 360)), l.autoRotate !== !1 && c != l.yaw && ot !== n && (l.autoRotate *= -1), c = 2 * Math.atan(Math.tan(l.hfov / 180 * Math.PI * 0.5) / (d.width / d.height)) / Math.PI * 180, d = l.minPitch + c / 2, _ = l.maxPitch - c / 2, l.maxPitch - l.minPitch < c && (d = _ = (d + _) / 2), isNaN(d) && (d = -90), isNaN(_) && (_ = 90), l.pitch = Math.max(d, Math.min(_, l.pitch)), V.render(l.pitch * Math.PI / 180, l.yaw * Math.PI / 180, l.hfov * Math.PI / 180, { roll: l.roll * Math.PI / 180 }), l.hotSpots.forEach(Z), l.compass && (gn.style.transform = "rotate(" + (-l.yaw - l.northOffset) + "deg)", gn.style.webkitTransform = "rotate(" + (-l.yaw - l.northOffset) + "deg)");
      }
    }
    function k(c, d, _, S) {
      this.w = c, this.x = d, this.y = _, this.z = S;
    }
    function ie(c) {
      var d;
      d = c.alpha;
      var _ = c.beta;
      c = c.gamma, _ = [_ ? _ * Math.PI / 180 / 2 : 0, c ? c * Math.PI / 180 / 2 : 0, d ? d * Math.PI / 180 / 2 : 0], d = [Math.cos(_[0]), Math.cos(_[1]), Math.cos(_[2])], _ = [Math.sin(_[0]), Math.sin(_[1]), Math.sin(_[2])], d = new k(d[0] * d[1] * d[2] - _[0] * _[1] * _[2], _[0] * d[1] * d[2] - d[0] * _[1] * _[2], d[0] * _[1] * d[2] + _[0] * d[1] * _[2], d[0] * d[1] * _[2] + _[0] * _[1] * d[2]), d = d.multiply(new k(Math.sqrt(0.5), -Math.sqrt(0.5), 0, 0)), _ = e.orientation ? -e.orientation * Math.PI / 180 / 2 : 0, d = d.multiply(new k(Math.cos(_), 0, -Math.sin(_), 0)).toEulerAngles(), typeof Ke == "number" && 10 > Ke ? Ke += 1 : Ke === 10 ? (wr = d[2] / Math.PI * 180 + l.yaw, Ke = !0, requestAnimationFrame(pe)) : (l.pitch = d[0] / Math.PI * 180, l.roll = -d[1] / Math.PI * 180, l.yaw = -d[2] / Math.PI * 180 + wr);
    }
    function R() {
      try {
        var c = {};
        l.horizonPitch !== n && (c.horizonPitch = l.horizonPitch * Math.PI / 180), l.horizonRoll !== n && (c.horizonRoll = l.horizonRoll * Math.PI / 180), l.backgroundColor !== n && (c.backgroundColor = l.backgroundColor), V.init(
          De,
          l.type,
          l.dynamic,
          l.haov * Math.PI / 180,
          l.vaov * Math.PI / 180,
          l.vOffset * Math.PI / 180,
          ye,
          c
        ), l.dynamic !== !0 && (De = n);
      } catch (d) {
        if (d.type == "webgl error" || d.type == "no webgl")
          h();
        else if (d.type == "webgl size error")
          h(l.strings.textureSizeError.replace("%s", d.width).replace("%s", d.maxWidth));
        else
          throw h(l.strings.unknownError), d;
      }
    }
    function ye() {
      if (l.sceneFadeDuration && V.fadeImg !== n) {
        V.fadeImg.style.opacity = 0;
        var c = V.fadeImg;
        delete V.fadeImg, setTimeout(function() {
          Le.removeChild(c), $("scenechangefadedone");
        }, l.sceneFadeDuration);
      }
      gn.style.display = l.compass ? "inline" : "none", b(), q.load.box.style.display = "none", W !== n && (Le.removeChild(W), W = n), Se = !0, $("load"), le();
    }
    function O(c) {
      c.pitch = Number(c.pitch) || 0, c.yaw = Number(c.yaw) || 0;
      var d = t.createElement("div");
      d.className = "pnlm-hotspot-base", d.className = c.cssClass ? d.className + (" " + c.cssClass) : d.className + (" pnlm-hotspot pnlm-sprite pnlm-" + ce(c.type));
      var _ = t.createElement("span");
      c.text && (_.innerHTML = ce(c.text));
      var S;
      if (c.video) {
        S = t.createElement("video");
        var I = c.video;
        l.basePath && !s(I) && (I = l.basePath + I), S.src = ue(I), S.controls = !0, S.style.width = c.width + "px", Le.appendChild(d), _.appendChild(S);
      } else if (c.image) {
        I = c.image, l.basePath && !s(I) && (I = l.basePath + I), S = t.createElement("a"), S.href = ue(c.URL ? c.URL : I, !0), S.target = "_blank", _.appendChild(S);
        var F = t.createElement("img");
        F.src = ue(I), F.style.width = c.width + "px", F.style.paddingTop = "5px", Le.appendChild(d), S.appendChild(F), _.style.maxWidth = "initial";
      } else if (c.URL) {
        if (S = t.createElement("a"), S.href = ue(c.URL, !0), c.attributes)
          for (I in c.attributes)
            S.setAttribute(I, c.attributes[I]);
        else
          S.target = "_blank";
        Le.appendChild(S), d.className += " pnlm-pointer", _.className += " pnlm-pointer", S.appendChild(d);
      } else
        c.sceneId && (d.onclick = d.ontouchend = function() {
          return d.clicked || (d.clicked = !0, J(c.sceneId, c.targetPitch, c.targetYaw, c.targetHfov)), !1;
        }, d.className += " pnlm-pointer", _.className += " pnlm-pointer"), Le.appendChild(d);
      c.createTooltipFunc ? c.createTooltipFunc(d, c.createTooltipArgs) : (c.text || c.video || c.image) && (d.classList.add("pnlm-tooltip"), d.appendChild(_), _.style.width = _.scrollWidth - 20 + "px", _.style.marginLeft = -(_.scrollWidth - d.offsetWidth) / 2 + "px", _.style.marginTop = -_.scrollHeight - 12 + "px"), c.clickHandlerFunc && (d.addEventListener("click", function(te) {
        c.clickHandlerFunc(te, c.clickHandlerArgs);
      }, "false"), d.className += " pnlm-pointer", _.className += " pnlm-pointer"), c.div = d;
    }
    function b() {
      pi || (l.hotSpots ? (l.hotSpots = l.hotSpots.sort(function(c, d) {
        return c.pitch < d.pitch;
      }), l.hotSpots.forEach(O)) : l.hotSpots = [], pi = !0, l.hotSpots.forEach(Z));
    }
    function y() {
      var c = l.hotSpots;
      if (pi = !1, delete l.hotSpots, c)
        for (var d = 0; d < c.length; d++) {
          var _ = c[d].div;
          if (_) {
            for (; _.parentNode && _.parentNode != Le; )
              _ = _.parentNode;
            Le.removeChild(_);
          }
          delete c[d].div;
        }
    }
    function Z(c) {
      var d = Math.sin(c.pitch * Math.PI / 180), _ = Math.cos(c.pitch * Math.PI / 180), S = Math.sin(l.pitch * Math.PI / 180), I = Math.cos(l.pitch * Math.PI / 180), F = Math.cos((-c.yaw + l.yaw) * Math.PI / 180), te = d * S + _ * F * I;
      if (90 >= c.yaw && -90 < c.yaw && 0 >= te || (90 < c.yaw || -90 >= c.yaw) && 0 >= te)
        c.div.style.visibility = "hidden";
      else {
        var et = Math.sin((-c.yaw + l.yaw) * Math.PI / 180), Ue = Math.tan(l.hfov * Math.PI / 360);
        c.div.style.visibility = "visible";
        var He = V.getCanvas(), tt = He.clientWidth, He = He.clientHeight, d = [-tt / Ue * et * _ / te / 2, -tt / Ue * (d * I - _ * F * S) / te / 2], _ = Math.sin(l.roll * Math.PI / 180), S = Math.cos(l.roll * Math.PI / 180), d = [d[0] * S - d[1] * _, d[0] * _ + d[1] * S];
        d[0] += (tt - c.div.offsetWidth) / 2, d[1] += (He - c.div.offsetHeight) / 2, tt = "translate(" + d[0] + "px, " + d[1] + "px) translateZ(9999px) rotate(" + l.roll + "deg)", c.scale && (tt += " scale(" + xt / l.hfov / te + ")"), c.div.style.webkitTransform = tt, c.div.style.MozTransform = tt, c.div.style.transform = tt;
      }
    }
    function U(c) {
      l = {};
      var d, _, S = "haov vaov vOffset northOffset horizonPitch horizonRoll".split(" ");
      at = [];
      for (d in gi)
        gi.hasOwnProperty(d) && (l[d] = gi[d]);
      for (d in o.default)
        if (o.default.hasOwnProperty(d))
          if (d == "strings")
            for (_ in o.default.strings)
              o.default.strings.hasOwnProperty(_) && (l.strings[_] = ce(o.default.strings[_]));
          else
            l[d] = o.default[d], 0 <= S.indexOf(d) && at.push(d);
      if (c !== null && c !== "" && o.scenes && o.scenes[c]) {
        var I = o.scenes[c];
        for (d in I)
          if (I.hasOwnProperty(d))
            if (d == "strings")
              for (_ in I.strings)
                I.strings.hasOwnProperty(_) && (l.strings[_] = ce(I.strings[_]));
            else
              l[d] = I[d], 0 <= S.indexOf(d) && at.push(d);
        l.scene = c;
      }
      for (d in o)
        if (o.hasOwnProperty(d))
          if (d == "strings")
            for (_ in o.strings)
              o.strings.hasOwnProperty(_) && (l.strings[_] = ce(o.strings[_]));
          else
            l[d] = o[d], 0 <= S.indexOf(d) && at.push(d);
    }
    function C(c) {
      if ((c = c || !1) && "preview" in l) {
        var d = l.preview;
        l.basePath && !s(d) && (d = l.basePath + d), W = t.createElement("div"), W.className = "pnlm-preview-img", W.style.backgroundImage = "url('" + ue(d).replace(/"/g, "%22").replace(/'/g, "%27") + "')", Le.appendChild(W);
      }
      var d = l.title, _ = l.author;
      c && ("previewTitle" in l && (l.title = l.previewTitle), "previewAuthor" in l && (l.author = l.previewAuthor)), l.hasOwnProperty("title") || (q.title.innerHTML = ""), l.hasOwnProperty("author") || (q.author.innerHTML = ""), l.hasOwnProperty("title") || l.hasOwnProperty("author") || (q.container.style.display = "none"), ne.load.innerHTML = "<p>" + l.strings.loadButtonLabel + "</p>", q.load.boxp.innerHTML = l.strings.loadingLabel;
      for (var S in l)
        if (l.hasOwnProperty(S))
          switch (S) {
            case "title":
              q.title.innerHTML = ce(l[S]), q.container.style.display = "inline";
              break;
            case "author":
              var I = ce(l[S]);
              l.authorURL && (I = t.createElement("a"), I.href = ue(l.authorURL, !0), I.target = "_blank", I.innerHTML = ce(l[S]), I = I.outerHTML), q.author.innerHTML = l.strings.bylineLabel.replace("%s", I), q.container.style.display = "inline";
              break;
            case "fallback":
              I = t.createElement("a"), I.href = ue(l[S], !0), I.target = "_blank", I.textContent = "Click here to view this panorama in an alternative viewer.";
              var F = t.createElement("p");
              F.textContent = "Your browser does not support WebGL.", F.appendChild(t.createElement("br")), F.appendChild(I), q.errorMsg.innerHTML = "", q.errorMsg.appendChild(F);
              break;
            case "hfov":
              G(Number(l[S]));
              break;
            case "autoLoad":
              l[S] === !0 && V === n && (q.load.box.style.display = "inline", ne.load.style.display = "none", a());
              break;
            case "showZoomCtrl":
              ne.zoom.style.display = l[S] && l.showControls != !1 ? "block" : "none";
              break;
            case "showFullscreenCtrl":
              ne.fullscreen.style.display = l[S] && l.showControls != !1 && ("fullscreen" in t || "mozFullScreen" in t || "webkitIsFullScreen" in t || "msFullscreenElement" in t) ? "block" : "none";
              break;
            case "hotSpotDebug":
              bi.style.display = l[S] ? "block" : "none";
              break;
            case "showControls":
              l[S] || (ne.orientation.style.display = "none", ne.zoom.style.display = "none", ne.fullscreen.style.display = "none");
              break;
            case "orientationOnByDefault":
              l[S] && he();
          }
      c && (d ? l.title = d : delete l.title, _ ? l.author = _ : delete l.author);
    }
    function w() {
      if (Se && !On)
        if (Ut)
          t.exitFullscreen ? t.exitFullscreen() : t.mozCancelFullScreen ? t.mozCancelFullScreen() : t.webkitCancelFullScreen ? t.webkitCancelFullScreen() : t.msExitFullscreen && t.msExitFullscreen();
        else
          try {
            r.requestFullscreen ? r.requestFullscreen() : r.mozRequestFullScreen ? r.mozRequestFullScreen() : r.msRequestFullscreen ? r.msRequestFullscreen() : r.webkitRequestFullScreen();
          } catch {
          }
    }
    function T(c) {
      t.fullscreenElement || t.fullscreen || t.mozFullScreen || t.webkitIsFullScreen || t.msFullscreenElement ? (ne.fullscreen.classList.add("pnlm-fullscreen-toggle-button-active"), Ut = !0) : (ne.fullscreen.classList.remove("pnlm-fullscreen-toggle-button-active"), Ut = !1), c !== "resize" && $("fullscreenchange", Ut), V.resize(), G(l.hfov), le();
    }
    function X(c) {
      var d = l.minHfov;
      if (l.type == "multires" && V && !l.multiResMinHfov && (d = Math.min(d, V.getCanvas().width / (l.multiRes.cubeResolution / 90 * 0.9))), d > l.maxHfov)
        return console.log("HFOV bounds do not make sense (minHfov > maxHfov)."), l.hfov;
      var _ = l.hfov, _ = c < d ? d : c > l.maxHfov ? l.maxHfov : c;
      return l.avoidShowingBackground && V && (c = V.getCanvas(), _ = Math.min(_, 360 * Math.atan(Math.tan((l.maxPitch - l.minPitch) / 360 * Math.PI) / c.height * c.width) / Math.PI)), _;
    }
    function G(c) {
      l.hfov = X(c), $("zoomchange", l.hfov);
    }
    function z() {
      Oe = {}, $e = l.autoRotate ? l.autoRotate : $e, l.autoRotate = !1;
    }
    function ee() {
      On && (q.load.box.style.display = "none", q.errorMsg.style.display = "none", On = !1, Le.style.display = "block", $("errorcleared")), Se = !1, ne.load.style.display = "none", q.load.box.style.display = "inline", a();
    }
    function J(c, d, _, S, I) {
      Se || (I = !0), Se = !1, Oe = {};
      var F, te;
      if (l.sceneFadeDuration && !I && (F = V.render(l.pitch * Math.PI / 180, l.yaw * Math.PI / 180, l.hfov * Math.PI / 180, { returnImage: !0 }), F !== n)) {
        I = new Image(), I.className = "pnlm-fade-img", I.style.transition = "opacity " + l.sceneFadeDuration / 1e3 + "s", I.style.width = "100%", I.style.height = "100%", I.onload = function() {
          J(c, d, _, S, !0);
        }, I.src = F, Le.appendChild(I), V.fadeImg = I;
        return;
      }
      I = d === "same" ? l.pitch : d, F = _ === "same" ? l.yaw : _ === "sameAzimuth" ? l.yaw + (l.northOffset || 0) - (o.scenes[c].northOffset || 0) : _, te = S === "same" ? l.hfov : S, y(), U(c), re.yaw = re.pitch = re.hfov = 0, C(), I !== n && (l.pitch = I), F !== n && (l.yaw = F), te !== n && (l.hfov = te), $("scenechange", c), ee();
    }
    function oe() {
      e.removeEventListener("deviceorientation", ie), ne.orientation.classList.remove("pnlm-orientation-button-active"), Ke = !1;
    }
    function he() {
      typeof DeviceMotionEvent.requestPermission == "function" ? DeviceOrientationEvent.requestPermission().then(function(c) {
        c == "granted" && (Ke = 1, e.addEventListener("deviceorientation", ie), ne.orientation.classList.add("pnlm-orientation-button-active"));
      }) : (Ke = 1, e.addEventListener("deviceorientation", ie), ne.orientation.classList.add("pnlm-orientation-button-active"));
    }
    function ce(c) {
      return o.escapeHTML ? String(c).split(/&/g).join("&amp;").split('"').join("&quot;").split("'").join("&#39;").split("<").join("&lt;").split(">").join("&gt;").split("/").join("&#x2f;").split(`
`).join("<br>") : String(c).split(`
`).join("<br>");
    }
    function ue(c, d) {
      try {
        var _ = decodeURIComponent(L(c)).replace(/[^\w:]/g, "").toLowerCase();
      } catch {
        return "about:blank";
      }
      return _.indexOf("javascript:") === 0 || _.indexOf("vbscript:") === 0 ? (console.log("Script URL removed."), "about:blank") : d && _.indexOf("data:") === 0 ? (console.log("Data URI removed from link."), "about:blank") : c;
    }
    function L(c) {
      return c.replace(/&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig, function(d, _) {
        return _ = _.toLowerCase(), _ === "colon" ? ":" : _.charAt(0) === "#" ? _.charAt(1) === "x" ? String.fromCharCode(parseInt(_.substring(2), 16)) : String.fromCharCode(+_.substring(1)) : "";
      });
    }
    function $(c) {
      if (c in qe)
        for (var d = qe[c].length; 0 < d; d--)
          qe[c][qe[c].length - d].apply(null, [].slice.call(arguments, 1));
    }
    var Ce = this, l, V, W, bt = !1, Ne = Date.now(), dn = 0, mn = 0, _n = -1, Bn = 0, Nn = 0, j = Array(10), Ut = !1, Se, On = !1, mi = !1, De, ot, re = { yaw: 0, pitch: 0, hfov: 0 }, _i = !1, Ke = !1, wr = 0, Hn, $e = 0, xt, pn, Oe = {}, qe = {}, at = [], kn = !1, pi = !1, yr = !1, gi = {
      hfov: 100,
      minHfov: 50,
      multiResMinHfov: !1,
      maxHfov: 120,
      pitch: 0,
      minPitch: n,
      maxPitch: n,
      yaw: 0,
      minYaw: -180,
      maxYaw: 180,
      roll: 0,
      haov: 360,
      vaov: 180,
      vOffset: 0,
      autoRotate: !1,
      autoRotateInactivityDelay: -1,
      autoRotateStopDelay: n,
      type: "equirectangular",
      northOffset: 0,
      showFullscreenCtrl: !0,
      dynamic: !1,
      dynamicUpdate: !1,
      doubleClickZoom: !0,
      keyboardZoom: !0,
      mouseZoom: !0,
      showZoomCtrl: !0,
      autoLoad: !1,
      showControls: !0,
      orientationOnByDefault: !1,
      hotSpotDebug: !1,
      backgroundColor: [0, 0, 0],
      avoidShowingBackground: !1,
      animationTimingFunction: function(c) {
        return 0.5 > c ? 2 * c * c : -1 + (4 - 2 * c) * c;
      },
      draggable: !0,
      disableKeyboardCtrl: !1,
      crossOrigin: "anonymous",
      touchPanSpeedCoeffFactor: 1,
      capturedKeyNumbers: [16, 17, 27, 37, 38, 39, 40, 61, 65, 68, 83, 87, 107, 109, 173, 187, 189],
      friction: 0.15,
      strings: {
        loadButtonLabel: "Click to<br>Load<br>Panorama",
        loadingLabel: "Loading...",
        bylineLabel: "by %s",
        noPanoramaError: "No panorama image was specified.",
        fileAccessError: "The file %s could not be accessed.",
        malformedURLError: "There is something wrong with the panorama URL.",
        iOS8WebGLError: "Due to iOS 8's broken WebGL implementation, only progressive encoded JPEGs work for your device (this panorama uses standard encoding).",
        genericWebGLError: "Your browser does not have the necessary WebGL support to display this panorama.",
        textureSizeError: "This panorama is too big for your device! It's %spx wide, but your device only supports images up to %spx wide. Try another device. (If you're the author, try scaling down the image.)",
        unknownError: "Unknown error. Check developer console."
      }
    };
    r = typeof r == "string" ? t.getElementById(r) : r, r.classList.add("pnlm-container"), r.tabIndex = 0;
    var Ie = t.createElement("div");
    Ie.className = "pnlm-ui", r.appendChild(Ie);
    var Le = t.createElement("div");
    Le.className = "pnlm-render-container", r.appendChild(Le);
    var We = t.createElement("div");
    We.className = "pnlm-dragfix", Ie.appendChild(We);
    var ft = t.createElement("span");
    ft.className = "pnlm-about-msg", ft.innerHTML = '<a href="https://pannellum.org/" target="_blank">Pannellum</a> 2.5.6', Ie.appendChild(ft), We.addEventListener("contextmenu", p);
    var q = {}, bi = t.createElement("div");
    bi.className = "pnlm-sprite pnlm-hot-spot-debug-indicator", Ie.appendChild(bi), q.container = t.createElement("div"), q.container.className = "pnlm-panorama-info", q.title = t.createElement("div"), q.title.className = "pnlm-title-box", q.container.appendChild(q.title), q.author = t.createElement("div"), q.author.className = "pnlm-author-box", q.container.appendChild(q.author), Ie.appendChild(q.container), q.load = {}, q.load.box = t.createElement("div"), q.load.box.className = "pnlm-load-box", q.load.boxp = t.createElement("p"), q.load.box.appendChild(q.load.boxp), q.load.lbox = t.createElement("div"), q.load.lbox.className = "pnlm-lbox", q.load.lbox.innerHTML = '<div class="pnlm-loading"></div>', q.load.box.appendChild(q.load.lbox), q.load.lbar = t.createElement("div"), q.load.lbar.className = "pnlm-lbar", q.load.lbarFill = t.createElement("div"), q.load.lbarFill.className = "pnlm-lbar-fill", q.load.lbar.appendChild(q.load.lbarFill), q.load.box.appendChild(q.load.lbar), q.load.msg = t.createElement("p"), q.load.msg.className = "pnlm-lmsg", q.load.box.appendChild(q.load.msg), Ie.appendChild(q.load.box), q.errorMsg = t.createElement("div"), q.errorMsg.className = "pnlm-error-msg pnlm-info-box", Ie.appendChild(q.errorMsg);
    var ne = {};
    ne.container = t.createElement("div"), ne.container.className = "pnlm-controls-container", Ie.appendChild(ne.container), ne.load = t.createElement("div"), ne.load.className = "pnlm-load-button", ne.load.addEventListener("click", function() {
      C(), ee();
    }), Ie.appendChild(ne.load), ne.zoom = t.createElement("div"), ne.zoom.className = "pnlm-zoom-controls pnlm-controls", ne.zoomIn = t.createElement("div"), ne.zoomIn.className = "pnlm-zoom-in pnlm-sprite pnlm-control", ne.zoomIn.addEventListener("click", function() {
      Se && (G(l.hfov - 5), le());
    }), ne.zoom.appendChild(ne.zoomIn), ne.zoomOut = t.createElement("div"), ne.zoomOut.className = "pnlm-zoom-out pnlm-sprite pnlm-control", ne.zoomOut.addEventListener("click", function() {
      Se && (G(l.hfov + 5), le());
    }), ne.zoom.appendChild(ne.zoomOut), ne.container.appendChild(ne.zoom), ne.fullscreen = t.createElement("div"), ne.fullscreen.addEventListener("click", w), ne.fullscreen.className = "pnlm-fullscreen-toggle-button pnlm-sprite pnlm-fullscreen-toggle-button-inactive pnlm-controls pnlm-control", (t.fullscreenEnabled || t.mozFullScreenEnabled || t.webkitFullscreenEnabled || t.msFullscreenEnabled) && ne.container.appendChild(ne.fullscreen), ne.orientation = t.createElement("div"), ne.orientation.addEventListener("click", function(c) {
      Ke ? oe() : he();
    }), ne.orientation.addEventListener("mousedown", function(c) {
      c.stopPropagation();
    }), ne.orientation.addEventListener("touchstart", function(c) {
      c.stopPropagation();
    }), ne.orientation.addEventListener("pointerdown", function(c) {
      c.stopPropagation();
    }), ne.orientation.className = "pnlm-orientation-button pnlm-orientation-button-inactive pnlm-sprite pnlm-controls pnlm-control";
    var vi = !1;
    e.DeviceOrientationEvent && location.protocol == "https:" && 0 <= navigator.userAgent.toLowerCase().indexOf("mobi") && (ne.container.appendChild(ne.orientation), vi = !0);
    var gn = t.createElement("div");
    gn.className = "pnlm-compass pnlm-controls pnlm-control", Ie.appendChild(gn), o.firstScene ? U(o.firstScene) : o.default && o.default.firstScene ? U(o.default.firstScene) : U(null), C(!0);
    var vt = [], Ft = [];
    k.prototype.multiply = function(c) {
      return new k(this.w * c.w - this.x * c.x - this.y * c.y - this.z * c.z, this.x * c.w + this.w * c.x + this.y * c.z - this.z * c.y, this.y * c.w + this.w * c.y + this.z * c.x - this.x * c.z, this.z * c.w + this.w * c.z + this.x * c.y - this.y * c.x);
    }, k.prototype.toEulerAngles = function() {
      var c = Math.atan2(2 * (this.w * this.x + this.y * this.z), 1 - 2 * (this.x * this.x + this.y * this.y)), d = Math.asin(2 * (this.w * this.y - this.z * this.x)), _ = Math.atan2(2 * (this.w * this.z + this.x * this.y), 1 - 2 * (this.y * this.y + this.z * this.z));
      return [c, d, _];
    }, this.isLoaded = function() {
      return !!Se;
    }, this.getPitch = function() {
      return l.pitch;
    }, this.setPitch = function(c, d, _, S) {
      return Ne = Date.now(), 1e-6 >= Math.abs(c - l.pitch) ? (typeof _ == "function" && _(S), this) : ((d = d == n ? 1e3 : Number(d)) ? (Oe.pitch = { startTime: Date.now(), startPosition: l.pitch, endPosition: c, duration: d }, typeof _ == "function" && setTimeout(function() {
        _(S);
      }, d)) : l.pitch = c, le(), this);
    }, this.getPitchBounds = function() {
      return [l.minPitch, l.maxPitch];
    }, this.setPitchBounds = function(c) {
      return l.minPitch = Math.max(-90, Math.min(c[0], 90)), l.maxPitch = Math.max(-90, Math.min(c[1], 90)), this;
    }, this.getYaw = function() {
      return (l.yaw + 540) % 360 - 180;
    }, this.setYaw = function(c, d, _, S) {
      return Ne = Date.now(), 1e-6 >= Math.abs(c - l.yaw) ? (typeof _ == "function" && _(S), this) : (d = d == n ? 1e3 : Number(d), c = (c + 180) % 360 - 180, d ? (180 < l.yaw - c ? c += 360 : 180 < c - l.yaw && (c -= 360), Oe.yaw = { startTime: Date.now(), startPosition: l.yaw, endPosition: c, duration: d }, typeof _ == "function" && setTimeout(function() {
        _(S);
      }, d)) : l.yaw = c, le(), this);
    }, this.getYawBounds = function() {
      return [l.minYaw, l.maxYaw];
    }, this.setYawBounds = function(c) {
      return l.minYaw = Math.max(-360, Math.min(c[0], 360)), l.maxYaw = Math.max(-360, Math.min(c[1], 360)), this;
    }, this.getHfov = function() {
      return l.hfov;
    }, this.setHfov = function(c, d, _, S) {
      return Ne = Date.now(), 1e-6 >= Math.abs(c - l.hfov) ? (typeof _ == "function" && _(S), this) : ((d = d == n ? 1e3 : Number(d)) ? (Oe.hfov = { startTime: Date.now(), startPosition: l.hfov, endPosition: X(c), duration: d }, typeof _ == "function" && setTimeout(function() {
        _(S);
      }, d)) : G(c), le(), this);
    }, this.getHfovBounds = function() {
      return [l.minHfov, l.maxHfov];
    }, this.setHfovBounds = function(c) {
      return l.minHfov = Math.max(0, c[0]), l.maxHfov = Math.max(0, c[1]), this;
    }, this.lookAt = function(c, d, _, S, I, F) {
      return S = S == n ? 1e3 : Number(S), c !== n && 1e-6 < Math.abs(c - l.pitch) && (this.setPitch(c, S, I, F), I = n), d !== n && 1e-6 < Math.abs(d - l.yaw) && (this.setYaw(d, S, I, F), I = n), _ !== n && 1e-6 < Math.abs(_ - l.hfov) && (this.setHfov(_, S, I, F), I = n), typeof I == "function" && I(F), this;
    }, this.getNorthOffset = function() {
      return l.northOffset;
    }, this.setNorthOffset = function(c) {
      return l.northOffset = Math.min(360, Math.max(0, c)), le(), this;
    }, this.getHorizonRoll = function() {
      return l.horizonRoll;
    }, this.setHorizonRoll = function(c) {
      return l.horizonRoll = Math.min(
        90,
        Math.max(-90, c)
      ), V.setPose(l.horizonPitch * Math.PI / 180, l.horizonRoll * Math.PI / 180), le(), this;
    }, this.getHorizonPitch = function() {
      return l.horizonPitch;
    }, this.setHorizonPitch = function(c) {
      return l.horizonPitch = Math.min(90, Math.max(-90, c)), V.setPose(l.horizonPitch * Math.PI / 180, l.horizonRoll * Math.PI / 180), le(), this;
    }, this.startAutoRotate = function(c, d) {
      return c = c || $e || 1, d = d === n ? pn : d, l.autoRotate = c, Ce.lookAt(d, n, xt, 3e3), le(), this;
    }, this.stopAutoRotate = function() {
      return $e = l.autoRotate ? l.autoRotate : $e, l.autoRotate = !1, l.autoRotateInactivityDelay = -1, this;
    }, this.stopMovement = function() {
      z(), re = { yaw: 0, pitch: 0, hfov: 0 };
    }, this.getRenderer = function() {
      return V;
    }, this.setUpdate = function(c) {
      return kn = c === !0, V === n ? u() : le(), this;
    }, this.mouseEventToCoords = function(c) {
      return D(c);
    }, this.loadScene = function(c, d, _, S) {
      return Se !== !1 && J(c, d, _, S), this;
    }, this.getScene = function() {
      return l.scene;
    }, this.addScene = function(c, d) {
      return o.scenes[c] = d, this;
    }, this.removeScene = function(c) {
      return l.scene === c || !o.scenes.hasOwnProperty(c) ? !1 : (delete o.scenes[c], !0);
    }, this.toggleFullscreen = function() {
      return w(), this;
    }, this.getConfig = function() {
      return l;
    }, this.getContainer = function() {
      return r;
    }, this.addHotSpot = function(c, d) {
      if (d === n && l.scene === n)
        l.hotSpots.push(c);
      else {
        var _ = d !== n ? d : l.scene;
        if (o.scenes.hasOwnProperty(_))
          o.scenes[_].hasOwnProperty("hotSpots") || (o.scenes[_].hotSpots = [], _ == l.scene && (l.hotSpots = o.scenes[_].hotSpots)), o.scenes[_].hotSpots.push(c);
        else
          throw "Invalid scene ID!";
      }
      return (d === n || l.scene == d) && (O(c), Se && Z(c)), this;
    }, this.removeHotSpot = function(c, d) {
      if (d === n || l.scene == d) {
        if (!l.hotSpots)
          return !1;
        for (var _ = 0; _ < l.hotSpots.length; _++)
          if (l.hotSpots[_].hasOwnProperty("id") && l.hotSpots[_].id === c) {
            for (var S = l.hotSpots[_].div; S.parentNode != Le; )
              S = S.parentNode;
            return Le.removeChild(S), delete l.hotSpots[_].div, l.hotSpots.splice(_, 1), !0;
          }
      } else if (o.scenes.hasOwnProperty(d)) {
        if (!o.scenes[d].hasOwnProperty("hotSpots"))
          return !1;
        for (_ = 0; _ < o.scenes[d].hotSpots.length; _++)
          if (o.scenes[d].hotSpots[_].hasOwnProperty("id") && o.scenes[d].hotSpots[_].id === c)
            return o.scenes[d].hotSpots.splice(
              _,
              1
            ), !0;
      } else
        return !1;
    }, this.resize = function() {
      V && Y();
    }, this.isLoaded = function() {
      return Se;
    }, this.isOrientationSupported = function() {
      return vi || !1;
    }, this.stopOrientation = function() {
      oe();
    }, this.startOrientation = function() {
      vi && he();
    }, this.isOrientationActive = function() {
      return !!Ke;
    }, this.on = function(c, d) {
      return qe[c] = qe[c] || [], qe[c].push(d), this;
    }, this.off = function(c, d) {
      if (!c)
        return qe = {}, this;
      if (d) {
        var _ = qe[c].indexOf(d);
        0 <= _ && qe[c].splice(_, 1), qe[c].length == 0 && delete qe[c];
      } else
        delete qe[c];
      return this;
    }, this.destroy = function() {
      yr = !0, clearTimeout(Hn), V && V.destroy(), mi && (t.removeEventListener("mousemove", N, !1), t.removeEventListener("mouseup", K, !1), r.removeEventListener("mozfullscreenchange", T, !1), r.removeEventListener("webkitfullscreenchange", T, !1), r.removeEventListener("msfullscreenchange", T, !1), r.removeEventListener("fullscreenchange", T, !1), e.removeEventListener("resize", Y, !1), e.removeEventListener("orientationchange", Y, !1), r.removeEventListener("keydown", be, !1), r.removeEventListener("keyup", we, !1), r.removeEventListener(
        "blur",
        ve,
        !1
      ), t.removeEventListener("mouseleave", K, !1)), r.innerHTML = "", r.classList.remove("pnlm-container");
    };
  }
  return { viewer: function(r, o) {
    return new i(r, o);
  } };
}(window, document);
const {
  SvelteComponent: Wu,
  attr: Fr,
  detach: Yu,
  element: Zu,
  init: Ju,
  insert: Qu,
  noop: Gr,
  safe_not_equal: Ku,
  set_style: zr
} = window.__gradio__svelte__internal, { onMount: $u } = window.__gradio__svelte__internal;
function ec(e) {
  let t;
  return {
    c() {
      t = Zu("div"), Fr(
        t,
        "id",
        /*div_id*/
        e[0]
      ), zr(
        t,
        "height",
        /*height*/
        e[1] + "px"
      );
    },
    m(n, i) {
      Qu(n, t, i);
    },
    p(n, [i]) {
      i & /*div_id*/
      1 && Fr(
        t,
        "id",
        /*div_id*/
        n[0]
      ), i & /*height*/
      2 && zr(
        t,
        "height",
        /*height*/
        n[1] + "px"
      );
    },
    i: Gr,
    o: Gr,
    d(n) {
      n && Yu(t);
    }
  };
}
function tc(e, t, n) {
  let { div_id: i } = t, { panorama: r } = t, { height: o = 400 } = t;
  return $u(() => {
    window.pannellum.viewer(i, { type: "equirectangular", panorama: r });
  }), e.$$set = (a) => {
    "div_id" in a && n(0, i = a.div_id), "panorama" in a && n(2, r = a.panorama), "height" in a && n(1, o = a.height);
  }, [i, o, r];
}
class na extends Wu {
  constructor(t) {
    super(), Ju(this, t, tc, ec, Ku, { div_id: 0, panorama: 2, height: 1 });
  }
}
const {
  SvelteComponent: nc,
  append: ic,
  attr: En,
  bubble: qr,
  check_outros: Ki,
  create_component: sn,
  destroy_component: ln,
  detach: Sn,
  element: ia,
  empty: rc,
  group_outros: $i,
  init: oc,
  insert: Cn,
  mount_component: un,
  safe_not_equal: ac,
  space: er,
  transition_in: Ge,
  transition_out: Je
} = window.__gradio__svelte__internal;
function sc(e) {
  let t, n, i, r, o, a = (
    /*show_download_button*/
    e[3] && jr(e)
  ), s = (
    /*show_share_button*/
    e[4] && Xr(e)
  );
  return r = new na({
    props: {
      div_id: "pannellum-preview-" + /*value*/
      e[0].orig_name,
      panorama: (
        /*value*/
        e[0].url
      ),
      height: (
        /*height*/
        e[6]
      )
    }
  }), {
    c() {
      t = ia("div"), a && a.c(), n = er(), s && s.c(), i = er(), sn(r.$$.fragment), En(t, "class", "icon-buttons svelte-1mrvp2o");
    },
    m(u, f) {
      Cn(u, t, f), a && a.m(t, null), ic(t, n), s && s.m(t, null), Cn(u, i, f), un(r, u, f), o = !0;
    },
    p(u, f) {
      /*show_download_button*/
      u[3] ? a ? (a.p(u, f), f & /*show_download_button*/
      8 && Ge(a, 1)) : (a = jr(u), a.c(), Ge(a, 1), a.m(t, n)) : a && ($i(), Je(a, 1, 1, () => {
        a = null;
      }), Ki()), /*show_share_button*/
      u[4] ? s ? (s.p(u, f), f & /*show_share_button*/
      16 && Ge(s, 1)) : (s = Xr(u), s.c(), Ge(s, 1), s.m(t, null)) : s && ($i(), Je(s, 1, 1, () => {
        s = null;
      }), Ki());
      const h = {};
      f & /*value*/
      1 && (h.div_id = "pannellum-preview-" + /*value*/
      u[0].orig_name), f & /*value*/
      1 && (h.panorama = /*value*/
      u[0].url), f & /*height*/
      64 && (h.height = /*height*/
      u[6]), r.$set(h);
    },
    i(u) {
      o || (Ge(a), Ge(s), Ge(r.$$.fragment, u), o = !0);
    },
    o(u) {
      Je(a), Je(s), Je(r.$$.fragment, u), o = !1;
    },
    d(u) {
      u && (Sn(t), Sn(i)), a && a.d(), s && s.d(), ln(r, u);
    }
  };
}
function lc(e) {
  let t, n;
  return t = new Ko({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [uc] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      sn(t.$$.fragment);
    },
    m(i, r) {
      un(t, i, r), n = !0;
    },
    p(i, r) {
      const o = {};
      r & /*$$scope*/
      1024 && (o.$$scope = { dirty: r, ctx: i }), t.$set(o);
    },
    i(i) {
      n || (Ge(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Je(t.$$.fragment, i), n = !1;
    },
    d(i) {
      ln(t, i);
    }
  };
}
function jr(e) {
  let t, n, i, r;
  return n = new ai({
    props: {
      Icon: Cl,
      label: (
        /*i18n*/
        e[5]("common.download")
      )
    }
  }), {
    c() {
      t = ia("a"), sn(n.$$.fragment), En(t, "href", i = /*value*/
      e[0].url), En(t, "target", window.__is_colab__ ? "_blank" : null), En(t, "download", "image");
    },
    m(o, a) {
      Cn(o, t, a), un(n, t, null), r = !0;
    },
    p(o, a) {
      const s = {};
      a & /*i18n*/
      32 && (s.label = /*i18n*/
      o[5]("common.download")), n.$set(s), (!r || a & /*value*/
      1 && i !== (i = /*value*/
      o[0].url)) && En(t, "href", i);
    },
    i(o) {
      r || (Ge(n.$$.fragment, o), r = !0);
    },
    o(o) {
      Je(n.$$.fragment, o), r = !1;
    },
    d(o) {
      o && Sn(t), ln(n);
    }
  };
}
function Xr(e) {
  let t, n;
  return t = new ou({
    props: {
      i18n: (
        /*i18n*/
        e[5]
      ),
      formatter: (
        /*func*/
        e[7]
      ),
      value: (
        /*value*/
        e[0]
      )
    }
  }), t.$on(
    "share",
    /*share_handler*/
    e[8]
  ), t.$on(
    "error",
    /*error_handler*/
    e[9]
  ), {
    c() {
      sn(t.$$.fragment);
    },
    m(i, r) {
      un(t, i, r), n = !0;
    },
    p(i, r) {
      const o = {};
      r & /*i18n*/
      32 && (o.i18n = /*i18n*/
      i[5]), r & /*value*/
      1 && (o.value = /*value*/
      i[0]), t.$set(o);
    },
    i(i) {
      n || (Ge(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Je(t.$$.fragment, i), n = !1;
    },
    d(i) {
      ln(t, i);
    }
  };
}
function uc(e) {
  let t, n;
  return t = new si({}), {
    c() {
      sn(t.$$.fragment);
    },
    m(i, r) {
      un(t, i, r), n = !0;
    },
    i(i) {
      n || (Ge(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Je(t.$$.fragment, i), n = !1;
    },
    d(i) {
      ln(t, i);
    }
  };
}
function cc(e) {
  let t, n, i, r, o, a;
  t = new Zo({
    props: {
      show_label: (
        /*show_label*/
        e[2]
      ),
      Icon: si,
      label: (
        /*label*/
        e[1] || /*i18n*/
        e[5]("image.image")
      )
    }
  });
  const s = [lc, sc], u = [];
  function f(h, p) {
    return (
      /*value*/
      h[0] === null || !/*value*/
      h[0].url ? 0 : 1
    );
  }
  return i = f(e), r = u[i] = s[i](e), {
    c() {
      sn(t.$$.fragment), n = er(), r.c(), o = rc();
    },
    m(h, p) {
      un(t, h, p), Cn(h, n, p), u[i].m(h, p), Cn(h, o, p), a = !0;
    },
    p(h, [p]) {
      const g = {};
      p & /*show_label*/
      4 && (g.show_label = /*show_label*/
      h[2]), p & /*label, i18n*/
      34 && (g.label = /*label*/
      h[1] || /*i18n*/
      h[5]("image.image")), t.$set(g);
      let v = i;
      i = f(h), i === v ? u[i].p(h, p) : ($i(), Je(u[v], 1, 1, () => {
        u[v] = null;
      }), Ki(), r = u[i], r ? r.p(h, p) : (r = u[i] = s[i](h), r.c()), Ge(r, 1), r.m(o.parentNode, o));
    },
    i(h) {
      a || (Ge(t.$$.fragment, h), Ge(r), a = !0);
    },
    o(h) {
      Je(t.$$.fragment, h), Je(r), a = !1;
    },
    d(h) {
      h && (Sn(n), Sn(o)), ln(t, h), u[i].d(h);
    }
  };
}
function fc(e, t, n) {
  let { value: i } = t, { label: r = void 0 } = t, { show_label: o } = t, { show_download_button: a = !0 } = t, { show_share_button: s = !1 } = t, { i18n: u } = t, { height: f = 400 } = t;
  const h = async (v) => v ? `<img src="${await Ja(v, "base64")}" />` : "";
  function p(v) {
    qr.call(this, e, v);
  }
  function g(v) {
    qr.call(this, e, v);
  }
  return e.$$set = (v) => {
    "value" in v && n(0, i = v.value), "label" in v && n(1, r = v.label), "show_label" in v && n(2, o = v.show_label), "show_download_button" in v && n(3, a = v.show_download_button), "show_share_button" in v && n(4, s = v.show_share_button), "i18n" in v && n(5, u = v.i18n), "height" in v && n(6, f = v.height);
  }, [
    i,
    r,
    o,
    a,
    s,
    u,
    f,
    h,
    p,
    g
  ];
}
class hc extends nc {
  constructor(t) {
    super(), oc(this, t, fc, cc, ac, {
      value: 0,
      label: 1,
      show_label: 2,
      show_download_button: 3,
      show_share_button: 4,
      i18n: 5,
      height: 6
    });
  }
}
function kt() {
}
function dc(e) {
  return e();
}
function mc(e) {
  e.forEach(dc);
}
function _c(e) {
  return typeof e == "function";
}
function pc(e, t) {
  return e != e ? t == t : e !== t || e && typeof e == "object" || typeof e == "function";
}
function gc(e, ...t) {
  if (e == null) {
    for (const i of t)
      i(void 0);
    return kt;
  }
  const n = e.subscribe(...t);
  return n.unsubscribe ? () => n.unsubscribe() : n;
}
const ra = typeof window < "u";
let Vr = ra ? () => window.performance.now() : () => Date.now(), oa = ra ? (e) => requestAnimationFrame(e) : kt;
const Jt = /* @__PURE__ */ new Set();
function aa(e) {
  Jt.forEach((t) => {
    t.c(e) || (Jt.delete(t), t.f());
  }), Jt.size !== 0 && oa(aa);
}
function bc(e) {
  let t;
  return Jt.size === 0 && oa(aa), {
    promise: new Promise((n) => {
      Jt.add(t = { c: e, f: n });
    }),
    abort() {
      Jt.delete(t);
    }
  };
}
const jt = [];
function vc(e, t) {
  return {
    subscribe: An(e, t).subscribe
  };
}
function An(e, t = kt) {
  let n;
  const i = /* @__PURE__ */ new Set();
  function r(s) {
    if (pc(e, s) && (e = s, n)) {
      const u = !jt.length;
      for (const f of i)
        f[1](), jt.push(f, e);
      if (u) {
        for (let f = 0; f < jt.length; f += 2)
          jt[f][0](jt[f + 1]);
        jt.length = 0;
      }
    }
  }
  function o(s) {
    r(s(e));
  }
  function a(s, u = kt) {
    const f = [s, u];
    return i.add(f), i.size === 1 && (n = t(r, o) || kt), s(e), () => {
      i.delete(f), i.size === 0 && n && (n(), n = null);
    };
  }
  return { set: r, update: o, subscribe: a };
}
function cn(e, t, n) {
  const i = !Array.isArray(e), r = i ? [e] : e;
  if (!r.every(Boolean))
    throw new Error("derived() expects stores as input, got a falsy value");
  const o = t.length < 2;
  return vc(n, (a, s) => {
    let u = !1;
    const f = [];
    let h = 0, p = kt;
    const g = () => {
      if (h)
        return;
      p();
      const B = t(i ? f[0] : f, a, s);
      o ? a(B) : p = _c(B) ? B : kt;
    }, v = r.map(
      (B, D) => gc(
        B,
        (N) => {
          f[D] = N, h &= ~(1 << D), u && g();
        },
        () => {
          h |= 1 << D;
        }
      )
    );
    return u = !0, g(), function() {
      mc(v), p(), u = !1;
    };
  });
}
function Wr(e) {
  return Object.prototype.toString.call(e) === "[object Date]";
}
function tr(e, t, n, i) {
  if (typeof n == "number" || Wr(n)) {
    const r = i - n, o = (n - t) / (e.dt || 1 / 60), a = e.opts.stiffness * r, s = e.opts.damping * o, u = (a - s) * e.inv_mass, f = (o + u) * e.dt;
    return Math.abs(f) < e.opts.precision && Math.abs(r) < e.opts.precision ? i : (e.settled = !1, Wr(n) ? new Date(n.getTime() + f) : n + f);
  } else {
    if (Array.isArray(n))
      return n.map(
        (r, o) => tr(e, t[o], n[o], i[o])
      );
    if (typeof n == "object") {
      const r = {};
      for (const o in n)
        r[o] = tr(e, t[o], n[o], i[o]);
      return r;
    } else
      throw new Error(`Cannot spring ${typeof n} values`);
  }
}
function Yr(e, t = {}) {
  const n = An(e), { stiffness: i = 0.15, damping: r = 0.8, precision: o = 0.01 } = t;
  let a, s, u, f = e, h = e, p = 1, g = 0, v = !1;
  function B(N, K = {}) {
    h = N;
    const x = u = {};
    return e == null || K.hard || D.stiffness >= 1 && D.damping >= 1 ? (v = !0, a = Vr(), f = N, n.set(e = h), Promise.resolve()) : (K.soft && (g = 1 / ((K.soft === !0 ? 0.5 : +K.soft) * 60), p = 0), s || (a = Vr(), v = !1, s = bc((M) => {
      if (v)
        return v = !1, s = null, !1;
      p = Math.min(p + g, 1);
      const H = {
        inv_mass: p,
        opts: D,
        settled: !0,
        dt: (M - a) * 60 / 1e3
      }, A = tr(H, f, e, h);
      return a = M, f = e, n.set(e = A), H.settled && (s = null), !H.settled;
    })), new Promise((M) => {
      s.promise.then(() => {
        x === u && M();
      });
    }));
  }
  const D = {
    set: B,
    update: (N, K) => B(N(h, e), K),
    subscribe: n.subscribe,
    stiffness: i,
    damping: r,
    precision: o
  };
  return D;
}
function wc(e) {
  return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e;
}
var yc = function(t) {
  return Ec(t) && !Tc(t);
};
function Ec(e) {
  return !!e && typeof e == "object";
}
function Tc(e) {
  var t = Object.prototype.toString.call(e);
  return t === "[object RegExp]" || t === "[object Date]" || Sc(e);
}
var Pc = typeof Symbol == "function" && Symbol.for, Mc = Pc ? Symbol.for("react.element") : 60103;
function Sc(e) {
  return e.$$typeof === Mc;
}
function Cc(e) {
  return Array.isArray(e) ? [] : {};
}
function xn(e, t) {
  return t.clone !== !1 && t.isMergeableObject(e) ? Qt(Cc(e), e, t) : e;
}
function xc(e, t, n) {
  return e.concat(t).map(function(i) {
    return xn(i, n);
  });
}
function Ic(e, t) {
  if (!t.customMerge)
    return Qt;
  var n = t.customMerge(e);
  return typeof n == "function" ? n : Qt;
}
function Ac(e) {
  return Object.getOwnPropertySymbols ? Object.getOwnPropertySymbols(e).filter(function(t) {
    return Object.propertyIsEnumerable.call(e, t);
  }) : [];
}
function Zr(e) {
  return Object.keys(e).concat(Ac(e));
}
function sa(e, t) {
  try {
    return t in e;
  } catch {
    return !1;
  }
}
function Rc(e, t) {
  return sa(e, t) && !(Object.hasOwnProperty.call(e, t) && Object.propertyIsEnumerable.call(e, t));
}
function Lc(e, t, n) {
  var i = {};
  return n.isMergeableObject(e) && Zr(e).forEach(function(r) {
    i[r] = xn(e[r], n);
  }), Zr(t).forEach(function(r) {
    Rc(e, r) || (sa(e, r) && n.isMergeableObject(t[r]) ? i[r] = Ic(r, n)(e[r], t[r], n) : i[r] = xn(t[r], n));
  }), i;
}
function Qt(e, t, n) {
  n = n || {}, n.arrayMerge = n.arrayMerge || xc, n.isMergeableObject = n.isMergeableObject || yc, n.cloneUnlessOtherwiseSpecified = xn;
  var i = Array.isArray(t), r = Array.isArray(e), o = i === r;
  return o ? i ? n.arrayMerge(e, t, n) : Lc(e, t, n) : xn(t, n);
}
Qt.all = function(t, n) {
  if (!Array.isArray(t))
    throw new Error("first argument should be an array");
  return t.reduce(function(i, r) {
    return Qt(i, r, n);
  }, {});
};
var Bc = Qt, Nc = Bc;
const Oc = /* @__PURE__ */ wc(Nc);
var nr = function(e, t) {
  return nr = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, i) {
    n.__proto__ = i;
  } || function(n, i) {
    for (var r in i)
      Object.prototype.hasOwnProperty.call(i, r) && (n[r] = i[r]);
  }, nr(e, t);
};
function li(e, t) {
  if (typeof t != "function" && t !== null)
    throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");
  nr(e, t);
  function n() {
    this.constructor = e;
  }
  e.prototype = t === null ? Object.create(t) : (n.prototype = t.prototype, new n());
}
var ge = function() {
  return ge = Object.assign || function(t) {
    for (var n, i = 1, r = arguments.length; i < r; i++) {
      n = arguments[i];
      for (var o in n)
        Object.prototype.hasOwnProperty.call(n, o) && (t[o] = n[o]);
    }
    return t;
  }, ge.apply(this, arguments);
};
function Ni(e, t, n) {
  if (n || arguments.length === 2)
    for (var i = 0, r = t.length, o; i < r; i++)
      (o || !(i in t)) && (o || (o = Array.prototype.slice.call(t, 0, i)), o[i] = t[i]);
  return e.concat(o || Array.prototype.slice.call(t));
}
var de;
(function(e) {
  e[e.EXPECT_ARGUMENT_CLOSING_BRACE = 1] = "EXPECT_ARGUMENT_CLOSING_BRACE", e[e.EMPTY_ARGUMENT = 2] = "EMPTY_ARGUMENT", e[e.MALFORMED_ARGUMENT = 3] = "MALFORMED_ARGUMENT", e[e.EXPECT_ARGUMENT_TYPE = 4] = "EXPECT_ARGUMENT_TYPE", e[e.INVALID_ARGUMENT_TYPE = 5] = "INVALID_ARGUMENT_TYPE", e[e.EXPECT_ARGUMENT_STYLE = 6] = "EXPECT_ARGUMENT_STYLE", e[e.INVALID_NUMBER_SKELETON = 7] = "INVALID_NUMBER_SKELETON", e[e.INVALID_DATE_TIME_SKELETON = 8] = "INVALID_DATE_TIME_SKELETON", e[e.EXPECT_NUMBER_SKELETON = 9] = "EXPECT_NUMBER_SKELETON", e[e.EXPECT_DATE_TIME_SKELETON = 10] = "EXPECT_DATE_TIME_SKELETON", e[e.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE = 11] = "UNCLOSED_QUOTE_IN_ARGUMENT_STYLE", e[e.EXPECT_SELECT_ARGUMENT_OPTIONS = 12] = "EXPECT_SELECT_ARGUMENT_OPTIONS", e[e.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE = 13] = "EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE = 14] = "INVALID_PLURAL_ARGUMENT_OFFSET_VALUE", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR = 15] = "EXPECT_SELECT_ARGUMENT_SELECTOR", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR = 16] = "EXPECT_PLURAL_ARGUMENT_SELECTOR", e[e.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT = 17] = "EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT", e[e.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT = 18] = "EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT", e[e.INVALID_PLURAL_ARGUMENT_SELECTOR = 19] = "INVALID_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_PLURAL_ARGUMENT_SELECTOR = 20] = "DUPLICATE_PLURAL_ARGUMENT_SELECTOR", e[e.DUPLICATE_SELECT_ARGUMENT_SELECTOR = 21] = "DUPLICATE_SELECT_ARGUMENT_SELECTOR", e[e.MISSING_OTHER_CLAUSE = 22] = "MISSING_OTHER_CLAUSE", e[e.INVALID_TAG = 23] = "INVALID_TAG", e[e.INVALID_TAG_NAME = 25] = "INVALID_TAG_NAME", e[e.UNMATCHED_CLOSING_TAG = 26] = "UNMATCHED_CLOSING_TAG", e[e.UNCLOSED_TAG = 27] = "UNCLOSED_TAG";
})(de || (de = {}));
var Te;
(function(e) {
  e[e.literal = 0] = "literal", e[e.argument = 1] = "argument", e[e.number = 2] = "number", e[e.date = 3] = "date", e[e.time = 4] = "time", e[e.select = 5] = "select", e[e.plural = 6] = "plural", e[e.pound = 7] = "pound", e[e.tag = 8] = "tag";
})(Te || (Te = {}));
var Kt;
(function(e) {
  e[e.number = 0] = "number", e[e.dateTime = 1] = "dateTime";
})(Kt || (Kt = {}));
function Jr(e) {
  return e.type === Te.literal;
}
function Hc(e) {
  return e.type === Te.argument;
}
function la(e) {
  return e.type === Te.number;
}
function ua(e) {
  return e.type === Te.date;
}
function ca(e) {
  return e.type === Te.time;
}
function fa(e) {
  return e.type === Te.select;
}
function ha(e) {
  return e.type === Te.plural;
}
function kc(e) {
  return e.type === Te.pound;
}
function da(e) {
  return e.type === Te.tag;
}
function ma(e) {
  return !!(e && typeof e == "object" && e.type === Kt.number);
}
function ir(e) {
  return !!(e && typeof e == "object" && e.type === Kt.dateTime);
}
var _a = /[ \xA0\u1680\u2000-\u200A\u202F\u205F\u3000]/, Dc = /(?:[Eec]{1,6}|G{1,5}|[Qq]{1,5}|(?:[yYur]+|U{1,5})|[ML]{1,5}|d{1,2}|D{1,3}|F{1}|[abB]{1,5}|[hkHK]{1,2}|w{1,2}|W{1}|m{1,2}|s{1,2}|[zZOvVxX]{1,4})(?=([^']*'[^']*')*[^']*$)/g;
function Uc(e) {
  var t = {};
  return e.replace(Dc, function(n) {
    var i = n.length;
    switch (n[0]) {
      case "G":
        t.era = i === 4 ? "long" : i === 5 ? "narrow" : "short";
        break;
      case "y":
        t.year = i === 2 ? "2-digit" : "numeric";
        break;
      case "Y":
      case "u":
      case "U":
      case "r":
        throw new RangeError("`Y/u/U/r` (year) patterns are not supported, use `y` instead");
      case "q":
      case "Q":
        throw new RangeError("`q/Q` (quarter) patterns are not supported");
      case "M":
      case "L":
        t.month = ["numeric", "2-digit", "short", "long", "narrow"][i - 1];
        break;
      case "w":
      case "W":
        throw new RangeError("`w/W` (week) patterns are not supported");
      case "d":
        t.day = ["numeric", "2-digit"][i - 1];
        break;
      case "D":
      case "F":
      case "g":
        throw new RangeError("`D/F/g` (day) patterns are not supported, use `d` instead");
      case "E":
        t.weekday = i === 4 ? "short" : i === 5 ? "narrow" : "short";
        break;
      case "e":
        if (i < 4)
          throw new RangeError("`e..eee` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "c":
        if (i < 4)
          throw new RangeError("`c..ccc` (weekday) patterns are not supported");
        t.weekday = ["short", "long", "narrow", "short"][i - 4];
        break;
      case "a":
        t.hour12 = !0;
        break;
      case "b":
      case "B":
        throw new RangeError("`b/B` (period) patterns are not supported, use `a` instead");
      case "h":
        t.hourCycle = "h12", t.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "H":
        t.hourCycle = "h23", t.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "K":
        t.hourCycle = "h11", t.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "k":
        t.hourCycle = "h24", t.hour = ["numeric", "2-digit"][i - 1];
        break;
      case "j":
      case "J":
      case "C":
        throw new RangeError("`j/J/C` (hour) patterns are not supported, use `h/H/K/k` instead");
      case "m":
        t.minute = ["numeric", "2-digit"][i - 1];
        break;
      case "s":
        t.second = ["numeric", "2-digit"][i - 1];
        break;
      case "S":
      case "A":
        throw new RangeError("`S/A` (second) patterns are not supported, use `s` instead");
      case "z":
        t.timeZoneName = i < 4 ? "short" : "long";
        break;
      case "Z":
      case "O":
      case "v":
      case "V":
      case "X":
      case "x":
        throw new RangeError("`Z/O/v/V/X/x` (timeZone) patterns are not supported, use `z` instead");
    }
    return "";
  }), t;
}
var Fc = /[\t-\r \x85\u200E\u200F\u2028\u2029]/i;
function Gc(e) {
  if (e.length === 0)
    throw new Error("Number skeleton cannot be empty");
  for (var t = e.split(Fc).filter(function(g) {
    return g.length > 0;
  }), n = [], i = 0, r = t; i < r.length; i++) {
    var o = r[i], a = o.split("/");
    if (a.length === 0)
      throw new Error("Invalid number skeleton");
    for (var s = a[0], u = a.slice(1), f = 0, h = u; f < h.length; f++) {
      var p = h[f];
      if (p.length === 0)
        throw new Error("Invalid number skeleton");
    }
    n.push({ stem: s, options: u });
  }
  return n;
}
function zc(e) {
  return e.replace(/^(.*?)-/, "");
}
var Qr = /^\.(?:(0+)(\*)?|(#+)|(0+)(#+))$/g, pa = /^(@+)?(\+|#+)?[rs]?$/g, qc = /(\*)(0+)|(#+)(0+)|(0+)/g, ga = /^(0+)$/;
function Kr(e) {
  var t = {};
  return e[e.length - 1] === "r" ? t.roundingPriority = "morePrecision" : e[e.length - 1] === "s" && (t.roundingPriority = "lessPrecision"), e.replace(pa, function(n, i, r) {
    return typeof r != "string" ? (t.minimumSignificantDigits = i.length, t.maximumSignificantDigits = i.length) : r === "+" ? t.minimumSignificantDigits = i.length : i[0] === "#" ? t.maximumSignificantDigits = i.length : (t.minimumSignificantDigits = i.length, t.maximumSignificantDigits = i.length + (typeof r == "string" ? r.length : 0)), "";
  }), t;
}
function ba(e) {
  switch (e) {
    case "sign-auto":
      return {
        signDisplay: "auto"
      };
    case "sign-accounting":
    case "()":
      return {
        currencySign: "accounting"
      };
    case "sign-always":
    case "+!":
      return {
        signDisplay: "always"
      };
    case "sign-accounting-always":
    case "()!":
      return {
        signDisplay: "always",
        currencySign: "accounting"
      };
    case "sign-except-zero":
    case "+?":
      return {
        signDisplay: "exceptZero"
      };
    case "sign-accounting-except-zero":
    case "()?":
      return {
        signDisplay: "exceptZero",
        currencySign: "accounting"
      };
    case "sign-never":
    case "+_":
      return {
        signDisplay: "never"
      };
  }
}
function jc(e) {
  var t;
  if (e[0] === "E" && e[1] === "E" ? (t = {
    notation: "engineering"
  }, e = e.slice(2)) : e[0] === "E" && (t = {
    notation: "scientific"
  }, e = e.slice(1)), t) {
    var n = e.slice(0, 2);
    if (n === "+!" ? (t.signDisplay = "always", e = e.slice(2)) : n === "+?" && (t.signDisplay = "exceptZero", e = e.slice(2)), !ga.test(e))
      throw new Error("Malformed concise eng/scientific notation");
    t.minimumIntegerDigits = e.length;
  }
  return t;
}
function $r(e) {
  var t = {}, n = ba(e);
  return n || t;
}
function Xc(e) {
  for (var t = {}, n = 0, i = e; n < i.length; n++) {
    var r = i[n];
    switch (r.stem) {
      case "percent":
      case "%":
        t.style = "percent";
        continue;
      case "%x100":
        t.style = "percent", t.scale = 100;
        continue;
      case "currency":
        t.style = "currency", t.currency = r.options[0];
        continue;
      case "group-off":
      case ",_":
        t.useGrouping = !1;
        continue;
      case "precision-integer":
      case ".":
        t.maximumFractionDigits = 0;
        continue;
      case "measure-unit":
      case "unit":
        t.style = "unit", t.unit = zc(r.options[0]);
        continue;
      case "compact-short":
      case "K":
        t.notation = "compact", t.compactDisplay = "short";
        continue;
      case "compact-long":
      case "KK":
        t.notation = "compact", t.compactDisplay = "long";
        continue;
      case "scientific":
        t = ge(ge(ge({}, t), { notation: "scientific" }), r.options.reduce(function(u, f) {
          return ge(ge({}, u), $r(f));
        }, {}));
        continue;
      case "engineering":
        t = ge(ge(ge({}, t), { notation: "engineering" }), r.options.reduce(function(u, f) {
          return ge(ge({}, u), $r(f));
        }, {}));
        continue;
      case "notation-simple":
        t.notation = "standard";
        continue;
      case "unit-width-narrow":
        t.currencyDisplay = "narrowSymbol", t.unitDisplay = "narrow";
        continue;
      case "unit-width-short":
        t.currencyDisplay = "code", t.unitDisplay = "short";
        continue;
      case "unit-width-full-name":
        t.currencyDisplay = "name", t.unitDisplay = "long";
        continue;
      case "unit-width-iso-code":
        t.currencyDisplay = "symbol";
        continue;
      case "scale":
        t.scale = parseFloat(r.options[0]);
        continue;
      case "integer-width":
        if (r.options.length > 1)
          throw new RangeError("integer-width stems only accept a single optional option");
        r.options[0].replace(qc, function(u, f, h, p, g, v) {
          if (f)
            t.minimumIntegerDigits = h.length;
          else {
            if (p && g)
              throw new Error("We currently do not support maximum integer digits");
            if (v)
              throw new Error("We currently do not support exact integer digits");
          }
          return "";
        });
        continue;
    }
    if (ga.test(r.stem)) {
      t.minimumIntegerDigits = r.stem.length;
      continue;
    }
    if (Qr.test(r.stem)) {
      if (r.options.length > 1)
        throw new RangeError("Fraction-precision stems only accept a single optional option");
      r.stem.replace(Qr, function(u, f, h, p, g, v) {
        return h === "*" ? t.minimumFractionDigits = f.length : p && p[0] === "#" ? t.maximumFractionDigits = p.length : g && v ? (t.minimumFractionDigits = g.length, t.maximumFractionDigits = g.length + v.length) : (t.minimumFractionDigits = f.length, t.maximumFractionDigits = f.length), "";
      });
      var o = r.options[0];
      o === "w" ? t = ge(ge({}, t), { trailingZeroDisplay: "stripIfInteger" }) : o && (t = ge(ge({}, t), Kr(o)));
      continue;
    }
    if (pa.test(r.stem)) {
      t = ge(ge({}, t), Kr(r.stem));
      continue;
    }
    var a = ba(r.stem);
    a && (t = ge(ge({}, t), a));
    var s = jc(r.stem);
    s && (t = ge(ge({}, t), s));
  }
  return t;
}
var zn = {
  AX: [
    "H"
  ],
  BQ: [
    "H"
  ],
  CP: [
    "H"
  ],
  CZ: [
    "H"
  ],
  DK: [
    "H"
  ],
  FI: [
    "H"
  ],
  ID: [
    "H"
  ],
  IS: [
    "H"
  ],
  ML: [
    "H"
  ],
  NE: [
    "H"
  ],
  RU: [
    "H"
  ],
  SE: [
    "H"
  ],
  SJ: [
    "H"
  ],
  SK: [
    "H"
  ],
  AS: [
    "h",
    "H"
  ],
  BT: [
    "h",
    "H"
  ],
  DJ: [
    "h",
    "H"
  ],
  ER: [
    "h",
    "H"
  ],
  GH: [
    "h",
    "H"
  ],
  IN: [
    "h",
    "H"
  ],
  LS: [
    "h",
    "H"
  ],
  PG: [
    "h",
    "H"
  ],
  PW: [
    "h",
    "H"
  ],
  SO: [
    "h",
    "H"
  ],
  TO: [
    "h",
    "H"
  ],
  VU: [
    "h",
    "H"
  ],
  WS: [
    "h",
    "H"
  ],
  "001": [
    "H",
    "h"
  ],
  AL: [
    "h",
    "H",
    "hB"
  ],
  TD: [
    "h",
    "H",
    "hB"
  ],
  "ca-ES": [
    "H",
    "h",
    "hB"
  ],
  CF: [
    "H",
    "h",
    "hB"
  ],
  CM: [
    "H",
    "h",
    "hB"
  ],
  "fr-CA": [
    "H",
    "h",
    "hB"
  ],
  "gl-ES": [
    "H",
    "h",
    "hB"
  ],
  "it-CH": [
    "H",
    "h",
    "hB"
  ],
  "it-IT": [
    "H",
    "h",
    "hB"
  ],
  LU: [
    "H",
    "h",
    "hB"
  ],
  NP: [
    "H",
    "h",
    "hB"
  ],
  PF: [
    "H",
    "h",
    "hB"
  ],
  SC: [
    "H",
    "h",
    "hB"
  ],
  SM: [
    "H",
    "h",
    "hB"
  ],
  SN: [
    "H",
    "h",
    "hB"
  ],
  TF: [
    "H",
    "h",
    "hB"
  ],
  VA: [
    "H",
    "h",
    "hB"
  ],
  CY: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  GR: [
    "h",
    "H",
    "hb",
    "hB"
  ],
  CO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  DO: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KP: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  KR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  NA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PA: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  PR: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  VE: [
    "h",
    "H",
    "hB",
    "hb"
  ],
  AC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  AI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BW: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  BZ: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CC: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  CX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  DG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  FK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GB: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  GI: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IM: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  IO: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  JE: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  LT: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MK: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  MS: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NF: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NG: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NR: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  NU: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  PN: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SH: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  SX: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  TA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  ZA: [
    "H",
    "h",
    "hb",
    "hB"
  ],
  "af-ZA": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  AR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CL: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CR: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  CU: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  EA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BO": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-BR": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-EC": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-ES": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-GQ": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  "es-PE": [
    "H",
    "h",
    "hB",
    "hb"
  ],
  GT: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  HN: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  IC: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KG: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  KM: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  LK: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MA: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  MX: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  NI: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  PY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  SV: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  UY: [
    "H",
    "h",
    "hB",
    "hb"
  ],
  JP: [
    "H",
    "h",
    "K"
  ],
  AD: [
    "H",
    "hB"
  ],
  AM: [
    "H",
    "hB"
  ],
  AO: [
    "H",
    "hB"
  ],
  AT: [
    "H",
    "hB"
  ],
  AW: [
    "H",
    "hB"
  ],
  BE: [
    "H",
    "hB"
  ],
  BF: [
    "H",
    "hB"
  ],
  BJ: [
    "H",
    "hB"
  ],
  BL: [
    "H",
    "hB"
  ],
  BR: [
    "H",
    "hB"
  ],
  CG: [
    "H",
    "hB"
  ],
  CI: [
    "H",
    "hB"
  ],
  CV: [
    "H",
    "hB"
  ],
  DE: [
    "H",
    "hB"
  ],
  EE: [
    "H",
    "hB"
  ],
  FR: [
    "H",
    "hB"
  ],
  GA: [
    "H",
    "hB"
  ],
  GF: [
    "H",
    "hB"
  ],
  GN: [
    "H",
    "hB"
  ],
  GP: [
    "H",
    "hB"
  ],
  GW: [
    "H",
    "hB"
  ],
  HR: [
    "H",
    "hB"
  ],
  IL: [
    "H",
    "hB"
  ],
  IT: [
    "H",
    "hB"
  ],
  KZ: [
    "H",
    "hB"
  ],
  MC: [
    "H",
    "hB"
  ],
  MD: [
    "H",
    "hB"
  ],
  MF: [
    "H",
    "hB"
  ],
  MQ: [
    "H",
    "hB"
  ],
  MZ: [
    "H",
    "hB"
  ],
  NC: [
    "H",
    "hB"
  ],
  NL: [
    "H",
    "hB"
  ],
  PM: [
    "H",
    "hB"
  ],
  PT: [
    "H",
    "hB"
  ],
  RE: [
    "H",
    "hB"
  ],
  RO: [
    "H",
    "hB"
  ],
  SI: [
    "H",
    "hB"
  ],
  SR: [
    "H",
    "hB"
  ],
  ST: [
    "H",
    "hB"
  ],
  TG: [
    "H",
    "hB"
  ],
  TR: [
    "H",
    "hB"
  ],
  WF: [
    "H",
    "hB"
  ],
  YT: [
    "H",
    "hB"
  ],
  BD: [
    "h",
    "hB",
    "H"
  ],
  PK: [
    "h",
    "hB",
    "H"
  ],
  AZ: [
    "H",
    "hB",
    "h"
  ],
  BA: [
    "H",
    "hB",
    "h"
  ],
  BG: [
    "H",
    "hB",
    "h"
  ],
  CH: [
    "H",
    "hB",
    "h"
  ],
  GE: [
    "H",
    "hB",
    "h"
  ],
  LI: [
    "H",
    "hB",
    "h"
  ],
  ME: [
    "H",
    "hB",
    "h"
  ],
  RS: [
    "H",
    "hB",
    "h"
  ],
  UA: [
    "H",
    "hB",
    "h"
  ],
  UZ: [
    "H",
    "hB",
    "h"
  ],
  XK: [
    "H",
    "hB",
    "h"
  ],
  AG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  AU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  CA: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  DM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  "en-001": [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FJ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  FM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GD: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GU: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  GY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  JM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KN: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  KY: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  LR: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MH: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MP: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  MW: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  NZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SB: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SL: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SS: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  SZ: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  TT: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  UM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  US: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VC: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VG: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  VI: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  ZM: [
    "h",
    "hb",
    "H",
    "hB"
  ],
  BO: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  EC: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  ES: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  GQ: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  PE: [
    "H",
    "hB",
    "h",
    "hb"
  ],
  AE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  "ar-001": [
    "h",
    "hB",
    "hb",
    "H"
  ],
  BH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  DZ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EG: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  EH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  HK: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  IQ: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  JO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  KW: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LB: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  LY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MO: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  MR: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  OM: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PH: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  PS: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  QA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SA: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SD: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  SY: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  TN: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  YE: [
    "h",
    "hB",
    "hb",
    "H"
  ],
  AF: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  LA: [
    "H",
    "hb",
    "hB",
    "h"
  ],
  CN: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  LV: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  TL: [
    "H",
    "hB",
    "hb",
    "h"
  ],
  "zu-ZA": [
    "H",
    "hB",
    "hb",
    "h"
  ],
  CD: [
    "hB",
    "H"
  ],
  IR: [
    "hB",
    "H"
  ],
  "hi-IN": [
    "hB",
    "h",
    "H"
  ],
  "kn-IN": [
    "hB",
    "h",
    "H"
  ],
  "ml-IN": [
    "hB",
    "h",
    "H"
  ],
  "te-IN": [
    "hB",
    "h",
    "H"
  ],
  KH: [
    "hB",
    "h",
    "H",
    "hb"
  ],
  "ta-IN": [
    "hB",
    "h",
    "hb",
    "H"
  ],
  BN: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  MY: [
    "hb",
    "hB",
    "h",
    "H"
  ],
  ET: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "gu-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "mr-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  "pa-IN": [
    "hB",
    "hb",
    "h",
    "H"
  ],
  TW: [
    "hB",
    "hb",
    "h",
    "H"
  ],
  KE: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  MM: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  TZ: [
    "hB",
    "hb",
    "H",
    "h"
  ],
  UG: [
    "hB",
    "hb",
    "H",
    "h"
  ]
};
function Vc(e, t) {
  for (var n = "", i = 0; i < e.length; i++) {
    var r = e.charAt(i);
    if (r === "j") {
      for (var o = 0; i + 1 < e.length && e.charAt(i + 1) === r; )
        o++, i++;
      var a = 1 + (o & 1), s = o < 2 ? 1 : 3 + (o >> 1), u = "a", f = Wc(t);
      for ((f == "H" || f == "k") && (s = 0); s-- > 0; )
        n += u;
      for (; a-- > 0; )
        n = f + n;
    } else
      r === "J" ? n += "H" : n += r;
  }
  return n;
}
function Wc(e) {
  var t = e.hourCycle;
  if (t === void 0 && // @ts-ignore hourCycle(s) is not identified yet
  e.hourCycles && // @ts-ignore
  e.hourCycles.length && (t = e.hourCycles[0]), t)
    switch (t) {
      case "h24":
        return "k";
      case "h23":
        return "H";
      case "h12":
        return "h";
      case "h11":
        return "K";
      default:
        throw new Error("Invalid hourCycle");
    }
  var n = e.language, i;
  n !== "root" && (i = e.maximize().region);
  var r = zn[i || ""] || zn[n || ""] || zn["".concat(n, "-001")] || zn["001"];
  return r[0];
}
var Oi, Yc = new RegExp("^".concat(_a.source, "*")), Zc = new RegExp("".concat(_a.source, "*$"));
function me(e, t) {
  return { start: e, end: t };
}
var Jc = !!String.prototype.startsWith, Qc = !!String.fromCodePoint, Kc = !!Object.fromEntries, $c = !!String.prototype.codePointAt, ef = !!String.prototype.trimStart, tf = !!String.prototype.trimEnd, nf = !!Number.isSafeInteger, rf = nf ? Number.isSafeInteger : function(e) {
  return typeof e == "number" && isFinite(e) && Math.floor(e) === e && Math.abs(e) <= 9007199254740991;
}, rr = !0;
try {
  var of = wa("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  rr = ((Oi = of.exec("a")) === null || Oi === void 0 ? void 0 : Oi[0]) === "a";
} catch {
  rr = !1;
}
var eo = Jc ? (
  // Native
  function(t, n, i) {
    return t.startsWith(n, i);
  }
) : (
  // For IE11
  function(t, n, i) {
    return t.slice(i, i + n.length) === n;
  }
), or = Qc ? String.fromCodePoint : (
  // IE11
  function() {
    for (var t = [], n = 0; n < arguments.length; n++)
      t[n] = arguments[n];
    for (var i = "", r = t.length, o = 0, a; r > o; ) {
      if (a = t[o++], a > 1114111)
        throw RangeError(a + " is not a valid code point");
      i += a < 65536 ? String.fromCharCode(a) : String.fromCharCode(((a -= 65536) >> 10) + 55296, a % 1024 + 56320);
    }
    return i;
  }
), to = (
  // native
  Kc ? Object.fromEntries : (
    // Ponyfill
    function(t) {
      for (var n = {}, i = 0, r = t; i < r.length; i++) {
        var o = r[i], a = o[0], s = o[1];
        n[a] = s;
      }
      return n;
    }
  )
), va = $c ? (
  // Native
  function(t, n) {
    return t.codePointAt(n);
  }
) : (
  // IE 11
  function(t, n) {
    var i = t.length;
    if (!(n < 0 || n >= i)) {
      var r = t.charCodeAt(n), o;
      return r < 55296 || r > 56319 || n + 1 === i || (o = t.charCodeAt(n + 1)) < 56320 || o > 57343 ? r : (r - 55296 << 10) + (o - 56320) + 65536;
    }
  }
), af = ef ? (
  // Native
  function(t) {
    return t.trimStart();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace(Yc, "");
  }
), sf = tf ? (
  // Native
  function(t) {
    return t.trimEnd();
  }
) : (
  // Ponyfill
  function(t) {
    return t.replace(Zc, "");
  }
);
function wa(e, t) {
  return new RegExp(e, t);
}
var ar;
if (rr) {
  var no = wa("([^\\p{White_Space}\\p{Pattern_Syntax}]*)", "yu");
  ar = function(t, n) {
    var i;
    no.lastIndex = n;
    var r = no.exec(t);
    return (i = r[1]) !== null && i !== void 0 ? i : "";
  };
} else
  ar = function(t, n) {
    for (var i = []; ; ) {
      var r = va(t, n);
      if (r === void 0 || ya(r) || ff(r))
        break;
      i.push(r), n += r >= 65536 ? 2 : 1;
    }
    return or.apply(void 0, i);
  };
var lf = (
  /** @class */
  function() {
    function e(t, n) {
      n === void 0 && (n = {}), this.message = t, this.position = { offset: 0, line: 1, column: 1 }, this.ignoreTag = !!n.ignoreTag, this.locale = n.locale, this.requiresOtherClause = !!n.requiresOtherClause, this.shouldParseSkeletons = !!n.shouldParseSkeletons;
    }
    return e.prototype.parse = function() {
      if (this.offset() !== 0)
        throw Error("parser can only be used once");
      return this.parseMessage(0, "", !1);
    }, e.prototype.parseMessage = function(t, n, i) {
      for (var r = []; !this.isEOF(); ) {
        var o = this.char();
        if (o === 123) {
          var a = this.parseArgument(t, i);
          if (a.err)
            return a;
          r.push(a.val);
        } else {
          if (o === 125 && t > 0)
            break;
          if (o === 35 && (n === "plural" || n === "selectordinal")) {
            var s = this.clonePosition();
            this.bump(), r.push({
              type: Te.pound,
              location: me(s, this.clonePosition())
            });
          } else if (o === 60 && !this.ignoreTag && this.peek() === 47) {
            if (i)
              break;
            return this.error(de.UNMATCHED_CLOSING_TAG, me(this.clonePosition(), this.clonePosition()));
          } else if (o === 60 && !this.ignoreTag && sr(this.peek() || 0)) {
            var a = this.parseTag(t, n);
            if (a.err)
              return a;
            r.push(a.val);
          } else {
            var a = this.parseLiteral(t, n);
            if (a.err)
              return a;
            r.push(a.val);
          }
        }
      }
      return { val: r, err: null };
    }, e.prototype.parseTag = function(t, n) {
      var i = this.clonePosition();
      this.bump();
      var r = this.parseTagName();
      if (this.bumpSpace(), this.bumpIf("/>"))
        return {
          val: {
            type: Te.literal,
            value: "<".concat(r, "/>"),
            location: me(i, this.clonePosition())
          },
          err: null
        };
      if (this.bumpIf(">")) {
        var o = this.parseMessage(t + 1, n, !0);
        if (o.err)
          return o;
        var a = o.val, s = this.clonePosition();
        if (this.bumpIf("</")) {
          if (this.isEOF() || !sr(this.char()))
            return this.error(de.INVALID_TAG, me(s, this.clonePosition()));
          var u = this.clonePosition(), f = this.parseTagName();
          return r !== f ? this.error(de.UNMATCHED_CLOSING_TAG, me(u, this.clonePosition())) : (this.bumpSpace(), this.bumpIf(">") ? {
            val: {
              type: Te.tag,
              value: r,
              children: a,
              location: me(i, this.clonePosition())
            },
            err: null
          } : this.error(de.INVALID_TAG, me(s, this.clonePosition())));
        } else
          return this.error(de.UNCLOSED_TAG, me(i, this.clonePosition()));
      } else
        return this.error(de.INVALID_TAG, me(i, this.clonePosition()));
    }, e.prototype.parseTagName = function() {
      var t = this.offset();
      for (this.bump(); !this.isEOF() && cf(this.char()); )
        this.bump();
      return this.message.slice(t, this.offset());
    }, e.prototype.parseLiteral = function(t, n) {
      for (var i = this.clonePosition(), r = ""; ; ) {
        var o = this.tryParseQuote(n);
        if (o) {
          r += o;
          continue;
        }
        var a = this.tryParseUnquoted(t, n);
        if (a) {
          r += a;
          continue;
        }
        var s = this.tryParseLeftAngleBracket();
        if (s) {
          r += s;
          continue;
        }
        break;
      }
      var u = me(i, this.clonePosition());
      return {
        val: { type: Te.literal, value: r, location: u },
        err: null
      };
    }, e.prototype.tryParseLeftAngleBracket = function() {
      return !this.isEOF() && this.char() === 60 && (this.ignoreTag || // If at the opening tag or closing tag position, bail.
      !uf(this.peek() || 0)) ? (this.bump(), "<") : null;
    }, e.prototype.tryParseQuote = function(t) {
      if (this.isEOF() || this.char() !== 39)
        return null;
      switch (this.peek()) {
        case 39:
          return this.bump(), this.bump(), "'";
        case 123:
        case 60:
        case 62:
        case 125:
          break;
        case 35:
          if (t === "plural" || t === "selectordinal")
            break;
          return null;
        default:
          return null;
      }
      this.bump();
      var n = [this.char()];
      for (this.bump(); !this.isEOF(); ) {
        var i = this.char();
        if (i === 39)
          if (this.peek() === 39)
            n.push(39), this.bump();
          else {
            this.bump();
            break;
          }
        else
          n.push(i);
        this.bump();
      }
      return or.apply(void 0, n);
    }, e.prototype.tryParseUnquoted = function(t, n) {
      if (this.isEOF())
        return null;
      var i = this.char();
      return i === 60 || i === 123 || i === 35 && (n === "plural" || n === "selectordinal") || i === 125 && t > 0 ? null : (this.bump(), or(i));
    }, e.prototype.parseArgument = function(t, n) {
      var i = this.clonePosition();
      if (this.bump(), this.bumpSpace(), this.isEOF())
        return this.error(de.EXPECT_ARGUMENT_CLOSING_BRACE, me(i, this.clonePosition()));
      if (this.char() === 125)
        return this.bump(), this.error(de.EMPTY_ARGUMENT, me(i, this.clonePosition()));
      var r = this.parseIdentifierIfPossible().value;
      if (!r)
        return this.error(de.MALFORMED_ARGUMENT, me(i, this.clonePosition()));
      if (this.bumpSpace(), this.isEOF())
        return this.error(de.EXPECT_ARGUMENT_CLOSING_BRACE, me(i, this.clonePosition()));
      switch (this.char()) {
        case 125:
          return this.bump(), {
            val: {
              type: Te.argument,
              // value does not include the opening and closing braces.
              value: r,
              location: me(i, this.clonePosition())
            },
            err: null
          };
        case 44:
          return this.bump(), this.bumpSpace(), this.isEOF() ? this.error(de.EXPECT_ARGUMENT_CLOSING_BRACE, me(i, this.clonePosition())) : this.parseArgumentOptions(t, n, r, i);
        default:
          return this.error(de.MALFORMED_ARGUMENT, me(i, this.clonePosition()));
      }
    }, e.prototype.parseIdentifierIfPossible = function() {
      var t = this.clonePosition(), n = this.offset(), i = ar(this.message, n), r = n + i.length;
      this.bumpTo(r);
      var o = this.clonePosition(), a = me(t, o);
      return { value: i, location: a };
    }, e.prototype.parseArgumentOptions = function(t, n, i, r) {
      var o, a = this.clonePosition(), s = this.parseIdentifierIfPossible().value, u = this.clonePosition();
      switch (s) {
        case "":
          return this.error(de.EXPECT_ARGUMENT_TYPE, me(a, u));
        case "number":
        case "date":
        case "time": {
          this.bumpSpace();
          var f = null;
          if (this.bumpIf(",")) {
            this.bumpSpace();
            var h = this.clonePosition(), p = this.parseSimpleArgStyleIfPossible();
            if (p.err)
              return p;
            var g = sf(p.val);
            if (g.length === 0)
              return this.error(de.EXPECT_ARGUMENT_STYLE, me(this.clonePosition(), this.clonePosition()));
            var v = me(h, this.clonePosition());
            f = { style: g, styleLocation: v };
          }
          var B = this.tryParseArgumentClose(r);
          if (B.err)
            return B;
          var D = me(r, this.clonePosition());
          if (f && eo(f == null ? void 0 : f.style, "::", 0)) {
            var N = af(f.style.slice(2));
            if (s === "number") {
              var p = this.parseNumberSkeletonFromString(N, f.styleLocation);
              return p.err ? p : {
                val: { type: Te.number, value: i, location: D, style: p.val },
                err: null
              };
            } else {
              if (N.length === 0)
                return this.error(de.EXPECT_DATE_TIME_SKELETON, D);
              var K = N;
              this.locale && (K = Vc(N, this.locale));
              var g = {
                type: Kt.dateTime,
                pattern: K,
                location: f.styleLocation,
                parsedOptions: this.shouldParseSkeletons ? Uc(K) : {}
              }, x = s === "date" ? Te.date : Te.time;
              return {
                val: { type: x, value: i, location: D, style: g },
                err: null
              };
            }
          }
          return {
            val: {
              type: s === "number" ? Te.number : s === "date" ? Te.date : Te.time,
              value: i,
              location: D,
              style: (o = f == null ? void 0 : f.style) !== null && o !== void 0 ? o : null
            },
            err: null
          };
        }
        case "plural":
        case "selectordinal":
        case "select": {
          var M = this.clonePosition();
          if (this.bumpSpace(), !this.bumpIf(","))
            return this.error(de.EXPECT_SELECT_ARGUMENT_OPTIONS, me(M, ge({}, M)));
          this.bumpSpace();
          var H = this.parseIdentifierIfPossible(), A = 0;
          if (s !== "select" && H.value === "offset") {
            if (!this.bumpIf(":"))
              return this.error(de.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, me(this.clonePosition(), this.clonePosition()));
            this.bumpSpace();
            var p = this.tryParseDecimalInteger(de.EXPECT_PLURAL_ARGUMENT_OFFSET_VALUE, de.INVALID_PLURAL_ARGUMENT_OFFSET_VALUE);
            if (p.err)
              return p;
            this.bumpSpace(), H = this.parseIdentifierIfPossible(), A = p.val;
          }
          var E = this.tryParsePluralOrSelectOptions(t, s, n, H);
          if (E.err)
            return E;
          var B = this.tryParseArgumentClose(r);
          if (B.err)
            return B;
          var m = me(r, this.clonePosition());
          return s === "select" ? {
            val: {
              type: Te.select,
              value: i,
              options: to(E.val),
              location: m
            },
            err: null
          } : {
            val: {
              type: Te.plural,
              value: i,
              options: to(E.val),
              offset: A,
              pluralType: s === "plural" ? "cardinal" : "ordinal",
              location: m
            },
            err: null
          };
        }
        default:
          return this.error(de.INVALID_ARGUMENT_TYPE, me(a, u));
      }
    }, e.prototype.tryParseArgumentClose = function(t) {
      return this.isEOF() || this.char() !== 125 ? this.error(de.EXPECT_ARGUMENT_CLOSING_BRACE, me(t, this.clonePosition())) : (this.bump(), { val: !0, err: null });
    }, e.prototype.parseSimpleArgStyleIfPossible = function() {
      for (var t = 0, n = this.clonePosition(); !this.isEOF(); ) {
        var i = this.char();
        switch (i) {
          case 39: {
            this.bump();
            var r = this.clonePosition();
            if (!this.bumpUntil("'"))
              return this.error(de.UNCLOSED_QUOTE_IN_ARGUMENT_STYLE, me(r, this.clonePosition()));
            this.bump();
            break;
          }
          case 123: {
            t += 1, this.bump();
            break;
          }
          case 125: {
            if (t > 0)
              t -= 1;
            else
              return {
                val: this.message.slice(n.offset, this.offset()),
                err: null
              };
            break;
          }
          default:
            this.bump();
            break;
        }
      }
      return {
        val: this.message.slice(n.offset, this.offset()),
        err: null
      };
    }, e.prototype.parseNumberSkeletonFromString = function(t, n) {
      var i = [];
      try {
        i = Gc(t);
      } catch {
        return this.error(de.INVALID_NUMBER_SKELETON, n);
      }
      return {
        val: {
          type: Kt.number,
          tokens: i,
          location: n,
          parsedOptions: this.shouldParseSkeletons ? Xc(i) : {}
        },
        err: null
      };
    }, e.prototype.tryParsePluralOrSelectOptions = function(t, n, i, r) {
      for (var o, a = !1, s = [], u = /* @__PURE__ */ new Set(), f = r.value, h = r.location; ; ) {
        if (f.length === 0) {
          var p = this.clonePosition();
          if (n !== "select" && this.bumpIf("=")) {
            var g = this.tryParseDecimalInteger(de.EXPECT_PLURAL_ARGUMENT_SELECTOR, de.INVALID_PLURAL_ARGUMENT_SELECTOR);
            if (g.err)
              return g;
            h = me(p, this.clonePosition()), f = this.message.slice(p.offset, this.offset());
          } else
            break;
        }
        if (u.has(f))
          return this.error(n === "select" ? de.DUPLICATE_SELECT_ARGUMENT_SELECTOR : de.DUPLICATE_PLURAL_ARGUMENT_SELECTOR, h);
        f === "other" && (a = !0), this.bumpSpace();
        var v = this.clonePosition();
        if (!this.bumpIf("{"))
          return this.error(n === "select" ? de.EXPECT_SELECT_ARGUMENT_SELECTOR_FRAGMENT : de.EXPECT_PLURAL_ARGUMENT_SELECTOR_FRAGMENT, me(this.clonePosition(), this.clonePosition()));
        var B = this.parseMessage(t + 1, n, i);
        if (B.err)
          return B;
        var D = this.tryParseArgumentClose(v);
        if (D.err)
          return D;
        s.push([
          f,
          {
            value: B.val,
            location: me(v, this.clonePosition())
          }
        ]), u.add(f), this.bumpSpace(), o = this.parseIdentifierIfPossible(), f = o.value, h = o.location;
      }
      return s.length === 0 ? this.error(n === "select" ? de.EXPECT_SELECT_ARGUMENT_SELECTOR : de.EXPECT_PLURAL_ARGUMENT_SELECTOR, me(this.clonePosition(), this.clonePosition())) : this.requiresOtherClause && !a ? this.error(de.MISSING_OTHER_CLAUSE, me(this.clonePosition(), this.clonePosition())) : { val: s, err: null };
    }, e.prototype.tryParseDecimalInteger = function(t, n) {
      var i = 1, r = this.clonePosition();
      this.bumpIf("+") || this.bumpIf("-") && (i = -1);
      for (var o = !1, a = 0; !this.isEOF(); ) {
        var s = this.char();
        if (s >= 48 && s <= 57)
          o = !0, a = a * 10 + (s - 48), this.bump();
        else
          break;
      }
      var u = me(r, this.clonePosition());
      return o ? (a *= i, rf(a) ? { val: a, err: null } : this.error(n, u)) : this.error(t, u);
    }, e.prototype.offset = function() {
      return this.position.offset;
    }, e.prototype.isEOF = function() {
      return this.offset() === this.message.length;
    }, e.prototype.clonePosition = function() {
      return {
        offset: this.position.offset,
        line: this.position.line,
        column: this.position.column
      };
    }, e.prototype.char = function() {
      var t = this.position.offset;
      if (t >= this.message.length)
        throw Error("out of bound");
      var n = va(this.message, t);
      if (n === void 0)
        throw Error("Offset ".concat(t, " is at invalid UTF-16 code unit boundary"));
      return n;
    }, e.prototype.error = function(t, n) {
      return {
        val: null,
        err: {
          kind: t,
          message: this.message,
          location: n
        }
      };
    }, e.prototype.bump = function() {
      if (!this.isEOF()) {
        var t = this.char();
        t === 10 ? (this.position.line += 1, this.position.column = 1, this.position.offset += 1) : (this.position.column += 1, this.position.offset += t < 65536 ? 1 : 2);
      }
    }, e.prototype.bumpIf = function(t) {
      if (eo(this.message, t, this.offset())) {
        for (var n = 0; n < t.length; n++)
          this.bump();
        return !0;
      }
      return !1;
    }, e.prototype.bumpUntil = function(t) {
      var n = this.offset(), i = this.message.indexOf(t, n);
      return i >= 0 ? (this.bumpTo(i), !0) : (this.bumpTo(this.message.length), !1);
    }, e.prototype.bumpTo = function(t) {
      if (this.offset() > t)
        throw Error("targetOffset ".concat(t, " must be greater than or equal to the current offset ").concat(this.offset()));
      for (t = Math.min(t, this.message.length); ; ) {
        var n = this.offset();
        if (n === t)
          break;
        if (n > t)
          throw Error("targetOffset ".concat(t, " is at invalid UTF-16 code unit boundary"));
        if (this.bump(), this.isEOF())
          break;
      }
    }, e.prototype.bumpSpace = function() {
      for (; !this.isEOF() && ya(this.char()); )
        this.bump();
    }, e.prototype.peek = function() {
      if (this.isEOF())
        return null;
      var t = this.char(), n = this.offset(), i = this.message.charCodeAt(n + (t >= 65536 ? 2 : 1));
      return i ?? null;
    }, e;
  }()
);
function sr(e) {
  return e >= 97 && e <= 122 || e >= 65 && e <= 90;
}
function uf(e) {
  return sr(e) || e === 47;
}
function cf(e) {
  return e === 45 || e === 46 || e >= 48 && e <= 57 || e === 95 || e >= 97 && e <= 122 || e >= 65 && e <= 90 || e == 183 || e >= 192 && e <= 214 || e >= 216 && e <= 246 || e >= 248 && e <= 893 || e >= 895 && e <= 8191 || e >= 8204 && e <= 8205 || e >= 8255 && e <= 8256 || e >= 8304 && e <= 8591 || e >= 11264 && e <= 12271 || e >= 12289 && e <= 55295 || e >= 63744 && e <= 64975 || e >= 65008 && e <= 65533 || e >= 65536 && e <= 983039;
}
function ya(e) {
  return e >= 9 && e <= 13 || e === 32 || e === 133 || e >= 8206 && e <= 8207 || e === 8232 || e === 8233;
}
function ff(e) {
  return e >= 33 && e <= 35 || e === 36 || e >= 37 && e <= 39 || e === 40 || e === 41 || e === 42 || e === 43 || e === 44 || e === 45 || e >= 46 && e <= 47 || e >= 58 && e <= 59 || e >= 60 && e <= 62 || e >= 63 && e <= 64 || e === 91 || e === 92 || e === 93 || e === 94 || e === 96 || e === 123 || e === 124 || e === 125 || e === 126 || e === 161 || e >= 162 && e <= 165 || e === 166 || e === 167 || e === 169 || e === 171 || e === 172 || e === 174 || e === 176 || e === 177 || e === 182 || e === 187 || e === 191 || e === 215 || e === 247 || e >= 8208 && e <= 8213 || e >= 8214 && e <= 8215 || e === 8216 || e === 8217 || e === 8218 || e >= 8219 && e <= 8220 || e === 8221 || e === 8222 || e === 8223 || e >= 8224 && e <= 8231 || e >= 8240 && e <= 8248 || e === 8249 || e === 8250 || e >= 8251 && e <= 8254 || e >= 8257 && e <= 8259 || e === 8260 || e === 8261 || e === 8262 || e >= 8263 && e <= 8273 || e === 8274 || e === 8275 || e >= 8277 && e <= 8286 || e >= 8592 && e <= 8596 || e >= 8597 && e <= 8601 || e >= 8602 && e <= 8603 || e >= 8604 && e <= 8607 || e === 8608 || e >= 8609 && e <= 8610 || e === 8611 || e >= 8612 && e <= 8613 || e === 8614 || e >= 8615 && e <= 8621 || e === 8622 || e >= 8623 && e <= 8653 || e >= 8654 && e <= 8655 || e >= 8656 && e <= 8657 || e === 8658 || e === 8659 || e === 8660 || e >= 8661 && e <= 8691 || e >= 8692 && e <= 8959 || e >= 8960 && e <= 8967 || e === 8968 || e === 8969 || e === 8970 || e === 8971 || e >= 8972 && e <= 8991 || e >= 8992 && e <= 8993 || e >= 8994 && e <= 9e3 || e === 9001 || e === 9002 || e >= 9003 && e <= 9083 || e === 9084 || e >= 9085 && e <= 9114 || e >= 9115 && e <= 9139 || e >= 9140 && e <= 9179 || e >= 9180 && e <= 9185 || e >= 9186 && e <= 9254 || e >= 9255 && e <= 9279 || e >= 9280 && e <= 9290 || e >= 9291 && e <= 9311 || e >= 9472 && e <= 9654 || e === 9655 || e >= 9656 && e <= 9664 || e === 9665 || e >= 9666 && e <= 9719 || e >= 9720 && e <= 9727 || e >= 9728 && e <= 9838 || e === 9839 || e >= 9840 && e <= 10087 || e === 10088 || e === 10089 || e === 10090 || e === 10091 || e === 10092 || e === 10093 || e === 10094 || e === 10095 || e === 10096 || e === 10097 || e === 10098 || e === 10099 || e === 10100 || e === 10101 || e >= 10132 && e <= 10175 || e >= 10176 && e <= 10180 || e === 10181 || e === 10182 || e >= 10183 && e <= 10213 || e === 10214 || e === 10215 || e === 10216 || e === 10217 || e === 10218 || e === 10219 || e === 10220 || e === 10221 || e === 10222 || e === 10223 || e >= 10224 && e <= 10239 || e >= 10240 && e <= 10495 || e >= 10496 && e <= 10626 || e === 10627 || e === 10628 || e === 10629 || e === 10630 || e === 10631 || e === 10632 || e === 10633 || e === 10634 || e === 10635 || e === 10636 || e === 10637 || e === 10638 || e === 10639 || e === 10640 || e === 10641 || e === 10642 || e === 10643 || e === 10644 || e === 10645 || e === 10646 || e === 10647 || e === 10648 || e >= 10649 && e <= 10711 || e === 10712 || e === 10713 || e === 10714 || e === 10715 || e >= 10716 && e <= 10747 || e === 10748 || e === 10749 || e >= 10750 && e <= 11007 || e >= 11008 && e <= 11055 || e >= 11056 && e <= 11076 || e >= 11077 && e <= 11078 || e >= 11079 && e <= 11084 || e >= 11085 && e <= 11123 || e >= 11124 && e <= 11125 || e >= 11126 && e <= 11157 || e === 11158 || e >= 11159 && e <= 11263 || e >= 11776 && e <= 11777 || e === 11778 || e === 11779 || e === 11780 || e === 11781 || e >= 11782 && e <= 11784 || e === 11785 || e === 11786 || e === 11787 || e === 11788 || e === 11789 || e >= 11790 && e <= 11798 || e === 11799 || e >= 11800 && e <= 11801 || e === 11802 || e === 11803 || e === 11804 || e === 11805 || e >= 11806 && e <= 11807 || e === 11808 || e === 11809 || e === 11810 || e === 11811 || e === 11812 || e === 11813 || e === 11814 || e === 11815 || e === 11816 || e === 11817 || e >= 11818 && e <= 11822 || e === 11823 || e >= 11824 && e <= 11833 || e >= 11834 && e <= 11835 || e >= 11836 && e <= 11839 || e === 11840 || e === 11841 || e === 11842 || e >= 11843 && e <= 11855 || e >= 11856 && e <= 11857 || e === 11858 || e >= 11859 && e <= 11903 || e >= 12289 && e <= 12291 || e === 12296 || e === 12297 || e === 12298 || e === 12299 || e === 12300 || e === 12301 || e === 12302 || e === 12303 || e === 12304 || e === 12305 || e >= 12306 && e <= 12307 || e === 12308 || e === 12309 || e === 12310 || e === 12311 || e === 12312 || e === 12313 || e === 12314 || e === 12315 || e === 12316 || e === 12317 || e >= 12318 && e <= 12319 || e === 12320 || e === 12336 || e === 64830 || e === 64831 || e >= 65093 && e <= 65094;
}
function lr(e) {
  e.forEach(function(t) {
    if (delete t.location, fa(t) || ha(t))
      for (var n in t.options)
        delete t.options[n].location, lr(t.options[n].value);
    else
      la(t) && ma(t.style) || (ua(t) || ca(t)) && ir(t.style) ? delete t.style.location : da(t) && lr(t.children);
  });
}
function hf(e, t) {
  t === void 0 && (t = {}), t = ge({ shouldParseSkeletons: !0, requiresOtherClause: !0 }, t);
  var n = new lf(e, t).parse();
  if (n.err) {
    var i = SyntaxError(de[n.err.kind]);
    throw i.location = n.err.location, i.originalMessage = n.err.message, i;
  }
  return t != null && t.captureLocation || lr(n.val), n.val;
}
function Hi(e, t) {
  var n = t && t.cache ? t.cache : bf, i = t && t.serializer ? t.serializer : gf, r = t && t.strategy ? t.strategy : mf;
  return r(e, {
    cache: n,
    serializer: i
  });
}
function df(e) {
  return e == null || typeof e == "number" || typeof e == "boolean";
}
function Ea(e, t, n, i) {
  var r = df(i) ? i : n(i), o = t.get(r);
  return typeof o > "u" && (o = e.call(this, i), t.set(r, o)), o;
}
function Ta(e, t, n) {
  var i = Array.prototype.slice.call(arguments, 3), r = n(i), o = t.get(r);
  return typeof o > "u" && (o = e.apply(this, i), t.set(r, o)), o;
}
function mr(e, t, n, i, r) {
  return n.bind(t, e, i, r);
}
function mf(e, t) {
  var n = e.length === 1 ? Ea : Ta;
  return mr(e, this, n, t.cache.create(), t.serializer);
}
function _f(e, t) {
  return mr(e, this, Ta, t.cache.create(), t.serializer);
}
function pf(e, t) {
  return mr(e, this, Ea, t.cache.create(), t.serializer);
}
var gf = function() {
  return JSON.stringify(arguments);
};
function _r() {
  this.cache = /* @__PURE__ */ Object.create(null);
}
_r.prototype.get = function(e) {
  return this.cache[e];
};
_r.prototype.set = function(e, t) {
  this.cache[e] = t;
};
var bf = {
  create: function() {
    return new _r();
  }
}, ki = {
  variadic: _f,
  monadic: pf
}, $t;
(function(e) {
  e.MISSING_VALUE = "MISSING_VALUE", e.INVALID_VALUE = "INVALID_VALUE", e.MISSING_INTL_API = "MISSING_INTL_API";
})($t || ($t = {}));
var ui = (
  /** @class */
  function(e) {
    li(t, e);
    function t(n, i, r) {
      var o = e.call(this, n) || this;
      return o.code = i, o.originalMessage = r, o;
    }
    return t.prototype.toString = function() {
      return "[formatjs Error: ".concat(this.code, "] ").concat(this.message);
    }, t;
  }(Error)
), io = (
  /** @class */
  function(e) {
    li(t, e);
    function t(n, i, r, o) {
      return e.call(this, 'Invalid values for "'.concat(n, '": "').concat(i, '". Options are "').concat(Object.keys(r).join('", "'), '"'), $t.INVALID_VALUE, o) || this;
    }
    return t;
  }(ui)
), vf = (
  /** @class */
  function(e) {
    li(t, e);
    function t(n, i, r) {
      return e.call(this, 'Value for "'.concat(n, '" must be of type ').concat(i), $t.INVALID_VALUE, r) || this;
    }
    return t;
  }(ui)
), wf = (
  /** @class */
  function(e) {
    li(t, e);
    function t(n, i) {
      return e.call(this, 'The intl string context variable "'.concat(n, '" was not provided to the string "').concat(i, '"'), $t.MISSING_VALUE, i) || this;
    }
    return t;
  }(ui)
), Fe;
(function(e) {
  e[e.literal = 0] = "literal", e[e.object = 1] = "object";
})(Fe || (Fe = {}));
function yf(e) {
  return e.length < 2 ? e : e.reduce(function(t, n) {
    var i = t[t.length - 1];
    return !i || i.type !== Fe.literal || n.type !== Fe.literal ? t.push(n) : i.value += n.value, t;
  }, []);
}
function Ef(e) {
  return typeof e == "function";
}
function Jn(e, t, n, i, r, o, a) {
  if (e.length === 1 && Jr(e[0]))
    return [
      {
        type: Fe.literal,
        value: e[0].value
      }
    ];
  for (var s = [], u = 0, f = e; u < f.length; u++) {
    var h = f[u];
    if (Jr(h)) {
      s.push({
        type: Fe.literal,
        value: h.value
      });
      continue;
    }
    if (kc(h)) {
      typeof o == "number" && s.push({
        type: Fe.literal,
        value: n.getNumberFormat(t).format(o)
      });
      continue;
    }
    var p = h.value;
    if (!(r && p in r))
      throw new wf(p, a);
    var g = r[p];
    if (Hc(h)) {
      (!g || typeof g == "string" || typeof g == "number") && (g = typeof g == "string" || typeof g == "number" ? String(g) : ""), s.push({
        type: typeof g == "string" ? Fe.literal : Fe.object,
        value: g
      });
      continue;
    }
    if (ua(h)) {
      var v = typeof h.style == "string" ? i.date[h.style] : ir(h.style) ? h.style.parsedOptions : void 0;
      s.push({
        type: Fe.literal,
        value: n.getDateTimeFormat(t, v).format(g)
      });
      continue;
    }
    if (ca(h)) {
      var v = typeof h.style == "string" ? i.time[h.style] : ir(h.style) ? h.style.parsedOptions : i.time.medium;
      s.push({
        type: Fe.literal,
        value: n.getDateTimeFormat(t, v).format(g)
      });
      continue;
    }
    if (la(h)) {
      var v = typeof h.style == "string" ? i.number[h.style] : ma(h.style) ? h.style.parsedOptions : void 0;
      v && v.scale && (g = g * (v.scale || 1)), s.push({
        type: Fe.literal,
        value: n.getNumberFormat(t, v).format(g)
      });
      continue;
    }
    if (da(h)) {
      var B = h.children, D = h.value, N = r[D];
      if (!Ef(N))
        throw new vf(D, "function", a);
      var K = Jn(B, t, n, i, r, o), x = N(K.map(function(A) {
        return A.value;
      }));
      Array.isArray(x) || (x = [x]), s.push.apply(s, x.map(function(A) {
        return {
          type: typeof A == "string" ? Fe.literal : Fe.object,
          value: A
        };
      }));
    }
    if (fa(h)) {
      var M = h.options[g] || h.options.other;
      if (!M)
        throw new io(h.value, g, Object.keys(h.options), a);
      s.push.apply(s, Jn(M.value, t, n, i, r));
      continue;
    }
    if (ha(h)) {
      var M = h.options["=".concat(g)];
      if (!M) {
        if (!Intl.PluralRules)
          throw new ui(`Intl.PluralRules is not available in this environment.
Try polyfilling it using "@formatjs/intl-pluralrules"
`, $t.MISSING_INTL_API, a);
        var H = n.getPluralRules(t, { type: h.pluralType }).select(g - (h.offset || 0));
        M = h.options[H] || h.options.other;
      }
      if (!M)
        throw new io(h.value, g, Object.keys(h.options), a);
      s.push.apply(s, Jn(M.value, t, n, i, r, g - (h.offset || 0)));
      continue;
    }
  }
  return yf(s);
}
function Tf(e, t) {
  return t ? ge(ge(ge({}, e || {}), t || {}), Object.keys(e).reduce(function(n, i) {
    return n[i] = ge(ge({}, e[i]), t[i] || {}), n;
  }, {})) : e;
}
function Pf(e, t) {
  return t ? Object.keys(e).reduce(function(n, i) {
    return n[i] = Tf(e[i], t[i]), n;
  }, ge({}, e)) : e;
}
function Di(e) {
  return {
    create: function() {
      return {
        get: function(t) {
          return e[t];
        },
        set: function(t, n) {
          e[t] = n;
        }
      };
    }
  };
}
function Mf(e) {
  return e === void 0 && (e = {
    number: {},
    dateTime: {},
    pluralRules: {}
  }), {
    getNumberFormat: Hi(function() {
      for (var t, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((t = Intl.NumberFormat).bind.apply(t, Ni([void 0], n, !1)))();
    }, {
      cache: Di(e.number),
      strategy: ki.variadic
    }),
    getDateTimeFormat: Hi(function() {
      for (var t, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((t = Intl.DateTimeFormat).bind.apply(t, Ni([void 0], n, !1)))();
    }, {
      cache: Di(e.dateTime),
      strategy: ki.variadic
    }),
    getPluralRules: Hi(function() {
      for (var t, n = [], i = 0; i < arguments.length; i++)
        n[i] = arguments[i];
      return new ((t = Intl.PluralRules).bind.apply(t, Ni([void 0], n, !1)))();
    }, {
      cache: Di(e.pluralRules),
      strategy: ki.variadic
    })
  };
}
var Sf = (
  /** @class */
  function() {
    function e(t, n, i, r) {
      var o = this;
      if (n === void 0 && (n = e.defaultLocale), this.formatterCache = {
        number: {},
        dateTime: {},
        pluralRules: {}
      }, this.format = function(a) {
        var s = o.formatToParts(a);
        if (s.length === 1)
          return s[0].value;
        var u = s.reduce(function(f, h) {
          return !f.length || h.type !== Fe.literal || typeof f[f.length - 1] != "string" ? f.push(h.value) : f[f.length - 1] += h.value, f;
        }, []);
        return u.length <= 1 ? u[0] || "" : u;
      }, this.formatToParts = function(a) {
        return Jn(o.ast, o.locales, o.formatters, o.formats, a, void 0, o.message);
      }, this.resolvedOptions = function() {
        return {
          locale: o.resolvedLocale.toString()
        };
      }, this.getAst = function() {
        return o.ast;
      }, this.locales = n, this.resolvedLocale = e.resolveLocale(n), typeof t == "string") {
        if (this.message = t, !e.__parse)
          throw new TypeError("IntlMessageFormat.__parse must be set to process `message` of type `string`");
        this.ast = e.__parse(t, {
          ignoreTag: r == null ? void 0 : r.ignoreTag,
          locale: this.resolvedLocale
        });
      } else
        this.ast = t;
      if (!Array.isArray(this.ast))
        throw new TypeError("A message must be provided as a String or AST.");
      this.formats = Pf(e.formats, i), this.formatters = r && r.formatters || Mf(this.formatterCache);
    }
    return Object.defineProperty(e, "defaultLocale", {
      get: function() {
        return e.memoizedDefaultLocale || (e.memoizedDefaultLocale = new Intl.NumberFormat().resolvedOptions().locale), e.memoizedDefaultLocale;
      },
      enumerable: !1,
      configurable: !0
    }), e.memoizedDefaultLocale = null, e.resolveLocale = function(t) {
      var n = Intl.NumberFormat.supportedLocalesOf(t);
      return n.length > 0 ? new Intl.Locale(n[0]) : new Intl.Locale(typeof t == "string" ? t : t[0]);
    }, e.__parse = hf, e.formats = {
      number: {
        integer: {
          maximumFractionDigits: 0
        },
        currency: {
          style: "currency"
        },
        percent: {
          style: "percent"
        }
      },
      date: {
        short: {
          month: "numeric",
          day: "numeric",
          year: "2-digit"
        },
        medium: {
          month: "short",
          day: "numeric",
          year: "numeric"
        },
        long: {
          month: "long",
          day: "numeric",
          year: "numeric"
        },
        full: {
          weekday: "long",
          month: "long",
          day: "numeric",
          year: "numeric"
        }
      },
      time: {
        short: {
          hour: "numeric",
          minute: "numeric"
        },
        medium: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric"
        },
        long: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        },
        full: {
          hour: "numeric",
          minute: "numeric",
          second: "numeric",
          timeZoneName: "short"
        }
      }
    }, e;
  }()
);
function Cf(e, t) {
  if (t == null)
    return;
  if (t in e)
    return e[t];
  const n = t.split(".");
  let i = e;
  for (let r = 0; r < n.length; r++)
    if (typeof i == "object") {
      if (r > 0) {
        const o = n.slice(r, n.length).join(".");
        if (o in i) {
          i = i[o];
          break;
        }
      }
      i = i[n[r]];
    } else
      i = void 0;
  return i;
}
const St = {}, xf = (e, t, n) => n && (t in St || (St[t] = {}), e in St[t] || (St[t][e] = n), n), Pa = (e, t) => {
  if (t == null)
    return;
  if (t in St && e in St[t])
    return St[t][e];
  const n = ci(t);
  for (let i = 0; i < n.length; i++) {
    const r = n[i], o = Af(r, e);
    if (o)
      return xf(e, t, o);
  }
};
let pr;
const Rn = An({});
function If(e) {
  return pr[e] || null;
}
function Ma(e) {
  return e in pr;
}
function Af(e, t) {
  if (!Ma(e))
    return null;
  const n = If(e);
  return Cf(n, t);
}
function Rf(e) {
  if (e == null)
    return;
  const t = ci(e);
  for (let n = 0; n < t.length; n++) {
    const i = t[n];
    if (Ma(i))
      return i;
  }
}
function Lf(e, ...t) {
  delete St[e], Rn.update((n) => (n[e] = Oc.all([n[e] || {}, ...t]), n));
}
cn(
  [Rn],
  ([e]) => Object.keys(e)
);
Rn.subscribe((e) => pr = e);
const Qn = {};
function Bf(e, t) {
  Qn[e].delete(t), Qn[e].size === 0 && delete Qn[e];
}
function Sa(e) {
  return Qn[e];
}
function Nf(e) {
  return ci(e).map((t) => {
    const n = Sa(t);
    return [t, n ? [...n] : []];
  }).filter(([, t]) => t.length > 0);
}
function ur(e) {
  return e == null ? !1 : ci(e).some(
    (t) => {
      var n;
      return (n = Sa(t)) == null ? void 0 : n.size;
    }
  );
}
function Of(e, t) {
  return Promise.all(
    t.map((i) => (Bf(e, i), i().then((r) => r.default || r)))
  ).then((i) => Lf(e, ...i));
}
const wn = {};
function Ca(e) {
  if (!ur(e))
    return e in wn ? wn[e] : Promise.resolve();
  const t = Nf(e);
  return wn[e] = Promise.all(
    t.map(
      ([n, i]) => Of(n, i)
    )
  ).then(() => {
    if (ur(e))
      return Ca(e);
    delete wn[e];
  }), wn[e];
}
const Hf = {
  number: {
    scientific: { notation: "scientific" },
    engineering: { notation: "engineering" },
    compactLong: { notation: "compact", compactDisplay: "long" },
    compactShort: { notation: "compact", compactDisplay: "short" }
  },
  date: {
    short: { month: "numeric", day: "numeric", year: "2-digit" },
    medium: { month: "short", day: "numeric", year: "numeric" },
    long: { month: "long", day: "numeric", year: "numeric" },
    full: { weekday: "long", month: "long", day: "numeric", year: "numeric" }
  },
  time: {
    short: { hour: "numeric", minute: "numeric" },
    medium: { hour: "numeric", minute: "numeric", second: "numeric" },
    long: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    },
    full: {
      hour: "numeric",
      minute: "numeric",
      second: "numeric",
      timeZoneName: "short"
    }
  }
}, kf = {
  fallbackLocale: null,
  loadingDelay: 200,
  formats: Hf,
  warnOnMissingMessages: !0,
  handleMissingMessage: void 0,
  ignoreTag: !0
}, Df = kf;
function en() {
  return Df;
}
const Ui = An(!1);
var Uf = Object.defineProperty, Ff = Object.defineProperties, Gf = Object.getOwnPropertyDescriptors, ro = Object.getOwnPropertySymbols, zf = Object.prototype.hasOwnProperty, qf = Object.prototype.propertyIsEnumerable, oo = (e, t, n) => t in e ? Uf(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, jf = (e, t) => {
  for (var n in t || (t = {}))
    zf.call(t, n) && oo(e, n, t[n]);
  if (ro)
    for (var n of ro(t))
      qf.call(t, n) && oo(e, n, t[n]);
  return e;
}, Xf = (e, t) => Ff(e, Gf(t));
let cr;
const Kn = An(null);
function ao(e) {
  return e.split("-").map((t, n, i) => i.slice(0, n + 1).join("-")).reverse();
}
function ci(e, t = en().fallbackLocale) {
  const n = ao(e);
  return t ? [.../* @__PURE__ */ new Set([...n, ...ao(t)])] : n;
}
function Dt() {
  return cr ?? void 0;
}
Kn.subscribe((e) => {
  cr = e ?? void 0, typeof window < "u" && e != null && document.documentElement.setAttribute("lang", e);
});
const Vf = (e) => {
  if (e && Rf(e) && ur(e)) {
    const { loadingDelay: t } = en();
    let n;
    return typeof window < "u" && Dt() != null && t ? n = window.setTimeout(
      () => Ui.set(!0),
      t
    ) : Ui.set(!0), Ca(e).then(() => {
      Kn.set(e);
    }).finally(() => {
      clearTimeout(n), Ui.set(!1);
    });
  }
  return Kn.set(e);
}, Ln = Xf(jf({}, Kn), {
  set: Vf
}), fi = (e) => {
  const t = /* @__PURE__ */ Object.create(null);
  return (i) => {
    const r = JSON.stringify(i);
    return r in t ? t[r] : t[r] = e(i);
  };
};
var Wf = Object.defineProperty, $n = Object.getOwnPropertySymbols, xa = Object.prototype.hasOwnProperty, Ia = Object.prototype.propertyIsEnumerable, so = (e, t, n) => t in e ? Wf(e, t, { enumerable: !0, configurable: !0, writable: !0, value: n }) : e[t] = n, gr = (e, t) => {
  for (var n in t || (t = {}))
    xa.call(t, n) && so(e, n, t[n]);
  if ($n)
    for (var n of $n(t))
      Ia.call(t, n) && so(e, n, t[n]);
  return e;
}, fn = (e, t) => {
  var n = {};
  for (var i in e)
    xa.call(e, i) && t.indexOf(i) < 0 && (n[i] = e[i]);
  if (e != null && $n)
    for (var i of $n(e))
      t.indexOf(i) < 0 && Ia.call(e, i) && (n[i] = e[i]);
  return n;
};
const In = (e, t) => {
  const { formats: n } = en();
  if (e in n && t in n[e])
    return n[e][t];
  throw new Error(`[svelte-i18n] Unknown "${t}" ${e} format.`);
}, Yf = fi(
  (e) => {
    var t = e, { locale: n, format: i } = t, r = fn(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format numbers');
    return i && (r = In("number", i)), new Intl.NumberFormat(n, r);
  }
), Zf = fi(
  (e) => {
    var t = e, { locale: n, format: i } = t, r = fn(t, ["locale", "format"]);
    if (n == null)
      throw new Error('[svelte-i18n] A "locale" must be set to format dates');
    return i ? r = In("date", i) : Object.keys(r).length === 0 && (r = In("date", "short")), new Intl.DateTimeFormat(n, r);
  }
), Jf = fi(
  (e) => {
    var t = e, { locale: n, format: i } = t, r = fn(t, ["locale", "format"]);
    if (n == null)
      throw new Error(
        '[svelte-i18n] A "locale" must be set to format time values'
      );
    return i ? r = In("time", i) : Object.keys(r).length === 0 && (r = In("time", "short")), new Intl.DateTimeFormat(n, r);
  }
), Qf = (e = {}) => {
  var t = e, {
    locale: n = Dt()
  } = t, i = fn(t, [
    "locale"
  ]);
  return Yf(gr({ locale: n }, i));
}, Kf = (e = {}) => {
  var t = e, {
    locale: n = Dt()
  } = t, i = fn(t, [
    "locale"
  ]);
  return Zf(gr({ locale: n }, i));
}, $f = (e = {}) => {
  var t = e, {
    locale: n = Dt()
  } = t, i = fn(t, [
    "locale"
  ]);
  return Jf(gr({ locale: n }, i));
}, eh = fi(
  // eslint-disable-next-line @typescript-eslint/no-non-null-assertion
  (e, t = Dt()) => new Sf(e, t, en().formats, {
    ignoreTag: en().ignoreTag
  })
), th = (e, t = {}) => {
  var n, i, r, o;
  let a = t;
  typeof e == "object" && (a = e, e = a.id);
  const {
    values: s,
    locale: u = Dt(),
    default: f
  } = a;
  if (u == null)
    throw new Error(
      "[svelte-i18n] Cannot format a message without first setting the initial locale."
    );
  let h = Pa(e, u);
  if (!h)
    h = (o = (r = (i = (n = en()).handleMissingMessage) == null ? void 0 : i.call(n, { locale: u, id: e, defaultValue: f })) != null ? r : f) != null ? o : e;
  else if (typeof h != "string")
    return console.warn(
      `[svelte-i18n] Message with id "${e}" must be of type "string", found: "${typeof h}". Gettin its value through the "$format" method is deprecated; use the "json" method instead.`
    ), h;
  if (!s)
    return h;
  let p = h;
  try {
    p = eh(h, u).format(s);
  } catch (g) {
    g instanceof Error && console.warn(
      `[svelte-i18n] Message "${e}" has syntax error:`,
      g.message
    );
  }
  return p;
}, nh = (e, t) => $f(t).format(e), ih = (e, t) => Kf(t).format(e), rh = (e, t) => Qf(t).format(e), oh = (e, t = Dt()) => Pa(e, t);
cn([Ln, Rn], () => th);
cn([Ln], () => nh);
cn([Ln], () => ih);
cn([Ln], () => rh);
cn([Ln, Rn], () => oh);
const {
  SvelteComponent: ah,
  append: ze,
  attr: Bt,
  detach: Aa,
  element: Nt,
  init: sh,
  insert: Ra,
  noop: lo,
  safe_not_equal: lh,
  set_data: ei,
  set_style: Fi,
  space: fr,
  text: Vt,
  toggle_class: uo
} = window.__gradio__svelte__internal, { onMount: uh, createEventDispatcher: ch } = window.__gradio__svelte__internal;
function co(e) {
  let t, n, i, r, o = Tn(
    /*current_file_upload*/
    e[2]
  ) + "", a, s, u, f, h = (
    /*current_file_upload*/
    e[2].orig_name + ""
  ), p;
  return {
    c() {
      t = Nt("div"), n = Nt("span"), i = Nt("div"), r = Nt("progress"), a = Vt(o), u = fr(), f = Nt("span"), p = Vt(h), Fi(r, "visibility", "hidden"), Fi(r, "height", "0"), Fi(r, "width", "0"), r.value = s = Tn(
        /*current_file_upload*/
        e[2]
      ), Bt(r, "max", "100"), Bt(r, "class", "svelte-12ckl9l"), Bt(i, "class", "progress-bar svelte-12ckl9l"), Bt(f, "class", "file-name svelte-12ckl9l"), Bt(t, "class", "file svelte-12ckl9l");
    },
    m(g, v) {
      Ra(g, t, v), ze(t, n), ze(n, i), ze(i, r), ze(r, a), ze(t, u), ze(t, f), ze(f, p);
    },
    p(g, v) {
      v & /*current_file_upload*/
      4 && o !== (o = Tn(
        /*current_file_upload*/
        g[2]
      ) + "") && ei(a, o), v & /*current_file_upload*/
      4 && s !== (s = Tn(
        /*current_file_upload*/
        g[2]
      )) && (r.value = s), v & /*current_file_upload*/
      4 && h !== (h = /*current_file_upload*/
      g[2].orig_name + "") && ei(p, h);
    },
    d(g) {
      g && Aa(t);
    }
  };
}
function fh(e) {
  let t, n, i, r = (
    /*files_with_progress*/
    e[0].length + ""
  ), o, a, s = (
    /*files_with_progress*/
    e[0].length > 1 ? "files" : "file"
  ), u, f, h, p = (
    /*current_file_upload*/
    e[2] && co(e)
  );
  return {
    c() {
      t = Nt("div"), n = Nt("span"), i = Vt("Uploading "), o = Vt(r), a = fr(), u = Vt(s), f = Vt("..."), h = fr(), p && p.c(), Bt(n, "class", "uploading svelte-12ckl9l"), Bt(t, "class", "wrap svelte-12ckl9l"), uo(
        t,
        "progress",
        /*progress*/
        e[1]
      );
    },
    m(g, v) {
      Ra(g, t, v), ze(t, n), ze(n, i), ze(n, o), ze(n, a), ze(n, u), ze(n, f), ze(t, h), p && p.m(t, null);
    },
    p(g, [v]) {
      v & /*files_with_progress*/
      1 && r !== (r = /*files_with_progress*/
      g[0].length + "") && ei(o, r), v & /*files_with_progress*/
      1 && s !== (s = /*files_with_progress*/
      g[0].length > 1 ? "files" : "file") && ei(u, s), /*current_file_upload*/
      g[2] ? p ? p.p(g, v) : (p = co(g), p.c(), p.m(t, null)) : p && (p.d(1), p = null), v & /*progress*/
      2 && uo(
        t,
        "progress",
        /*progress*/
        g[1]
      );
    },
    i: lo,
    o: lo,
    d(g) {
      g && Aa(t), p && p.d();
    }
  };
}
function Tn(e) {
  return e.progress * 100 / (e.size || 0) || 0;
}
function hh(e) {
  let t = 0;
  return e.forEach((n) => {
    t += Tn(n);
  }), document.documentElement.style.setProperty("--upload-progress-width", (t / e.length).toFixed(2) + "%"), t / e.length;
}
function dh(e, t, n) {
  let { upload_id: i } = t, { root: r } = t, { files: o } = t, a, s = !1, u, f = o.map((g) => ({ ...g, progress: 0 }));
  const h = ch();
  function p(g, v) {
    n(0, f = f.map((B) => (B.orig_name === g && (B.progress += v), B)));
  }
  return uh(() => {
    a = new EventSource(`${r}/upload_progress?upload_id=${i}`), a.onmessage = async function(g) {
      const v = JSON.parse(g.data);
      s || n(1, s = !0), v.msg === "done" ? (a.close(), h("done")) : (n(2, u = v), p(v.orig_name, v.chunk_size));
    };
  }), e.$$set = (g) => {
    "upload_id" in g && n(3, i = g.upload_id), "root" in g && n(4, r = g.root), "files" in g && n(5, o = g.files);
  }, e.$$.update = () => {
    e.$$.dirty & /*files_with_progress*/
    1 && hh(f);
  }, [f, s, u, i, r, o];
}
class mh extends ah {
  constructor(t) {
    super(), sh(this, t, dh, fh, lh, { upload_id: 3, root: 4, files: 5 });
  }
}
const {
  SvelteComponent: _h,
  append: fo,
  attr: ht,
  binding_callbacks: ph,
  bubble: It,
  check_outros: gh,
  create_component: bh,
  create_slot: vh,
  destroy_component: wh,
  detach: La,
  element: ho,
  empty: yh,
  get_all_dirty_from_scope: Eh,
  get_slot_changes: Th,
  group_outros: Ph,
  init: Mh,
  insert: Ba,
  listen: Ye,
  mount_component: Sh,
  prevent_default: At,
  run_all: Ch,
  safe_not_equal: xh,
  set_style: mo,
  space: Ih,
  stop_propagation: Rt,
  toggle_class: Pt,
  transition_in: ti,
  transition_out: ni,
  update_slot_base: Ah
} = window.__gradio__svelte__internal, { createEventDispatcher: Rh, tick: Lh, getContext: Bh } = window.__gradio__svelte__internal;
function Nh(e) {
  let t, n, i, r, o, a, s, u, f;
  const h = (
    /*#slots*/
    e[20].default
  ), p = vh(
    h,
    e,
    /*$$scope*/
    e[19],
    null
  );
  return {
    c() {
      t = ho("button"), p && p.c(), n = Ih(), i = ho("input"), ht(i, "type", "file"), ht(
        i,
        "accept",
        /*filetype*/
        e[0]
      ), i.multiple = r = /*file_count*/
      e[4] === "multiple" || void 0, ht(i, "webkitdirectory", o = /*file_count*/
      e[4] === "directory" || void 0), ht(i, "mozdirectory", a = /*file_count*/
      e[4] === "directory" || void 0), ht(i, "class", "svelte-a356bc"), ht(t, "class", "svelte-a356bc"), Pt(
        t,
        "hidden",
        /*hidden*/
        e[6]
      ), Pt(
        t,
        "center",
        /*center*/
        e[2]
      ), Pt(
        t,
        "boundedheight",
        /*boundedheight*/
        e[1]
      ), Pt(
        t,
        "flex",
        /*flex*/
        e[3]
      ), mo(
        t,
        "height",
        /*include_sources*/
        e[7] ? "calc(100% - 40px" : "100%"
      );
    },
    m(g, v) {
      Ba(g, t, v), p && p.m(t, null), fo(t, n), fo(t, i), e[28](i), s = !0, u || (f = [
        Ye(
          i,
          "change",
          /*load_files_from_upload*/
          e[14]
        ),
        Ye(t, "drag", Rt(At(
          /*drag_handler*/
          e[21]
        ))),
        Ye(t, "dragstart", Rt(At(
          /*dragstart_handler*/
          e[22]
        ))),
        Ye(t, "dragend", Rt(At(
          /*dragend_handler*/
          e[23]
        ))),
        Ye(t, "dragover", Rt(At(
          /*dragover_handler*/
          e[24]
        ))),
        Ye(t, "dragenter", Rt(At(
          /*dragenter_handler*/
          e[25]
        ))),
        Ye(t, "dragleave", Rt(At(
          /*dragleave_handler*/
          e[26]
        ))),
        Ye(t, "drop", Rt(At(
          /*drop_handler*/
          e[27]
        ))),
        Ye(
          t,
          "click",
          /*open_file_upload*/
          e[8]
        ),
        Ye(
          t,
          "drop",
          /*loadFilesFromDrop*/
          e[15]
        ),
        Ye(
          t,
          "dragenter",
          /*updateDragging*/
          e[13]
        ),
        Ye(
          t,
          "dragleave",
          /*updateDragging*/
          e[13]
        )
      ], u = !0);
    },
    p(g, v) {
      p && p.p && (!s || v[0] & /*$$scope*/
      524288) && Ah(
        p,
        h,
        g,
        /*$$scope*/
        g[19],
        s ? Th(
          h,
          /*$$scope*/
          g[19],
          v,
          null
        ) : Eh(
          /*$$scope*/
          g[19]
        ),
        null
      ), (!s || v[0] & /*filetype*/
      1) && ht(
        i,
        "accept",
        /*filetype*/
        g[0]
      ), (!s || v[0] & /*file_count*/
      16 && r !== (r = /*file_count*/
      g[4] === "multiple" || void 0)) && (i.multiple = r), (!s || v[0] & /*file_count*/
      16 && o !== (o = /*file_count*/
      g[4] === "directory" || void 0)) && ht(i, "webkitdirectory", o), (!s || v[0] & /*file_count*/
      16 && a !== (a = /*file_count*/
      g[4] === "directory" || void 0)) && ht(i, "mozdirectory", a), (!s || v[0] & /*hidden*/
      64) && Pt(
        t,
        "hidden",
        /*hidden*/
        g[6]
      ), (!s || v[0] & /*center*/
      4) && Pt(
        t,
        "center",
        /*center*/
        g[2]
      ), (!s || v[0] & /*boundedheight*/
      2) && Pt(
        t,
        "boundedheight",
        /*boundedheight*/
        g[1]
      ), (!s || v[0] & /*flex*/
      8) && Pt(
        t,
        "flex",
        /*flex*/
        g[3]
      ), v[0] & /*include_sources*/
      128 && mo(
        t,
        "height",
        /*include_sources*/
        g[7] ? "calc(100% - 40px" : "100%"
      );
    },
    i(g) {
      s || (ti(p, g), s = !0);
    },
    o(g) {
      ni(p, g), s = !1;
    },
    d(g) {
      g && La(t), p && p.d(g), e[28](null), u = !1, Ch(f);
    }
  };
}
function Oh(e) {
  let t, n;
  return t = new mh({
    props: {
      root: (
        /*root*/
        e[5]
      ),
      upload_id: (
        /*upload_id*/
        e[10]
      ),
      files: (
        /*file_data*/
        e[11]
      )
    }
  }), {
    c() {
      bh(t.$$.fragment);
    },
    m(i, r) {
      Sh(t, i, r), n = !0;
    },
    p(i, r) {
      const o = {};
      r[0] & /*root*/
      32 && (o.root = /*root*/
      i[5]), r[0] & /*upload_id*/
      1024 && (o.upload_id = /*upload_id*/
      i[10]), r[0] & /*file_data*/
      2048 && (o.files = /*file_data*/
      i[11]), t.$set(o);
    },
    i(i) {
      n || (ti(t.$$.fragment, i), n = !0);
    },
    o(i) {
      ni(t.$$.fragment, i), n = !1;
    },
    d(i) {
      wh(t, i);
    }
  };
}
function Hh(e) {
  let t, n, i, r;
  const o = [Oh, Nh], a = [];
  function s(u, f) {
    return (
      /*uploading*/
      u[9] ? 0 : 1
    );
  }
  return t = s(e), n = a[t] = o[t](e), {
    c() {
      n.c(), i = yh();
    },
    m(u, f) {
      a[t].m(u, f), Ba(u, i, f), r = !0;
    },
    p(u, f) {
      let h = t;
      t = s(u), t === h ? a[t].p(u, f) : (Ph(), ni(a[h], 1, 1, () => {
        a[h] = null;
      }), gh(), n = a[t], n ? n.p(u, f) : (n = a[t] = o[t](u), n.c()), ti(n, 1), n.m(i.parentNode, i));
    },
    i(u) {
      r || (ti(n), r = !0);
    },
    o(u) {
      ni(n), r = !1;
    },
    d(u) {
      u && La(i), a[t].d(u);
    }
  };
}
function Gi(e) {
  let t, n = e[0], i = 1;
  for (; i < e.length; ) {
    const r = e[i], o = e[i + 1];
    if (i += 2, (r === "optionalAccess" || r === "optionalCall") && n == null)
      return;
    r === "access" || r === "optionalAccess" ? (t = n, n = o(n)) : (r === "call" || r === "optionalCall") && (n = o((...a) => n.call(t, ...a)), t = void 0);
  }
  return n;
}
function kh(e, t) {
  return !e || e === "*" ? !0 : e.endsWith("/*") ? t.startsWith(e.slice(0, -1)) : e === t;
}
function Dh(e, t, n) {
  let { $$slots: i = {}, $$scope: r } = t, { filetype: o = null } = t, { dragging: a = !1 } = t, { boundedheight: s = !0 } = t, { center: u = !0 } = t, { flex: f = !0 } = t, { file_count: h = "single" } = t, { disable_click: p = !1 } = t, { root: g } = t, { hidden: v = !1 } = t, { include_sources: B = !1 } = t, D = !1, N, K;
  const x = Bh("upload_files");
  let M;
  const H = Rh();
  function A() {
    n(16, a = !a);
  }
  function E() {
    p || (n(12, M.value = "", M), M.click());
  }
  async function m(k) {
    await Lh(), n(10, N = Math.random().toString(36).substring(2, 15)), n(9, D = !0);
    const ie = await Uu(k, g, N, x);
    return H("load", h === "single" ? Gi([ie, "optionalAccess", (R) => R[0]]) : ie), n(9, D = !1), ie || [];
  }
  async function fe(k) {
    if (!k.length)
      return;
    let ie = k.map((R) => new File([R], R.name));
    return n(11, K = await Fu(ie)), await m(K);
  }
  async function be(k) {
    const ie = k.target;
    ie.files && await fe(Array.from(ie.files));
  }
  async function ve(k) {
    if (n(16, a = !1), !Gi([k, "access", (R) => R.dataTransfer, "optionalAccess", (R) => R.files]))
      return;
    const ie = Array.from(k.dataTransfer.files).filter((R) => Gi([
      o,
      "optionalAccess",
      (ye) => ye.split,
      "call",
      (ye) => ye(","),
      "access",
      (ye) => ye.some,
      "call",
      (ye) => ye((O) => kh(O, R.type))
    ]) ? !0 : (H("error", `Invalid file type only ${o} allowed.`), !1));
    await fe(ie);
  }
  function we(k) {
    It.call(this, e, k);
  }
  function Re(k) {
    It.call(this, e, k);
  }
  function Ee(k) {
    It.call(this, e, k);
  }
  function P(k) {
    It.call(this, e, k);
  }
  function Y(k) {
    It.call(this, e, k);
  }
  function le(k) {
    It.call(this, e, k);
  }
  function pe(k) {
    It.call(this, e, k);
  }
  function Q(k) {
    ph[k ? "unshift" : "push"](() => {
      M = k, n(12, M);
    });
  }
  return e.$$set = (k) => {
    "filetype" in k && n(0, o = k.filetype), "dragging" in k && n(16, a = k.dragging), "boundedheight" in k && n(1, s = k.boundedheight), "center" in k && n(2, u = k.center), "flex" in k && n(3, f = k.flex), "file_count" in k && n(4, h = k.file_count), "disable_click" in k && n(17, p = k.disable_click), "root" in k && n(5, g = k.root), "hidden" in k && n(6, v = k.hidden), "include_sources" in k && n(7, B = k.include_sources), "$$scope" in k && n(19, r = k.$$scope);
  }, [
    o,
    s,
    u,
    f,
    h,
    g,
    v,
    B,
    E,
    D,
    N,
    K,
    M,
    A,
    be,
    ve,
    a,
    p,
    fe,
    r,
    i,
    we,
    Re,
    Ee,
    P,
    Y,
    le,
    pe,
    Q
  ];
}
class Uh extends _h {
  constructor(t) {
    super(), Mh(
      this,
      t,
      Dh,
      Hh,
      xh,
      {
        filetype: 0,
        dragging: 16,
        boundedheight: 1,
        center: 2,
        flex: 3,
        file_count: 4,
        disable_click: 17,
        root: 5,
        hidden: 6,
        include_sources: 7,
        open_file_upload: 8,
        load_files: 18
      },
      null,
      [-1, -1]
    );
  }
  get open_file_upload() {
    return this.$$.ctx[8];
  }
  get load_files() {
    return this.$$.ctx[18];
  }
}
const {
  SvelteComponent: Fh,
  attr: Gh,
  create_component: zh,
  destroy_component: qh,
  detach: jh,
  element: Xh,
  init: Vh,
  insert: Wh,
  mount_component: Yh,
  noop: Zh,
  safe_not_equal: Jh,
  transition_in: Qh,
  transition_out: Kh
} = window.__gradio__svelte__internal, { createEventDispatcher: $h } = window.__gradio__svelte__internal;
function e0(e) {
  let t, n, i;
  return n = new ai({
    props: { Icon: fl, label: "Remove Image" }
  }), n.$on(
    "click",
    /*click_handler*/
    e[1]
  ), {
    c() {
      t = Xh("div"), zh(n.$$.fragment), Gh(t, "class", "svelte-1g74h68");
    },
    m(r, o) {
      Wh(r, t, o), Yh(n, t, null), i = !0;
    },
    p: Zh,
    i(r) {
      i || (Qh(n.$$.fragment, r), i = !0);
    },
    o(r) {
      Kh(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && jh(t), qh(n);
    }
  };
}
function t0(e) {
  const t = $h();
  return [t, (i) => {
    t("remove_image"), i.stopPropagation();
  }];
}
class n0 extends Fh {
  constructor(t) {
    super(), Vh(this, t, t0, e0, Jh, {});
  }
}
const {
  SvelteComponent: i0,
  add_flush_callback: r0,
  append: qn,
  attr: zi,
  bind: o0,
  binding_callbacks: Na,
  bubble: a0,
  check_outros: Pn,
  create_component: tn,
  create_slot: s0,
  destroy_component: nn,
  destroy_each: l0,
  detach: ii,
  element: _o,
  empty: Oa,
  ensure_array_like: po,
  get_all_dirty_from_scope: u0,
  get_slot_changes: c0,
  group_outros: Mn,
  init: f0,
  insert: ri,
  mount_component: rn,
  noop: h0,
  safe_not_equal: d0,
  space: jn,
  transition_in: Me,
  transition_out: Be,
  update_slot_base: m0
} = window.__gradio__svelte__internal;
function go(e, t, n) {
  const i = e.slice();
  return i[20] = t[n], i;
}
function bo(e) {
  let t, n;
  return t = new n0({}), t.$on(
    "remove_image",
    /*remove_image_handler*/
    e[14]
  ), {
    c() {
      tn(t.$$.fragment);
    },
    m(i, r) {
      rn(t, i, r), n = !0;
    },
    p: h0,
    i(i) {
      n || (Me(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Be(t.$$.fragment, i), n = !1;
    },
    d(i) {
      nn(t, i);
    }
  };
}
function vo(e) {
  let t;
  const n = (
    /*#slots*/
    e[13].default
  ), i = s0(
    n,
    e,
    /*$$scope*/
    e[19],
    null
  );
  return {
    c() {
      i && i.c();
    },
    m(r, o) {
      i && i.m(r, o), t = !0;
    },
    p(r, o) {
      i && i.p && (!t || o & /*$$scope*/
      524288) && m0(
        i,
        n,
        r,
        /*$$scope*/
        r[19],
        t ? c0(
          n,
          /*$$scope*/
          r[19],
          o,
          null
        ) : u0(
          /*$$scope*/
          r[19]
        ),
        null
      );
    },
    i(r) {
      t || (Me(i, r), t = !0);
    },
    o(r) {
      Be(i, r), t = !1;
    },
    d(r) {
      i && i.d(r);
    }
  };
}
function _0(e) {
  let t, n, i = (
    /*value*/
    e[0] === null && vo(e)
  );
  return {
    c() {
      i && i.c(), t = Oa();
    },
    m(r, o) {
      i && i.m(r, o), ri(r, t, o), n = !0;
    },
    p(r, o) {
      /*value*/
      r[0] === null ? i ? (i.p(r, o), o & /*value*/
      1 && Me(i, 1)) : (i = vo(r), i.c(), Me(i, 1), i.m(t.parentNode, t)) : i && (Mn(), Be(i, 1, 1, () => {
        i = null;
      }), Pn());
    },
    i(r) {
      n || (Me(i), n = !0);
    },
    o(r) {
      Be(i), n = !1;
    },
    d(r) {
      r && ii(t), i && i.d(r);
    }
  };
}
function wo(e) {
  let t, n;
  return t = new na({
    props: {
      div_id: "pannellum-uploader-" + /*value*/
      e[0].orig_name,
      panorama: (
        /*value*/
        e[0].url
      ),
      height: (
        /*height*/
        e[2]
      )
    }
  }), {
    c() {
      tn(t.$$.fragment);
    },
    m(i, r) {
      rn(t, i, r), n = !0;
    },
    p(i, r) {
      const o = {};
      r & /*value*/
      1 && (o.div_id = "pannellum-uploader-" + /*value*/
      i[0].orig_name), r & /*value*/
      1 && (o.panorama = /*value*/
      i[0].url), r & /*height*/
      4 && (o.height = /*height*/
      i[2]), t.$set(o);
    },
    i(i) {
      n || (Me(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Be(t.$$.fragment, i), n = !1;
    },
    d(i) {
      nn(t, i);
    }
  };
}
function yo(e) {
  var i;
  let t, n;
  return t = new Lu({
    props: {
      show_border: !/*value*/
      ((i = e[0]) != null && i.url),
      $$slots: { default: [p0] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      tn(t.$$.fragment);
    },
    m(r, o) {
      rn(t, r, o), n = !0;
    },
    p(r, o) {
      var s;
      const a = {};
      o & /*value*/
      1 && (a.show_border = !/*value*/
      ((s = r[0]) != null && s.url)), o & /*$$scope, sources_list*/
      524544 && (a.$$scope = { dirty: o, ctx: r }), t.$set(a);
    },
    i(r) {
      n || (Me(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Be(t.$$.fragment, r), n = !1;
    },
    d(r) {
      nn(t, r);
    }
  };
}
function Eo(e) {
  let t, n;
  function i() {
    return (
      /*click_handler*/
      e[18](
        /*source*/
        e[20]
      )
    );
  }
  return t = new ai({
    props: {
      Icon: (
        /*sources_meta*/
        e[10][
          /*source*/
          e[20]
        ].icon
      ),
      size: "large",
      padded: !1
    }
  }), t.$on("click", i), {
    c() {
      tn(t.$$.fragment);
    },
    m(r, o) {
      rn(t, r, o), n = !0;
    },
    p(r, o) {
      e = r;
      const a = {};
      o & /*sources_list*/
      256 && (a.Icon = /*sources_meta*/
      e[10][
        /*source*/
        e[20]
      ].icon), t.$set(a);
    },
    i(r) {
      n || (Me(t.$$.fragment, r), n = !0);
    },
    o(r) {
      Be(t.$$.fragment, r), n = !1;
    },
    d(r) {
      nn(t, r);
    }
  };
}
function p0(e) {
  let t, n, i = po(
    /*sources_list*/
    e[8]
  ), r = [];
  for (let a = 0; a < i.length; a += 1)
    r[a] = Eo(go(e, i, a));
  const o = (a) => Be(r[a], 1, 1, () => {
    r[a] = null;
  });
  return {
    c() {
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      t = Oa();
    },
    m(a, s) {
      for (let u = 0; u < r.length; u += 1)
        r[u] && r[u].m(a, s);
      ri(a, t, s), n = !0;
    },
    p(a, s) {
      if (s & /*sources_meta, sources_list, handle_toolbar*/
      3328) {
        i = po(
          /*sources_list*/
          a[8]
        );
        let u;
        for (u = 0; u < i.length; u += 1) {
          const f = go(a, i, u);
          r[u] ? (r[u].p(f, s), Me(r[u], 1)) : (r[u] = Eo(f), r[u].c(), Me(r[u], 1), r[u].m(t.parentNode, t));
        }
        for (Mn(), u = i.length; u < r.length; u += 1)
          o(u);
        Pn();
      }
    },
    i(a) {
      if (!n) {
        for (let s = 0; s < i.length; s += 1)
          Me(r[s]);
        n = !0;
      }
    },
    o(a) {
      r = r.filter(Boolean);
      for (let s = 0; s < r.length; s += 1)
        Be(r[s]);
      n = !1;
    },
    d(a) {
      a && ii(t), l0(r, a);
    }
  };
}
function g0(e) {
  var K;
  let t, n, i, r, o, a, s, u, f, h = (
    /*sources*/
    e[4].length > 1 || /*sources*/
    e[4].includes("clipboard")
  ), p;
  t = new Zo({
    props: {
      show_label: (
        /*show_label*/
        e[3]
      ),
      Icon: si,
      label: (
        /*label*/
        e[1] || "Image"
      )
    }
  });
  let g = (
    /*value*/
    ((K = e[0]) == null ? void 0 : K.url) && bo(e)
  );
  function v(x) {
    e[16](x);
  }
  let B = {
    hidden: (
      /*value*/
      e[0] !== null
    ),
    filetype: "image/*",
    root: (
      /*root*/
      e[5]
    ),
    disable_click: !/*sources*/
    e[4].includes("upload"),
    $$slots: { default: [_0] },
    $$scope: { ctx: e }
  };
  /*dragging*/
  e[7] !== void 0 && (B.dragging = /*dragging*/
  e[7]), a = new Uh({ props: B }), e[15](a), Na.push(() => o0(a, "dragging", v)), a.$on(
    "load",
    /*handle_upload*/
    e[9]
  ), a.$on(
    "error",
    /*error_handler*/
    e[17]
  );
  let D = (
    /*value*/
    e[0] !== null && wo(e)
  ), N = h && yo(e);
  return {
    c() {
      tn(t.$$.fragment), n = jn(), i = _o("div"), g && g.c(), r = jn(), o = _o("div"), tn(a.$$.fragment), u = jn(), D && D.c(), f = jn(), N && N.c(), zi(o, "class", "upload-container svelte-1h6b24t"), zi(i, "data-testid", "image"), zi(i, "class", "image-container svelte-1h6b24t");
    },
    m(x, M) {
      rn(t, x, M), ri(x, n, M), ri(x, i, M), g && g.m(i, null), qn(i, r), qn(i, o), rn(a, o, null), qn(o, u), D && D.m(o, null), qn(i, f), N && N.m(i, null), p = !0;
    },
    p(x, [M]) {
      var E;
      const H = {};
      M & /*show_label*/
      8 && (H.show_label = /*show_label*/
      x[3]), M & /*label*/
      2 && (H.label = /*label*/
      x[1] || "Image"), t.$set(H), /*value*/
      (E = x[0]) != null && E.url ? g ? (g.p(x, M), M & /*value*/
      1 && Me(g, 1)) : (g = bo(x), g.c(), Me(g, 1), g.m(i, r)) : g && (Mn(), Be(g, 1, 1, () => {
        g = null;
      }), Pn());
      const A = {};
      M & /*value*/
      1 && (A.hidden = /*value*/
      x[0] !== null), M & /*root*/
      32 && (A.root = /*root*/
      x[5]), M & /*sources*/
      16 && (A.disable_click = !/*sources*/
      x[4].includes("upload")), M & /*$$scope, value*/
      524289 && (A.$$scope = { dirty: M, ctx: x }), !s && M & /*dragging*/
      128 && (s = !0, A.dragging = /*dragging*/
      x[7], r0(() => s = !1)), a.$set(A), /*value*/
      x[0] !== null ? D ? (D.p(x, M), M & /*value*/
      1 && Me(D, 1)) : (D = wo(x), D.c(), Me(D, 1), D.m(o, null)) : D && (Mn(), Be(D, 1, 1, () => {
        D = null;
      }), Pn()), M & /*sources*/
      16 && (h = /*sources*/
      x[4].length > 1 || /*sources*/
      x[4].includes("clipboard")), h ? N ? (N.p(x, M), M & /*sources*/
      16 && Me(N, 1)) : (N = yo(x), N.c(), Me(N, 1), N.m(i, null)) : N && (Mn(), Be(N, 1, 1, () => {
        N = null;
      }), Pn());
    },
    i(x) {
      p || (Me(t.$$.fragment, x), Me(g), Me(a.$$.fragment, x), Me(D), Me(N), p = !0);
    },
    o(x) {
      Be(t.$$.fragment, x), Be(g), Be(a.$$.fragment, x), Be(D), Be(N), p = !1;
    },
    d(x) {
      x && (ii(n), ii(i)), nn(t, x), g && g.d(), e[15](null), nn(a), D && D.d(), N && N.d();
    }
  };
}
function b0(e) {
  let t, n = e[0], i = 1;
  for (; i < e.length; ) {
    const r = e[i], o = e[i + 1];
    if (i += 2, (r === "optionalAccess" || r === "optionalCall") && n == null)
      return;
    r === "access" || r === "optionalAccess" ? (t = n, n = o(n)) : (r === "call" || r === "optionalCall") && (n = o((...a) => n.call(t, ...a)), t = void 0);
  }
  return n;
}
function v0(e, t, n) {
  let i, { $$slots: r = {}, $$scope: o } = t, { value: a } = t, { label: s = void 0 } = t, { height: u = 400 } = t, { show_label: f } = t, { sources: h = ["upload", "clipboard"] } = t, { root: p } = t, { i18n: g } = t, v;
  function B({ detail: m }) {
    n(0, a = dt(m, p, null));
  }
  let D = !1;
  const N = {
    upload: {
      icon: $o,
      label: g("Upload"),
      order: 0
    },
    clipboard: {
      icon: Gl,
      label: g("Paste"),
      order: 1
    }
  };
  async function K(m) {
    switch (m) {
      case "clipboard":
        navigator.clipboard.read().then(async (fe) => {
          for (let be = 0; be < fe.length; be++) {
            const ve = fe[be].types.find((we) => we.startsWith("image/"));
            if (ve) {
              fe[be].getType(ve).then(async (we) => {
                const Re = await v.load_files([new File([we], `clipboard.${ve.replace("image/", "")}`)]);
                n(0, a = b0([Re, "optionalAccess", (Ee) => Ee[0]]) || null);
              });
              break;
            }
          }
        });
        break;
      case "upload":
        v.open_file_upload();
        break;
    }
  }
  const x = () => n(0, a = null);
  function M(m) {
    Na[m ? "unshift" : "push"](() => {
      v = m, n(6, v);
    });
  }
  function H(m) {
    D = m, n(7, D);
  }
  function A(m) {
    a0.call(this, e, m);
  }
  const E = (m) => K(m);
  return e.$$set = (m) => {
    "value" in m && n(0, a = m.value), "label" in m && n(1, s = m.label), "height" in m && n(2, u = m.height), "show_label" in m && n(3, f = m.show_label), "sources" in m && n(4, h = m.sources), "root" in m && n(5, p = m.root), "i18n" in m && n(12, g = m.i18n), "$$scope" in m && n(19, o = m.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty & /*value, root*/
    33 && a && !a.url && n(0, a = dt(a, p, null)), e.$$.dirty & /*sources*/
    16 && n(8, i = h.sort((m, fe) => N[m].order - N[fe].order));
  }, [
    a,
    s,
    u,
    f,
    h,
    p,
    v,
    D,
    i,
    B,
    N,
    K,
    g,
    r,
    x,
    M,
    H,
    A,
    E,
    o
  ];
}
class w0 extends i0 {
  constructor(t) {
    super(), f0(this, t, v0, g0, d0, {
      value: 0,
      label: 1,
      height: 2,
      show_label: 3,
      sources: 4,
      root: 5,
      i18n: 12
    });
  }
}
function Wt(e) {
  let t = ["", "k", "M", "G", "T", "P", "E", "Z"], n = 0;
  for (; e > 1e3 && n < t.length - 1; )
    e /= 1e3, n++;
  let i = t[n];
  return (Number.isInteger(e) ? e : e.toFixed(1)) + i;
}
const {
  SvelteComponent: y0,
  append: it,
  attr: _e,
  component_subscribe: To,
  detach: E0,
  element: T0,
  init: P0,
  insert: M0,
  noop: Po,
  safe_not_equal: S0,
  set_style: Xn,
  svg_element: rt,
  toggle_class: Mo
} = window.__gradio__svelte__internal, { onMount: C0 } = window.__gradio__svelte__internal;
function x0(e) {
  let t, n, i, r, o, a, s, u, f, h, p, g;
  return {
    c() {
      t = T0("div"), n = rt("svg"), i = rt("g"), r = rt("path"), o = rt("path"), a = rt("path"), s = rt("path"), u = rt("g"), f = rt("path"), h = rt("path"), p = rt("path"), g = rt("path"), _e(r, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), _e(r, "fill", "#FF7C00"), _e(r, "fill-opacity", "0.4"), _e(r, "class", "svelte-43sxxs"), _e(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), _e(o, "fill", "#FF7C00"), _e(o, "class", "svelte-43sxxs"), _e(a, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), _e(a, "fill", "#FF7C00"), _e(a, "fill-opacity", "0.4"), _e(a, "class", "svelte-43sxxs"), _e(s, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), _e(s, "fill", "#FF7C00"), _e(s, "class", "svelte-43sxxs"), Xn(i, "transform", "translate(" + /*$top*/
      e[1][0] + "px, " + /*$top*/
      e[1][1] + "px)"), _e(f, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), _e(f, "fill", "#FF7C00"), _e(f, "fill-opacity", "0.4"), _e(f, "class", "svelte-43sxxs"), _e(h, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), _e(h, "fill", "#FF7C00"), _e(h, "class", "svelte-43sxxs"), _e(p, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), _e(p, "fill", "#FF7C00"), _e(p, "fill-opacity", "0.4"), _e(p, "class", "svelte-43sxxs"), _e(g, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), _e(g, "fill", "#FF7C00"), _e(g, "class", "svelte-43sxxs"), Xn(u, "transform", "translate(" + /*$bottom*/
      e[2][0] + "px, " + /*$bottom*/
      e[2][1] + "px)"), _e(n, "viewBox", "-1200 -1200 3000 3000"), _e(n, "fill", "none"), _e(n, "xmlns", "http://www.w3.org/2000/svg"), _e(n, "class", "svelte-43sxxs"), _e(t, "class", "svelte-43sxxs"), Mo(
        t,
        "margin",
        /*margin*/
        e[0]
      );
    },
    m(v, B) {
      M0(v, t, B), it(t, n), it(n, i), it(i, r), it(i, o), it(i, a), it(i, s), it(n, u), it(u, f), it(u, h), it(u, p), it(u, g);
    },
    p(v, [B]) {
      B & /*$top*/
      2 && Xn(i, "transform", "translate(" + /*$top*/
      v[1][0] + "px, " + /*$top*/
      v[1][1] + "px)"), B & /*$bottom*/
      4 && Xn(u, "transform", "translate(" + /*$bottom*/
      v[2][0] + "px, " + /*$bottom*/
      v[2][1] + "px)"), B & /*margin*/
      1 && Mo(
        t,
        "margin",
        /*margin*/
        v[0]
      );
    },
    i: Po,
    o: Po,
    d(v) {
      v && E0(t);
    }
  };
}
function I0(e, t, n) {
  let i, r, { margin: o = !0 } = t;
  const a = Yr([0, 0]);
  To(e, a, (g) => n(1, i = g));
  const s = Yr([0, 0]);
  To(e, s, (g) => n(2, r = g));
  let u;
  async function f() {
    await Promise.all([a.set([125, 140]), s.set([-125, -140])]), await Promise.all([a.set([-125, 140]), s.set([125, -140])]), await Promise.all([a.set([-125, 0]), s.set([125, -0])]), await Promise.all([a.set([125, 0]), s.set([-125, 0])]);
  }
  async function h() {
    await f(), u || h();
  }
  async function p() {
    await Promise.all([a.set([125, 0]), s.set([-125, 0])]), h();
  }
  return C0(() => (p(), () => u = !0)), e.$$set = (g) => {
    "margin" in g && n(0, o = g.margin);
  }, [o, i, r, a, s];
}
class A0 extends y0 {
  constructor(t) {
    super(), P0(this, t, I0, x0, S0, { margin: 0 });
  }
}
const {
  SvelteComponent: R0,
  append: Ht,
  attr: ut,
  binding_callbacks: So,
  check_outros: Ha,
  create_component: L0,
  create_slot: B0,
  destroy_component: N0,
  destroy_each: ka,
  detach: ae,
  element: mt,
  empty: hn,
  ensure_array_like: oi,
  get_all_dirty_from_scope: O0,
  get_slot_changes: H0,
  group_outros: Da,
  init: k0,
  insert: se,
  mount_component: D0,
  noop: hr,
  safe_not_equal: U0,
  set_data: Qe,
  set_style: Ct,
  space: ct,
  text: Pe,
  toggle_class: Ze,
  transition_in: on,
  transition_out: an,
  update_slot_base: F0
} = window.__gradio__svelte__internal, { tick: G0 } = window.__gradio__svelte__internal, { onDestroy: z0 } = window.__gradio__svelte__internal, q0 = (e) => ({}), Co = (e) => ({});
function xo(e, t, n) {
  const i = e.slice();
  return i[38] = t[n], i[40] = n, i;
}
function Io(e, t, n) {
  const i = e.slice();
  return i[38] = t[n], i;
}
function j0(e) {
  let t, n = (
    /*i18n*/
    e[1]("common.error") + ""
  ), i, r, o;
  const a = (
    /*#slots*/
    e[29].error
  ), s = B0(
    a,
    e,
    /*$$scope*/
    e[28],
    Co
  );
  return {
    c() {
      t = mt("span"), i = Pe(n), r = ct(), s && s.c(), ut(t, "class", "error svelte-14miwb5");
    },
    m(u, f) {
      se(u, t, f), Ht(t, i), se(u, r, f), s && s.m(u, f), o = !0;
    },
    p(u, f) {
      (!o || f[0] & /*i18n*/
      2) && n !== (n = /*i18n*/
      u[1]("common.error") + "") && Qe(i, n), s && s.p && (!o || f[0] & /*$$scope*/
      268435456) && F0(
        s,
        a,
        u,
        /*$$scope*/
        u[28],
        o ? H0(
          a,
          /*$$scope*/
          u[28],
          f,
          q0
        ) : O0(
          /*$$scope*/
          u[28]
        ),
        Co
      );
    },
    i(u) {
      o || (on(s, u), o = !0);
    },
    o(u) {
      an(s, u), o = !1;
    },
    d(u) {
      u && (ae(t), ae(r)), s && s.d(u);
    }
  };
}
function X0(e) {
  let t, n, i, r, o, a, s, u, f, h = (
    /*variant*/
    e[8] === "default" && /*show_eta_bar*/
    e[18] && /*show_progress*/
    e[6] === "full" && Ao(e)
  );
  function p(M, H) {
    if (
      /*progress*/
      M[7]
    )
      return Y0;
    if (
      /*queue_position*/
      M[2] !== null && /*queue_size*/
      M[3] !== void 0 && /*queue_position*/
      M[2] >= 0
    )
      return W0;
    if (
      /*queue_position*/
      M[2] === 0
    )
      return V0;
  }
  let g = p(e), v = g && g(e), B = (
    /*timer*/
    e[5] && Bo(e)
  );
  const D = [K0, Q0], N = [];
  function K(M, H) {
    return (
      /*last_progress_level*/
      M[15] != null ? 0 : (
        /*show_progress*/
        M[6] === "full" ? 1 : -1
      )
    );
  }
  ~(o = K(e)) && (a = N[o] = D[o](e));
  let x = !/*timer*/
  e[5] && Fo(e);
  return {
    c() {
      h && h.c(), t = ct(), n = mt("div"), v && v.c(), i = ct(), B && B.c(), r = ct(), a && a.c(), s = ct(), x && x.c(), u = hn(), ut(n, "class", "progress-text svelte-14miwb5"), Ze(
        n,
        "meta-text-center",
        /*variant*/
        e[8] === "center"
      ), Ze(
        n,
        "meta-text",
        /*variant*/
        e[8] === "default"
      );
    },
    m(M, H) {
      h && h.m(M, H), se(M, t, H), se(M, n, H), v && v.m(n, null), Ht(n, i), B && B.m(n, null), se(M, r, H), ~o && N[o].m(M, H), se(M, s, H), x && x.m(M, H), se(M, u, H), f = !0;
    },
    p(M, H) {
      /*variant*/
      M[8] === "default" && /*show_eta_bar*/
      M[18] && /*show_progress*/
      M[6] === "full" ? h ? h.p(M, H) : (h = Ao(M), h.c(), h.m(t.parentNode, t)) : h && (h.d(1), h = null), g === (g = p(M)) && v ? v.p(M, H) : (v && v.d(1), v = g && g(M), v && (v.c(), v.m(n, i))), /*timer*/
      M[5] ? B ? B.p(M, H) : (B = Bo(M), B.c(), B.m(n, null)) : B && (B.d(1), B = null), (!f || H[0] & /*variant*/
      256) && Ze(
        n,
        "meta-text-center",
        /*variant*/
        M[8] === "center"
      ), (!f || H[0] & /*variant*/
      256) && Ze(
        n,
        "meta-text",
        /*variant*/
        M[8] === "default"
      );
      let A = o;
      o = K(M), o === A ? ~o && N[o].p(M, H) : (a && (Da(), an(N[A], 1, 1, () => {
        N[A] = null;
      }), Ha()), ~o ? (a = N[o], a ? a.p(M, H) : (a = N[o] = D[o](M), a.c()), on(a, 1), a.m(s.parentNode, s)) : a = null), /*timer*/
      M[5] ? x && (x.d(1), x = null) : x ? x.p(M, H) : (x = Fo(M), x.c(), x.m(u.parentNode, u));
    },
    i(M) {
      f || (on(a), f = !0);
    },
    o(M) {
      an(a), f = !1;
    },
    d(M) {
      M && (ae(t), ae(n), ae(r), ae(s), ae(u)), h && h.d(M), v && v.d(), B && B.d(), ~o && N[o].d(M), x && x.d(M);
    }
  };
}
function Ao(e) {
  let t, n = `translateX(${/*eta_level*/
  (e[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      t = mt("div"), ut(t, "class", "eta-bar svelte-14miwb5"), Ct(t, "transform", n);
    },
    m(i, r) {
      se(i, t, r);
    },
    p(i, r) {
      r[0] & /*eta_level*/
      131072 && n !== (n = `translateX(${/*eta_level*/
      (i[17] || 0) * 100 - 100}%)`) && Ct(t, "transform", n);
    },
    d(i) {
      i && ae(t);
    }
  };
}
function V0(e) {
  let t;
  return {
    c() {
      t = Pe("processing |");
    },
    m(n, i) {
      se(n, t, i);
    },
    p: hr,
    d(n) {
      n && ae(t);
    }
  };
}
function W0(e) {
  let t, n = (
    /*queue_position*/
    e[2] + 1 + ""
  ), i, r, o, a;
  return {
    c() {
      t = Pe("queue: "), i = Pe(n), r = Pe("/"), o = Pe(
        /*queue_size*/
        e[3]
      ), a = Pe(" |");
    },
    m(s, u) {
      se(s, t, u), se(s, i, u), se(s, r, u), se(s, o, u), se(s, a, u);
    },
    p(s, u) {
      u[0] & /*queue_position*/
      4 && n !== (n = /*queue_position*/
      s[2] + 1 + "") && Qe(i, n), u[0] & /*queue_size*/
      8 && Qe(
        o,
        /*queue_size*/
        s[3]
      );
    },
    d(s) {
      s && (ae(t), ae(i), ae(r), ae(o), ae(a));
    }
  };
}
function Y0(e) {
  let t, n = oi(
    /*progress*/
    e[7]
  ), i = [];
  for (let r = 0; r < n.length; r += 1)
    i[r] = Lo(Io(e, n, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      t = hn();
    },
    m(r, o) {
      for (let a = 0; a < i.length; a += 1)
        i[a] && i[a].m(r, o);
      se(r, t, o);
    },
    p(r, o) {
      if (o[0] & /*progress*/
      128) {
        n = oi(
          /*progress*/
          r[7]
        );
        let a;
        for (a = 0; a < n.length; a += 1) {
          const s = Io(r, n, a);
          i[a] ? i[a].p(s, o) : (i[a] = Lo(s), i[a].c(), i[a].m(t.parentNode, t));
        }
        for (; a < i.length; a += 1)
          i[a].d(1);
        i.length = n.length;
      }
    },
    d(r) {
      r && ae(t), ka(i, r);
    }
  };
}
function Ro(e) {
  let t, n = (
    /*p*/
    e[38].unit + ""
  ), i, r, o = " ", a;
  function s(h, p) {
    return (
      /*p*/
      h[38].length != null ? J0 : Z0
    );
  }
  let u = s(e), f = u(e);
  return {
    c() {
      f.c(), t = ct(), i = Pe(n), r = Pe(" | "), a = Pe(o);
    },
    m(h, p) {
      f.m(h, p), se(h, t, p), se(h, i, p), se(h, r, p), se(h, a, p);
    },
    p(h, p) {
      u === (u = s(h)) && f ? f.p(h, p) : (f.d(1), f = u(h), f && (f.c(), f.m(t.parentNode, t))), p[0] & /*progress*/
      128 && n !== (n = /*p*/
      h[38].unit + "") && Qe(i, n);
    },
    d(h) {
      h && (ae(t), ae(i), ae(r), ae(a)), f.d(h);
    }
  };
}
function Z0(e) {
  let t = Wt(
    /*p*/
    e[38].index || 0
  ) + "", n;
  return {
    c() {
      n = Pe(t);
    },
    m(i, r) {
      se(i, n, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      128 && t !== (t = Wt(
        /*p*/
        i[38].index || 0
      ) + "") && Qe(n, t);
    },
    d(i) {
      i && ae(n);
    }
  };
}
function J0(e) {
  let t = Wt(
    /*p*/
    e[38].index || 0
  ) + "", n, i, r = Wt(
    /*p*/
    e[38].length
  ) + "", o;
  return {
    c() {
      n = Pe(t), i = Pe("/"), o = Pe(r);
    },
    m(a, s) {
      se(a, n, s), se(a, i, s), se(a, o, s);
    },
    p(a, s) {
      s[0] & /*progress*/
      128 && t !== (t = Wt(
        /*p*/
        a[38].index || 0
      ) + "") && Qe(n, t), s[0] & /*progress*/
      128 && r !== (r = Wt(
        /*p*/
        a[38].length
      ) + "") && Qe(o, r);
    },
    d(a) {
      a && (ae(n), ae(i), ae(o));
    }
  };
}
function Lo(e) {
  let t, n = (
    /*p*/
    e[38].index != null && Ro(e)
  );
  return {
    c() {
      n && n.c(), t = hn();
    },
    m(i, r) {
      n && n.m(i, r), se(i, t, r);
    },
    p(i, r) {
      /*p*/
      i[38].index != null ? n ? n.p(i, r) : (n = Ro(i), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && ae(t), n && n.d(i);
    }
  };
}
function Bo(e) {
  let t, n = (
    /*eta*/
    e[0] ? `/${/*formatted_eta*/
    e[19]}` : ""
  ), i, r;
  return {
    c() {
      t = Pe(
        /*formatted_timer*/
        e[20]
      ), i = Pe(n), r = Pe("s");
    },
    m(o, a) {
      se(o, t, a), se(o, i, a), se(o, r, a);
    },
    p(o, a) {
      a[0] & /*formatted_timer*/
      1048576 && Qe(
        t,
        /*formatted_timer*/
        o[20]
      ), a[0] & /*eta, formatted_eta*/
      524289 && n !== (n = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[19]}` : "") && Qe(i, n);
    },
    d(o) {
      o && (ae(t), ae(i), ae(r));
    }
  };
}
function Q0(e) {
  let t, n;
  return t = new A0({
    props: { margin: (
      /*variant*/
      e[8] === "default"
    ) }
  }), {
    c() {
      L0(t.$$.fragment);
    },
    m(i, r) {
      D0(t, i, r), n = !0;
    },
    p(i, r) {
      const o = {};
      r[0] & /*variant*/
      256 && (o.margin = /*variant*/
      i[8] === "default"), t.$set(o);
    },
    i(i) {
      n || (on(t.$$.fragment, i), n = !0);
    },
    o(i) {
      an(t.$$.fragment, i), n = !1;
    },
    d(i) {
      N0(t, i);
    }
  };
}
function K0(e) {
  let t, n, i, r, o, a = `${/*last_progress_level*/
  e[15] * 100}%`, s = (
    /*progress*/
    e[7] != null && No(e)
  );
  return {
    c() {
      t = mt("div"), n = mt("div"), s && s.c(), i = ct(), r = mt("div"), o = mt("div"), ut(n, "class", "progress-level-inner svelte-14miwb5"), ut(o, "class", "progress-bar svelte-14miwb5"), Ct(o, "width", a), ut(r, "class", "progress-bar-wrap svelte-14miwb5"), ut(t, "class", "progress-level svelte-14miwb5");
    },
    m(u, f) {
      se(u, t, f), Ht(t, n), s && s.m(n, null), Ht(t, i), Ht(t, r), Ht(r, o), e[30](o);
    },
    p(u, f) {
      /*progress*/
      u[7] != null ? s ? s.p(u, f) : (s = No(u), s.c(), s.m(n, null)) : s && (s.d(1), s = null), f[0] & /*last_progress_level*/
      32768 && a !== (a = `${/*last_progress_level*/
      u[15] * 100}%`) && Ct(o, "width", a);
    },
    i: hr,
    o: hr,
    d(u) {
      u && ae(t), s && s.d(), e[30](null);
    }
  };
}
function No(e) {
  let t, n = oi(
    /*progress*/
    e[7]
  ), i = [];
  for (let r = 0; r < n.length; r += 1)
    i[r] = Uo(xo(e, n, r));
  return {
    c() {
      for (let r = 0; r < i.length; r += 1)
        i[r].c();
      t = hn();
    },
    m(r, o) {
      for (let a = 0; a < i.length; a += 1)
        i[a] && i[a].m(r, o);
      se(r, t, o);
    },
    p(r, o) {
      if (o[0] & /*progress_level, progress*/
      16512) {
        n = oi(
          /*progress*/
          r[7]
        );
        let a;
        for (a = 0; a < n.length; a += 1) {
          const s = xo(r, n, a);
          i[a] ? i[a].p(s, o) : (i[a] = Uo(s), i[a].c(), i[a].m(t.parentNode, t));
        }
        for (; a < i.length; a += 1)
          i[a].d(1);
        i.length = n.length;
      }
    },
    d(r) {
      r && ae(t), ka(i, r);
    }
  };
}
function Oo(e) {
  let t, n, i, r, o = (
    /*i*/
    e[40] !== 0 && $0()
  ), a = (
    /*p*/
    e[38].desc != null && Ho(e)
  ), s = (
    /*p*/
    e[38].desc != null && /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[40]
    ] != null && ko()
  ), u = (
    /*progress_level*/
    e[14] != null && Do(e)
  );
  return {
    c() {
      o && o.c(), t = ct(), a && a.c(), n = ct(), s && s.c(), i = ct(), u && u.c(), r = hn();
    },
    m(f, h) {
      o && o.m(f, h), se(f, t, h), a && a.m(f, h), se(f, n, h), s && s.m(f, h), se(f, i, h), u && u.m(f, h), se(f, r, h);
    },
    p(f, h) {
      /*p*/
      f[38].desc != null ? a ? a.p(f, h) : (a = Ho(f), a.c(), a.m(n.parentNode, n)) : a && (a.d(1), a = null), /*p*/
      f[38].desc != null && /*progress_level*/
      f[14] && /*progress_level*/
      f[14][
        /*i*/
        f[40]
      ] != null ? s || (s = ko(), s.c(), s.m(i.parentNode, i)) : s && (s.d(1), s = null), /*progress_level*/
      f[14] != null ? u ? u.p(f, h) : (u = Do(f), u.c(), u.m(r.parentNode, r)) : u && (u.d(1), u = null);
    },
    d(f) {
      f && (ae(t), ae(n), ae(i), ae(r)), o && o.d(f), a && a.d(f), s && s.d(f), u && u.d(f);
    }
  };
}
function $0(e) {
  let t;
  return {
    c() {
      t = Pe(" /");
    },
    m(n, i) {
      se(n, t, i);
    },
    d(n) {
      n && ae(t);
    }
  };
}
function Ho(e) {
  let t = (
    /*p*/
    e[38].desc + ""
  ), n;
  return {
    c() {
      n = Pe(t);
    },
    m(i, r) {
      se(i, n, r);
    },
    p(i, r) {
      r[0] & /*progress*/
      128 && t !== (t = /*p*/
      i[38].desc + "") && Qe(n, t);
    },
    d(i) {
      i && ae(n);
    }
  };
}
function ko(e) {
  let t;
  return {
    c() {
      t = Pe("-");
    },
    m(n, i) {
      se(n, t, i);
    },
    d(n) {
      n && ae(t);
    }
  };
}
function Do(e) {
  let t = (100 * /*progress_level*/
  (e[14][
    /*i*/
    e[40]
  ] || 0)).toFixed(1) + "", n, i;
  return {
    c() {
      n = Pe(t), i = Pe("%");
    },
    m(r, o) {
      se(r, n, o), se(r, i, o);
    },
    p(r, o) {
      o[0] & /*progress_level*/
      16384 && t !== (t = (100 * /*progress_level*/
      (r[14][
        /*i*/
        r[40]
      ] || 0)).toFixed(1) + "") && Qe(n, t);
    },
    d(r) {
      r && (ae(n), ae(i));
    }
  };
}
function Uo(e) {
  let t, n = (
    /*p*/
    (e[38].desc != null || /*progress_level*/
    e[14] && /*progress_level*/
    e[14][
      /*i*/
      e[40]
    ] != null) && Oo(e)
  );
  return {
    c() {
      n && n.c(), t = hn();
    },
    m(i, r) {
      n && n.m(i, r), se(i, t, r);
    },
    p(i, r) {
      /*p*/
      i[38].desc != null || /*progress_level*/
      i[14] && /*progress_level*/
      i[14][
        /*i*/
        i[40]
      ] != null ? n ? n.p(i, r) : (n = Oo(i), n.c(), n.m(t.parentNode, t)) : n && (n.d(1), n = null);
    },
    d(i) {
      i && ae(t), n && n.d(i);
    }
  };
}
function Fo(e) {
  let t, n;
  return {
    c() {
      t = mt("p"), n = Pe(
        /*loading_text*/
        e[9]
      ), ut(t, "class", "loading svelte-14miwb5");
    },
    m(i, r) {
      se(i, t, r), Ht(t, n);
    },
    p(i, r) {
      r[0] & /*loading_text*/
      512 && Qe(
        n,
        /*loading_text*/
        i[9]
      );
    },
    d(i) {
      i && ae(t);
    }
  };
}
function ed(e) {
  let t, n, i, r, o;
  const a = [X0, j0], s = [];
  function u(f, h) {
    return (
      /*status*/
      f[4] === "pending" ? 0 : (
        /*status*/
        f[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(n = u(e)) && (i = s[n] = a[n](e)), {
    c() {
      t = mt("div"), i && i.c(), ut(t, "class", r = "wrap " + /*variant*/
      e[8] + " " + /*show_progress*/
      e[6] + " svelte-14miwb5"), Ze(t, "hide", !/*status*/
      e[4] || /*status*/
      e[4] === "complete" || /*show_progress*/
      e[6] === "hidden"), Ze(
        t,
        "translucent",
        /*variant*/
        e[8] === "center" && /*status*/
        (e[4] === "pending" || /*status*/
        e[4] === "error") || /*translucent*/
        e[11] || /*show_progress*/
        e[6] === "minimal"
      ), Ze(
        t,
        "generating",
        /*status*/
        e[4] === "generating"
      ), Ze(
        t,
        "border",
        /*border*/
        e[12]
      ), Ct(
        t,
        "position",
        /*absolute*/
        e[10] ? "absolute" : "static"
      ), Ct(
        t,
        "padding",
        /*absolute*/
        e[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(f, h) {
      se(f, t, h), ~n && s[n].m(t, null), e[31](t), o = !0;
    },
    p(f, h) {
      let p = n;
      n = u(f), n === p ? ~n && s[n].p(f, h) : (i && (Da(), an(s[p], 1, 1, () => {
        s[p] = null;
      }), Ha()), ~n ? (i = s[n], i ? i.p(f, h) : (i = s[n] = a[n](f), i.c()), on(i, 1), i.m(t, null)) : i = null), (!o || h[0] & /*variant, show_progress*/
      320 && r !== (r = "wrap " + /*variant*/
      f[8] + " " + /*show_progress*/
      f[6] + " svelte-14miwb5")) && ut(t, "class", r), (!o || h[0] & /*variant, show_progress, status, show_progress*/
      336) && Ze(t, "hide", !/*status*/
      f[4] || /*status*/
      f[4] === "complete" || /*show_progress*/
      f[6] === "hidden"), (!o || h[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && Ze(
        t,
        "translucent",
        /*variant*/
        f[8] === "center" && /*status*/
        (f[4] === "pending" || /*status*/
        f[4] === "error") || /*translucent*/
        f[11] || /*show_progress*/
        f[6] === "minimal"
      ), (!o || h[0] & /*variant, show_progress, status*/
      336) && Ze(
        t,
        "generating",
        /*status*/
        f[4] === "generating"
      ), (!o || h[0] & /*variant, show_progress, border*/
      4416) && Ze(
        t,
        "border",
        /*border*/
        f[12]
      ), h[0] & /*absolute*/
      1024 && Ct(
        t,
        "position",
        /*absolute*/
        f[10] ? "absolute" : "static"
      ), h[0] & /*absolute*/
      1024 && Ct(
        t,
        "padding",
        /*absolute*/
        f[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(f) {
      o || (on(i), o = !0);
    },
    o(f) {
      an(i), o = !1;
    },
    d(f) {
      f && ae(t), ~n && s[n].d(), e[31](null);
    }
  };
}
let Vn = [], qi = !1;
async function td(e, t = !0) {
  if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
    if (Vn.push(e), !qi)
      qi = !0;
    else
      return;
    await G0(), requestAnimationFrame(() => {
      let n = [0, 0];
      for (let i = 0; i < Vn.length; i++) {
        const o = Vn[i].getBoundingClientRect();
        (i === 0 || o.top + window.scrollY <= n[0]) && (n[0] = o.top + window.scrollY, n[1] = i);
      }
      window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), qi = !1, Vn = [];
    });
  }
}
function nd(e, t, n) {
  let i, { $$slots: r = {}, $$scope: o } = t, { i18n: a } = t, { eta: s = null } = t, { queue: u = !1 } = t, { queue_position: f } = t, { queue_size: h } = t, { status: p } = t, { scroll_to_output: g = !1 } = t, { timer: v = !0 } = t, { show_progress: B = "full" } = t, { message: D = null } = t, { progress: N = null } = t, { variant: K = "default" } = t, { loading_text: x = "Loading..." } = t, { absolute: M = !0 } = t, { translucent: H = !1 } = t, { border: A = !1 } = t, { autoscroll: E } = t, m, fe = !1, be = 0, ve = 0, we = null, Re = 0, Ee = null, P, Y = null, le = !0;
  const pe = () => {
    n(25, be = performance.now()), n(26, ve = 0), fe = !0, Q();
  };
  function Q() {
    requestAnimationFrame(() => {
      n(26, ve = (performance.now() - be) / 1e3), fe && Q();
    });
  }
  function k() {
    n(26, ve = 0), fe && (fe = !1);
  }
  z0(() => {
    fe && k();
  });
  let ie = null;
  function R(O) {
    So[O ? "unshift" : "push"](() => {
      Y = O, n(16, Y), n(7, N), n(14, Ee), n(15, P);
    });
  }
  function ye(O) {
    So[O ? "unshift" : "push"](() => {
      m = O, n(13, m);
    });
  }
  return e.$$set = (O) => {
    "i18n" in O && n(1, a = O.i18n), "eta" in O && n(0, s = O.eta), "queue" in O && n(21, u = O.queue), "queue_position" in O && n(2, f = O.queue_position), "queue_size" in O && n(3, h = O.queue_size), "status" in O && n(4, p = O.status), "scroll_to_output" in O && n(22, g = O.scroll_to_output), "timer" in O && n(5, v = O.timer), "show_progress" in O && n(6, B = O.show_progress), "message" in O && n(23, D = O.message), "progress" in O && n(7, N = O.progress), "variant" in O && n(8, K = O.variant), "loading_text" in O && n(9, x = O.loading_text), "absolute" in O && n(10, M = O.absolute), "translucent" in O && n(11, H = O.translucent), "border" in O && n(12, A = O.border), "autoscroll" in O && n(24, E = O.autoscroll), "$$scope" in O && n(28, o = O.$$scope);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*eta, old_eta, queue, timer_start*/
    169869313 && (s === null ? n(0, s = we) : u && n(0, s = (performance.now() - be) / 1e3 + s), s != null && (n(19, ie = s.toFixed(1)), n(27, we = s))), e.$$.dirty[0] & /*eta, timer_diff*/
    67108865 && n(17, Re = s === null || s <= 0 || !ve ? null : Math.min(ve / s, 1)), e.$$.dirty[0] & /*progress*/
    128 && N != null && n(18, le = !1), e.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (N != null ? n(14, Ee = N.map((O) => {
      if (O.index != null && O.length != null)
        return O.index / O.length;
      if (O.progress != null)
        return O.progress;
    })) : n(14, Ee = null), Ee ? (n(15, P = Ee[Ee.length - 1]), Y && (P === 0 ? n(16, Y.style.transition = "0", Y) : n(16, Y.style.transition = "150ms", Y))) : n(15, P = void 0)), e.$$.dirty[0] & /*status*/
    16 && (p === "pending" ? pe() : k()), e.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && m && g && (p === "pending" || p === "complete") && td(m, E), e.$$.dirty[0] & /*status, message*/
    8388624, e.$$.dirty[0] & /*timer_diff*/
    67108864 && n(20, i = ve.toFixed(1));
  }, [
    s,
    a,
    f,
    h,
    p,
    v,
    B,
    N,
    K,
    x,
    M,
    H,
    A,
    m,
    Ee,
    P,
    Y,
    Re,
    le,
    ie,
    i,
    u,
    g,
    D,
    E,
    be,
    ve,
    we,
    o,
    r,
    R,
    ye
  ];
}
class Ua extends R0 {
  constructor(t) {
    super(), k0(
      this,
      t,
      nd,
      ed,
      U0,
      {
        i18n: 1,
        eta: 0,
        queue: 21,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const { setContext: lm, getContext: id } = window.__gradio__svelte__internal, rd = "WORKER_PROXY_CONTEXT_KEY";
function od() {
  return id(rd);
}
function ad(e) {
  return e.host === window.location.host || e.host === "localhost:7860" || e.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  e.host === "lite.local";
}
async function Go(e) {
  if (e == null)
    return e;
  const t = new URL(e);
  if (!ad(t) || t.protocol !== "http:" && t.protocol !== "https:")
    return e;
  const n = od();
  if (n == null)
    return e;
  const i = t.pathname;
  return n.httpRequest({
    method: "GET",
    path: i,
    headers: {},
    query_string: ""
  }).then((r) => {
    if (r.status !== 200)
      throw new Error(`Failed to get file ${i} from the Wasm worker.`);
    const o = new Blob([r.body], {
      type: r.headers["Content-Type"]
    });
    return URL.createObjectURL(o);
  });
}
const {
  SvelteComponent: sd,
  append: ld,
  assign: dr,
  compute_rest_props: zo,
  detach: br,
  element: Fa,
  empty: ud,
  exclude_internal_props: cd,
  get_spread_update: fd,
  handle_promise: qo,
  init: hd,
  insert: vr,
  noop: Yt,
  safe_not_equal: dd,
  set_attributes: jo,
  set_data: md,
  set_style: _d,
  src_url_equal: pd,
  text: gd,
  toggle_class: Xo,
  update_await_block_branch: bd
} = window.__gradio__svelte__internal;
function vd(e) {
  let t, n = (
    /*error*/
    e[3].message + ""
  ), i;
  return {
    c() {
      t = Fa("p"), i = gd(n), _d(t, "color", "red");
    },
    m(r, o) {
      vr(r, t, o), ld(t, i);
    },
    p(r, o) {
      o & /*src*/
      1 && n !== (n = /*error*/
      r[3].message + "") && md(i, n);
    },
    d(r) {
      r && br(t);
    }
  };
}
function wd(e) {
  let t, n, i = [
    {
      src: n = /*resolved_src*/
      e[2]
    },
    /*$$restProps*/
    e[1]
  ], r = {};
  for (let o = 0; o < i.length; o += 1)
    r = dr(r, i[o]);
  return {
    c() {
      t = Fa("img"), jo(t, r), Xo(t, "svelte-1k8xp4f", !0);
    },
    m(o, a) {
      vr(o, t, a);
    },
    p(o, a) {
      jo(t, r = fd(i, [
        a & /*src*/
        1 && !pd(t.src, n = /*resolved_src*/
        o[2]) && { src: n },
        a & /*$$restProps*/
        2 && /*$$restProps*/
        o[1]
      ])), Xo(t, "svelte-1k8xp4f", !0);
    },
    d(o) {
      o && br(t);
    }
  };
}
function yd(e) {
  return { c: Yt, m: Yt, p: Yt, d: Yt };
}
function Ed(e) {
  let t, n, i = {
    ctx: e,
    current: null,
    token: null,
    hasCatch: !0,
    pending: yd,
    then: wd,
    catch: vd,
    value: 2,
    error: 3
  };
  return qo(n = Go(
    /*src*/
    e[0]
  ), i), {
    c() {
      t = ud(), i.block.c();
    },
    m(r, o) {
      vr(r, t, o), i.block.m(r, i.anchor = o), i.mount = () => t.parentNode, i.anchor = t;
    },
    p(r, [o]) {
      e = r, i.ctx = e, o & /*src*/
      1 && n !== (n = Go(
        /*src*/
        e[0]
      )) && qo(n, i) || bd(i, e, o);
    },
    i: Yt,
    o: Yt,
    d(r) {
      r && br(t), i.block.d(r), i.token = null, i = null;
    }
  };
}
function Td(e, t, n) {
  const i = ["src"];
  let r = zo(t, i), { src: o = void 0 } = t;
  return e.$$set = (a) => {
    t = dr(dr({}, t), cd(a)), n(1, r = zo(t, i)), "src" in a && n(0, o = a.src);
  }, [o, r];
}
let Pd = class extends sd {
  constructor(t) {
    super(), hd(this, t, Td, Ed, dd, { src: 0 });
  }
};
const {
  SvelteComponent: Md,
  attr: Sd,
  create_component: Cd,
  destroy_component: xd,
  detach: Id,
  element: Ad,
  init: Rd,
  insert: Ld,
  mount_component: Bd,
  safe_not_equal: Nd,
  toggle_class: Xt,
  transition_in: Od,
  transition_out: Hd
} = window.__gradio__svelte__internal;
function kd(e) {
  let t, n, i;
  return n = new Pd({
    props: {
      src: (
        /*samples_dir*/
        e[1] + /*value*/
        e[0]
      ),
      alt: ""
    }
  }), {
    c() {
      t = Ad("div"), Cd(n.$$.fragment), Sd(t, "class", "container svelte-1iqucjz"), Xt(
        t,
        "table",
        /*type*/
        e[2] === "table"
      ), Xt(
        t,
        "gallery",
        /*type*/
        e[2] === "gallery"
      ), Xt(
        t,
        "selected",
        /*selected*/
        e[3]
      );
    },
    m(r, o) {
      Ld(r, t, o), Bd(n, t, null), i = !0;
    },
    p(r, [o]) {
      const a = {};
      o & /*samples_dir, value*/
      3 && (a.src = /*samples_dir*/
      r[1] + /*value*/
      r[0]), n.$set(a), (!i || o & /*type*/
      4) && Xt(
        t,
        "table",
        /*type*/
        r[2] === "table"
      ), (!i || o & /*type*/
      4) && Xt(
        t,
        "gallery",
        /*type*/
        r[2] === "gallery"
      ), (!i || o & /*selected*/
      8) && Xt(
        t,
        "selected",
        /*selected*/
        r[3]
      );
    },
    i(r) {
      i || (Od(n.$$.fragment, r), i = !0);
    },
    o(r) {
      Hd(n.$$.fragment, r), i = !1;
    },
    d(r) {
      r && Id(t), xd(n);
    }
  };
}
function Dd(e, t, n) {
  let { value: i } = t, { samples_dir: r } = t, { type: o } = t, { selected: a = !1 } = t;
  return e.$$set = (s) => {
    "value" in s && n(0, i = s.value), "samples_dir" in s && n(1, r = s.samples_dir), "type" in s && n(2, o = s.type), "selected" in s && n(3, a = s.selected);
  }, [i, r, o, a];
}
class cm extends Md {
  constructor(t) {
    super(), Rd(this, t, Dd, kd, Nd, {
      value: 0,
      samples_dir: 1,
      type: 2,
      selected: 3
    });
  }
}
const {
  SvelteComponent: Ud,
  add_flush_callback: Fd,
  assign: Ga,
  bind: Gd,
  binding_callbacks: zd,
  bubble: qd,
  check_outros: za,
  create_component: _t,
  destroy_component: pt,
  detach: hi,
  empty: qa,
  flush: Ae,
  get_spread_object: ja,
  get_spread_update: Xa,
  group_outros: Va,
  init: jd,
  insert: di,
  mount_component: gt,
  safe_not_equal: Xd,
  space: Wa,
  transition_in: Xe,
  transition_out: Ve
} = window.__gradio__svelte__internal;
function Vd(e) {
  let t, n;
  return t = new Yo({
    props: {
      visible: (
        /*visible*/
        e[4]
      ),
      variant: (
        /*_value*/
        e[19] === null ? "dashed" : "solid"
      ),
      border_mode: (
        /*dragging*/
        e[18] ? "focus" : "base"
      ),
      padding: !1,
      elem_id: (
        /*elem_id*/
        e[2]
      ),
      elem_classes: (
        /*elem_classes*/
        e[3]
      ),
      height: (
        /*height*/
        e[9] || void 0
      ),
      width: (
        /*width*/
        e[10]
      ),
      allow_overflow: !1,
      container: (
        /*container*/
        e[11]
      ),
      scale: (
        /*scale*/
        e[12]
      ),
      min_width: (
        /*min_width*/
        e[13]
      ),
      $$slots: { default: [Kd] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      _t(t.$$.fragment);
    },
    m(i, r) {
      gt(t, i, r), n = !0;
    },
    p(i, r) {
      const o = {};
      r[0] & /*visible*/
      16 && (o.visible = /*visible*/
      i[4]), r[0] & /*_value*/
      524288 && (o.variant = /*_value*/
      i[19] === null ? "dashed" : "solid"), r[0] & /*dragging*/
      262144 && (o.border_mode = /*dragging*/
      i[18] ? "focus" : "base"), r[0] & /*elem_id*/
      4 && (o.elem_id = /*elem_id*/
      i[2]), r[0] & /*elem_classes*/
      8 && (o.elem_classes = /*elem_classes*/
      i[3]), r[0] & /*height*/
      512 && (o.height = /*height*/
      i[9] || void 0), r[0] & /*width*/
      1024 && (o.width = /*width*/
      i[10]), r[0] & /*container*/
      2048 && (o.container = /*container*/
      i[11]), r[0] & /*scale*/
      4096 && (o.scale = /*scale*/
      i[12]), r[0] & /*min_width*/
      8192 && (o.min_width = /*min_width*/
      i[13]), r[0] & /*root, sources, label, show_label, gradio, value, dragging, loading_status*/
      426339 | r[1] & /*$$scope*/
      8 && (o.$$scope = { dirty: r, ctx: i }), t.$set(o);
    },
    i(i) {
      n || (Xe(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Ve(t.$$.fragment, i), n = !1;
    },
    d(i) {
      pt(t, i);
    }
  };
}
function Wd(e) {
  let t, n;
  return t = new Yo({
    props: {
      visible: (
        /*visible*/
        e[4]
      ),
      variant: "solid",
      border_mode: (
        /*dragging*/
        e[18] ? "focus" : "base"
      ),
      padding: !1,
      elem_id: (
        /*elem_id*/
        e[2]
      ),
      elem_classes: (
        /*elem_classes*/
        e[3]
      ),
      height: (
        /*height*/
        e[9] || void 0
      ),
      width: (
        /*width*/
        e[10]
      ),
      allow_overflow: !1,
      container: (
        /*container*/
        e[11]
      ),
      scale: (
        /*scale*/
        e[12]
      ),
      min_width: (
        /*min_width*/
        e[13]
      ),
      $$slots: { default: [$d] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      _t(t.$$.fragment);
    },
    m(i, r) {
      gt(t, i, r), n = !0;
    },
    p(i, r) {
      const o = {};
      r[0] & /*visible*/
      16 && (o.visible = /*visible*/
      i[4]), r[0] & /*dragging*/
      262144 && (o.border_mode = /*dragging*/
      i[18] ? "focus" : "base"), r[0] & /*elem_id*/
      4 && (o.elem_id = /*elem_id*/
      i[2]), r[0] & /*elem_classes*/
      8 && (o.elem_classes = /*elem_classes*/
      i[3]), r[0] & /*height*/
      512 && (o.height = /*height*/
      i[9] || void 0), r[0] & /*width*/
      1024 && (o.width = /*width*/
      i[10]), r[0] & /*container*/
      2048 && (o.container = /*container*/
      i[11]), r[0] & /*scale*/
      4096 && (o.scale = /*scale*/
      i[12]), r[0] & /*min_width*/
      8192 && (o.min_width = /*min_width*/
      i[13]), r[0] & /*_value, label, show_label, show_download_button, show_share_button, gradio, loading_status*/
      671970 | r[1] & /*$$scope*/
      8 && (o.$$scope = { dirty: r, ctx: i }), t.$set(o);
    },
    i(i) {
      n || (Xe(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Ve(t.$$.fragment, i), n = !1;
    },
    d(i) {
      pt(t, i);
    }
  };
}
function Yd(e) {
  let t, n;
  return t = new Ko({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [Jd] },
      $$scope: { ctx: e }
    }
  }), {
    c() {
      _t(t.$$.fragment);
    },
    m(i, r) {
      gt(t, i, r), n = !0;
    },
    p(i, r) {
      const o = {};
      r[1] & /*$$scope*/
      8 && (o.$$scope = { dirty: r, ctx: i }), t.$set(o);
    },
    i(i) {
      n || (Xe(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Ve(t.$$.fragment, i), n = !1;
    },
    d(i) {
      pt(t, i);
    }
  };
}
function Zd(e) {
  let t, n;
  return t = new pu({
    props: {
      i18n: (
        /*gradio*/
        e[17].i18n
      ),
      type: "image",
      mode: "short"
    }
  }), {
    c() {
      _t(t.$$.fragment);
    },
    m(i, r) {
      gt(t, i, r), n = !0;
    },
    p(i, r) {
      const o = {};
      r[0] & /*gradio*/
      131072 && (o.i18n = /*gradio*/
      i[17].i18n), t.$set(o);
    },
    i(i) {
      n || (Xe(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Ve(t.$$.fragment, i), n = !1;
    },
    d(i) {
      pt(t, i);
    }
  };
}
function Jd(e) {
  let t, n;
  return t = new si({}), {
    c() {
      _t(t.$$.fragment);
    },
    m(i, r) {
      gt(t, i, r), n = !0;
    },
    i(i) {
      n || (Xe(t.$$.fragment, i), n = !0);
    },
    o(i) {
      Ve(t.$$.fragment, i), n = !1;
    },
    d(i) {
      pt(t, i);
    }
  };
}
function Qd(e) {
  let t, n, i, r, o;
  const a = [Zd, Yd], s = [];
  function u(f, h) {
    return h[0] & /*sources*/
    32768 && (t = null), t == null && (t = !!/*sources*/
    f[15].includes("upload")), t ? 0 : 1;
  }
  return n = u(e, [-1, -1]), i = s[n] = a[n](e), {
    c() {
      i.c(), r = qa();
    },
    m(f, h) {
      s[n].m(f, h), di(f, r, h), o = !0;
    },
    p(f, h) {
      let p = n;
      n = u(f, h), n === p ? s[n].p(f, h) : (Va(), Ve(s[p], 1, 1, () => {
        s[p] = null;
      }), za(), i = s[n], i ? i.p(f, h) : (i = s[n] = a[n](f), i.c()), Xe(i, 1), i.m(r.parentNode, r));
    },
    i(f) {
      o || (Xe(i), o = !0);
    },
    o(f) {
      Ve(i), o = !1;
    },
    d(f) {
      f && hi(r), s[n].d(f);
    }
  };
}
function Kd(e) {
  let t, n, i, r, o;
  const a = [
    {
      autoscroll: (
        /*gradio*/
        e[17].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      e[17].i18n
    ) },
    /*loading_status*/
    e[1]
  ];
  let s = {};
  for (let h = 0; h < a.length; h += 1)
    s = Ga(s, a[h]);
  t = new Ua({ props: s });
  function u(h) {
    e[24](h);
  }
  let f = {
    root: (
      /*root*/
      e[8]
    ),
    sources: (
      /*sources*/
      e[15]
    ),
    label: (
      /*label*/
      e[5]
    ),
    show_label: (
      /*show_label*/
      e[6]
    ),
    i18n: (
      /*gradio*/
      e[17].i18n
    ),
    $$slots: { default: [Qd] },
    $$scope: { ctx: e }
  };
  return (
    /*value*/
    e[0] !== void 0 && (f.value = /*value*/
    e[0]), i = new w0({ props: f }), zd.push(() => Gd(i, "value", u)), i.$on(
      "edit",
      /*edit_handler*/
      e[25]
    ), i.$on(
      "clear",
      /*clear_handler*/
      e[26]
    ), i.$on(
      "drag",
      /*drag_handler*/
      e[27]
    ), i.$on(
      "upload",
      /*upload_handler*/
      e[28]
    ), i.$on(
      "select",
      /*select_handler_1*/
      e[29]
    ), i.$on(
      "share",
      /*share_handler_1*/
      e[30]
    ), i.$on(
      "error",
      /*error_handler_2*/
      e[31]
    ), i.$on(
      "click",
      /*click_handler*/
      e[32]
    ), i.$on(
      "error",
      /*error_handler*/
      e[33]
    ), {
      c() {
        _t(t.$$.fragment), n = Wa(), _t(i.$$.fragment);
      },
      m(h, p) {
        gt(t, h, p), di(h, n, p), gt(i, h, p), o = !0;
      },
      p(h, p) {
        const g = p[0] & /*gradio, loading_status*/
        131074 ? Xa(a, [
          p[0] & /*gradio*/
          131072 && {
            autoscroll: (
              /*gradio*/
              h[17].autoscroll
            )
          },
          p[0] & /*gradio*/
          131072 && { i18n: (
            /*gradio*/
            h[17].i18n
          ) },
          p[0] & /*loading_status*/
          2 && ja(
            /*loading_status*/
            h[1]
          )
        ]) : {};
        t.$set(g);
        const v = {};
        p[0] & /*root*/
        256 && (v.root = /*root*/
        h[8]), p[0] & /*sources*/
        32768 && (v.sources = /*sources*/
        h[15]), p[0] & /*label*/
        32 && (v.label = /*label*/
        h[5]), p[0] & /*show_label*/
        64 && (v.show_label = /*show_label*/
        h[6]), p[0] & /*gradio*/
        131072 && (v.i18n = /*gradio*/
        h[17].i18n), p[0] & /*gradio, sources*/
        163840 | p[1] & /*$$scope*/
        8 && (v.$$scope = { dirty: p, ctx: h }), !r && p[0] & /*value*/
        1 && (r = !0, v.value = /*value*/
        h[0], Fd(() => r = !1)), i.$set(v);
      },
      i(h) {
        o || (Xe(t.$$.fragment, h), Xe(i.$$.fragment, h), o = !0);
      },
      o(h) {
        Ve(t.$$.fragment, h), Ve(i.$$.fragment, h), o = !1;
      },
      d(h) {
        h && hi(n), pt(t, h), pt(i, h);
      }
    }
  );
}
function $d(e) {
  let t, n, i, r;
  const o = [
    {
      autoscroll: (
        /*gradio*/
        e[17].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      e[17].i18n
    ) },
    /*loading_status*/
    e[1]
  ];
  let a = {};
  for (let s = 0; s < o.length; s += 1)
    a = Ga(a, o[s]);
  return t = new Ua({ props: a }), i = new hc({
    props: {
      value: (
        /*_value*/
        e[19]
      ),
      label: (
        /*label*/
        e[5]
      ),
      show_label: (
        /*show_label*/
        e[6]
      ),
      show_download_button: (
        /*show_download_button*/
        e[7]
      ),
      show_share_button: (
        /*show_share_button*/
        e[14]
      ),
      i18n: (
        /*gradio*/
        e[17].i18n
      )
    }
  }), i.$on(
    "select",
    /*select_handler*/
    e[21]
  ), i.$on(
    "share",
    /*share_handler*/
    e[22]
  ), i.$on(
    "error",
    /*error_handler_1*/
    e[23]
  ), {
    c() {
      _t(t.$$.fragment), n = Wa(), _t(i.$$.fragment);
    },
    m(s, u) {
      gt(t, s, u), di(s, n, u), gt(i, s, u), r = !0;
    },
    p(s, u) {
      const f = u[0] & /*gradio, loading_status*/
      131074 ? Xa(o, [
        u[0] & /*gradio*/
        131072 && {
          autoscroll: (
            /*gradio*/
            s[17].autoscroll
          )
        },
        u[0] & /*gradio*/
        131072 && { i18n: (
          /*gradio*/
          s[17].i18n
        ) },
        u[0] & /*loading_status*/
        2 && ja(
          /*loading_status*/
          s[1]
        )
      ]) : {};
      t.$set(f);
      const h = {};
      u[0] & /*_value*/
      524288 && (h.value = /*_value*/
      s[19]), u[0] & /*label*/
      32 && (h.label = /*label*/
      s[5]), u[0] & /*show_label*/
      64 && (h.show_label = /*show_label*/
      s[6]), u[0] & /*show_download_button*/
      128 && (h.show_download_button = /*show_download_button*/
      s[7]), u[0] & /*show_share_button*/
      16384 && (h.show_share_button = /*show_share_button*/
      s[14]), u[0] & /*gradio*/
      131072 && (h.i18n = /*gradio*/
      s[17].i18n), i.$set(h);
    },
    i(s) {
      r || (Xe(t.$$.fragment, s), Xe(i.$$.fragment, s), r = !0);
    },
    o(s) {
      Ve(t.$$.fragment, s), Ve(i.$$.fragment, s), r = !1;
    },
    d(s) {
      s && hi(n), pt(t, s), pt(i, s);
    }
  };
}
function em(e) {
  let t, n, i, r;
  const o = [Wd, Vd], a = [];
  function s(u, f) {
    return (
      /*interactive*/
      u[16] ? 1 : 0
    );
  }
  return t = s(e), n = a[t] = o[t](e), {
    c() {
      n.c(), i = qa();
    },
    m(u, f) {
      a[t].m(u, f), di(u, i, f), r = !0;
    },
    p(u, f) {
      let h = t;
      t = s(u), t === h ? a[t].p(u, f) : (Va(), Ve(a[h], 1, 1, () => {
        a[h] = null;
      }), za(), n = a[t], n ? n.p(u, f) : (n = a[t] = o[t](u), n.c()), Xe(n, 1), n.m(i.parentNode, i));
    },
    i(u) {
      r || (Xe(n), r = !0);
    },
    o(u) {
      Ve(n), r = !1;
    },
    d(u) {
      u && hi(i), a[t].d(u);
    }
  };
}
function tm(e) {
  let t, n = e[0], i = 1;
  for (; i < e.length; ) {
    const r = e[i], o = e[i + 1];
    if (i += 2, (r === "optionalAccess" || r === "optionalCall") && n == null)
      return;
    r === "access" || r === "optionalAccess" ? (t = n, n = o(n)) : (r === "call" || r === "optionalCall") && (n = o((...a) => n.call(t, ...a)), t = void 0);
  }
  return n;
}
function nm(e, t, n) {
  let i, { elem_id: r = "" } = t, { elem_classes: o = [] } = t, { visible: a = !0 } = t, { value: s = null } = t, { label: u } = t, { show_label: f } = t, { show_download_button: h } = t, { root: p } = t, { proxy_url: g } = t, { height: v } = t, { width: B } = t, { container: D = !0 } = t, { scale: N = null } = t, { min_width: K = void 0 } = t, { loading_status: x } = t, { show_share_button: M = !1 } = t, { sources: H = ["upload", "clipboard"] } = t, { interactive: A } = t, { gradio: E } = t, m;
  const fe = ({ detail: R }) => E.dispatch("select", R), be = ({ detail: R }) => E.dispatch("share", R), ve = ({ detail: R }) => E.dispatch("error", R);
  function we(R) {
    s = R, n(0, s);
  }
  const Re = () => E.dispatch("edit"), Ee = () => E.dispatch("clear"), P = ({ detail: R }) => n(18, m = R), Y = () => E.dispatch("upload"), le = ({ detail: R }) => E.dispatch("select", R), pe = ({ detail: R }) => E.dispatch("share", R), Q = ({ detail: R }) => {
    n(1, x = x || {}), n(1, x.status = "error", x), E.dispatch("error", R);
  }, k = () => E.dispatch("error", "bad thing happened");
  function ie(R) {
    qd.call(this, e, R);
  }
  return e.$$set = (R) => {
    "elem_id" in R && n(2, r = R.elem_id), "elem_classes" in R && n(3, o = R.elem_classes), "visible" in R && n(4, a = R.visible), "value" in R && n(0, s = R.value), "label" in R && n(5, u = R.label), "show_label" in R && n(6, f = R.show_label), "show_download_button" in R && n(7, h = R.show_download_button), "root" in R && n(8, p = R.root), "proxy_url" in R && n(20, g = R.proxy_url), "height" in R && n(9, v = R.height), "width" in R && n(10, B = R.width), "container" in R && n(11, D = R.container), "scale" in R && n(12, N = R.scale), "min_width" in R && n(13, K = R.min_width), "loading_status" in R && n(1, x = R.loading_status), "show_share_button" in R && n(14, M = R.show_share_button), "sources" in R && n(15, H = R.sources), "interactive" in R && n(16, A = R.interactive), "gradio" in R && n(17, E = R.gradio);
  }, e.$$.update = () => {
    e.$$.dirty[0] & /*value, root, proxy_url*/
    1048833 && n(19, i = dt(s, p, g)), e.$$.dirty[0] & /*value, gradio*/
    131073 && tm([s, "optionalAccess", (R) => R.url]) && E.dispatch("change");
  }, [
    s,
    x,
    r,
    o,
    a,
    u,
    f,
    h,
    p,
    v,
    B,
    D,
    N,
    K,
    M,
    H,
    A,
    E,
    m,
    i,
    g,
    fe,
    be,
    ve,
    we,
    Re,
    Ee,
    P,
    Y,
    le,
    pe,
    Q,
    k,
    ie
  ];
}
class fm extends Ud {
  constructor(t) {
    super(), jd(
      this,
      t,
      nm,
      em,
      Xd,
      {
        elem_id: 2,
        elem_classes: 3,
        visible: 4,
        value: 0,
        label: 5,
        show_label: 6,
        show_download_button: 7,
        root: 8,
        proxy_url: 20,
        height: 9,
        width: 10,
        container: 11,
        scale: 12,
        min_width: 13,
        loading_status: 1,
        show_share_button: 14,
        sources: 15,
        interactive: 16,
        gradio: 17
      },
      null,
      [-1, -1]
    );
  }
  get elem_id() {
    return this.$$.ctx[2];
  }
  set elem_id(t) {
    this.$$set({ elem_id: t }), Ae();
  }
  get elem_classes() {
    return this.$$.ctx[3];
  }
  set elem_classes(t) {
    this.$$set({ elem_classes: t }), Ae();
  }
  get visible() {
    return this.$$.ctx[4];
  }
  set visible(t) {
    this.$$set({ visible: t }), Ae();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(t) {
    this.$$set({ value: t }), Ae();
  }
  get label() {
    return this.$$.ctx[5];
  }
  set label(t) {
    this.$$set({ label: t }), Ae();
  }
  get show_label() {
    return this.$$.ctx[6];
  }
  set show_label(t) {
    this.$$set({ show_label: t }), Ae();
  }
  get show_download_button() {
    return this.$$.ctx[7];
  }
  set show_download_button(t) {
    this.$$set({ show_download_button: t }), Ae();
  }
  get root() {
    return this.$$.ctx[8];
  }
  set root(t) {
    this.$$set({ root: t }), Ae();
  }
  get proxy_url() {
    return this.$$.ctx[20];
  }
  set proxy_url(t) {
    this.$$set({ proxy_url: t }), Ae();
  }
  get height() {
    return this.$$.ctx[9];
  }
  set height(t) {
    this.$$set({ height: t }), Ae();
  }
  get width() {
    return this.$$.ctx[10];
  }
  set width(t) {
    this.$$set({ width: t }), Ae();
  }
  get container() {
    return this.$$.ctx[11];
  }
  set container(t) {
    this.$$set({ container: t }), Ae();
  }
  get scale() {
    return this.$$.ctx[12];
  }
  set scale(t) {
    this.$$set({ scale: t }), Ae();
  }
  get min_width() {
    return this.$$.ctx[13];
  }
  set min_width(t) {
    this.$$set({ min_width: t }), Ae();
  }
  get loading_status() {
    return this.$$.ctx[1];
  }
  set loading_status(t) {
    this.$$set({ loading_status: t }), Ae();
  }
  get show_share_button() {
    return this.$$.ctx[14];
  }
  set show_share_button(t) {
    this.$$set({ show_share_button: t }), Ae();
  }
  get sources() {
    return this.$$.ctx[15];
  }
  set sources(t) {
    this.$$set({ sources: t }), Ae();
  }
  get interactive() {
    return this.$$.ctx[16];
  }
  set interactive(t) {
    this.$$set({ interactive: t }), Ae();
  }
  get gradio() {
    return this.$$.ctx[17];
  }
  set gradio(t) {
    this.$$set({ gradio: t }), Ae();
  }
}
export {
  cm as BaseExample,
  w0 as BaseImageUploader,
  hc as BaseStaticImage,
  fm as default
};
